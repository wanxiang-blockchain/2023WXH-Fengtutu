package com.bage.domain.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.io.Serializable;

/**
 * 文章表(CoArticle)实体类
 *
 * @author makejava
 * @since 2023-08-17 22:34:37
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("co_article")
public class CoArticle implements Serializable {

    private Long id;
/**
     * 标题
     */
    private String title;
/**
     * 文章内容
     */
    private String content;
/**
     * 文章摘要
     */
    private String summary;
/**
     * 所属分类id
     */
    private Long categoryId;
/**
     * 缩略图
     */
    private String thumbnail;
/**
     * 状态（0已发布，1草稿）
     */
    private String status;
/**
     * 访问量
     */
    private Long viewCount;
/**
     * 是否允许评论 1是，0否
     */
    private String isComment;
/**
     * 创建人的用户openpid
     */
    private String createBy;
/**
     * 创建时间
     */
    private Date createTime;
/**
     * 更新人openpid
     */
    private String updateBy;
/**
     * 更新时间
     */
    private Date updateTime;
/**
     * 删除标志（0代表未删除，1代表已删除）
     */
    private String del;
    /**
     * 评论量
     */
    @TableField(exist = false) //告诉mybatisplus这个字段在表里面不存在，查询的时候不要查这个字段
    private Long commentCount;

    @TableField(exist = false)
    private Long praiseCount;

}

