package com.bage.domain.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CoAlbumDto {
    private Long id;

    //画册名称
    private String title;
    //删除画册
    private String del;
    //是否为草稿画册 1是，0否
    private String isDraftAlbum;
    //创建人的用户id
    private String createBy;
    //创建时间
    private Date createTime;
    //更新人的用户id
    private String updateBy;
    //更新时间
    private Date updateTime;
}
