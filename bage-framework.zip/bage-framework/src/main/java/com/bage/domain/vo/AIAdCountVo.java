package com.bage.domain.vo;

import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * 用户VO
 */
@Data
@Accessors(chain = true)
public class AIAdCountVo {
    @TableId
//    private Integer userId;

//    private String userName;

//    private String password;

//    private String defaultTag;

//    private String negativeTag;
    //生成的图片（未读）
//    private String createdImg;

    private Integer adViewNumber;

    private String usableCount;

//    private String token;
}
