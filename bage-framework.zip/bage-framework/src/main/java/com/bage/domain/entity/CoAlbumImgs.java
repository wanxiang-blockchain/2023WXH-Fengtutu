package com.bage.domain.entity;

import java.util.Date;

import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
/**
 * (CoAlbumImgs)表实体类
 *
 * @author makejava
 * @since 2023-08-29 16:55:05
 */
@SuppressWarnings("serial")
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("co_album_imgs")
public class CoAlbumImgs implements Serializable  {
@TableId
    private Integer id;


    private String userName;
//持有人的用户id
    private String userOpenpid;
//图片url
    private String imgUrl;
//图片状态0:删除 1：画册里
    private Integer imgStatus;
//图片来源0:本地生成 1：手机上传
    private Integer imgType;
//图片所在的画册id
    private Long albumId;
//图片进入画册时间
    private Date createTime;

    private String prompt;

    private String promptCn;

    private Integer cn;

    private String model;

    private String negative;

    private Integer steps;



}

