package com.bage.domain.dto;


import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * (AiConfig)表实体类
 *
 * @author makejava
 * @since 2023-08-22 22:22:00
 */
@SuppressWarnings("serial")
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("ai_config")
public class AiConfigDto {
    @ApiModelProperty(notes = "配置ID")//swagger的注解
    private Integer id;
    @ApiModelProperty(notes = "用户token（userName）")//swagger的注解
    private String userName;
    @ApiModelProperty(notes = "奖励种类（预留，可以不传）")//swagger的注解
    private String name;
    @ApiModelProperty(notes = "奖励代码")//swagger的注解
    private String value;
}

