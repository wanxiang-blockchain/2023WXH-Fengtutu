package com.bage.domain.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AiExpandDataDto {
    private String image;
    private String token;
    private String userName;
    private String base64;
}
