package com.bage.domain.entity;


import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.baomidou.mybatisplus.annotation.TableName;
/**
 * (AiTranslate)表实体类
 *
 * @author makejava
 * @since 2023-06-13 17:31:16
 */
@SuppressWarnings("serial")
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("ai_translate")
public class AiTranslate  {

    @TableId
    private Integer id;

    private String name;
    
    private String appid;
    
    private String appkey;
    
    private String staus;
    
    private String used;

    private String translationuselength;

}

