package com.bage.domain.entity;

import java.util.Date;

import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
/**
 * 画册表(CoAlbum)表实体类
 *
 * @author makejava
 * @since 2023-08-28 17:09:29
 */
@SuppressWarnings("serial")
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("co_album")
public class CoAlbum implements Serializable  {
@TableId
    private Long id;

//画册名称
    private String title;
//删除画册
    private String del;
//是否为草稿画册 1是，0否
    private String isDraftAlbum;
//创建人的用户id
    private String createBy;
//创建时间
    private Date createTime;
//更新人的用户id
    private String updateBy;
//更新时间
    private Date updateTime;

}

