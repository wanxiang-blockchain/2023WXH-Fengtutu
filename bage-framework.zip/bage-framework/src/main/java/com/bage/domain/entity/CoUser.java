package com.bage.domain.entity;


import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
/**
 * (CoUser)表实体类
 *
 * @author makejava
 * @since 2023-08-16 19:53:17
 */
@SuppressWarnings("serial")
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("co_user")
public class CoUser  {
    @TableId
    private Integer userId;

    //用户名
    private String userName;
    
    private String password;
    //正向词
    private String defaultTag;
    //反向词
    private String negativeTag;
    //观看广告次数
    private Integer adViewNumber;
    //可用次数
    private String usableCount;
    //用户权限0:普通用户 1:管理员
    private Integer userLimit;
    //手机号
    private String mobile;



}

