package com.bage.domain.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class QueryFromOpenpidDto {
    /**
     * openpid
     */
    private String openpid;
    /**
     * 分页页码
     */
    private Integer pageNum;
    /**
     * 分页单页数据量
     */
    private Integer pageSize;
}
