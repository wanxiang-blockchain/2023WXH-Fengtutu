package com.bage.domain.entity;


import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
/**
 * 各个页面的消息(AiMessage)表实体类
 *
 * @author makejava
 * @since 2023-06-13 16:45:25
 */
@SuppressWarnings("serial")
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("ai_message")
public class AiMessage  {

    
    private String speedMessage;
    
    private String homeMessage;
    
    private String createMessage;
    
    private String myPhoneMessage;
    
    private String myDeffaultMessage;



}

