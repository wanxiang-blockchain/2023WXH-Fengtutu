/**
 * 分页VO，让所有分页类都返回这两个字段
 */
package com.bage.domain.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PageVo {
    //数据集合
    private List rows;
    //total
    private Long total;
}
