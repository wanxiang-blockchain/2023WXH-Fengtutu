package com.bage.domain.dto;
/**
 * 标签列表dto，因为查询条件有两个，一个标签名字name，一个
 * 评论remark。干脆把这两个查询条件封装在一个对象里进行传参
 * 不然分开传会很乱
 * */

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TagListDto {
    //标签名
    private String name;
    //备注
    private String remark;
}
