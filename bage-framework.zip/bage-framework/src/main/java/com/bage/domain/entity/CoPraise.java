package com.bage.domain.entity;

import java.util.Date;

import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
/**
 * (CoPraise)表实体类
 *
 * @author makejava
 * @since 2023-08-23 12:44:25
 */
@SuppressWarnings("serial")
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("co_praise")
public class CoPraise  {
@TableId
    private Long id;

//文章id
    private Long articleId;
//所点赞的目标文章的userid
    private Long toPraiseUserId;

    private Date createTime;

    private Date updateTime;
//删除标志（0代表未删除，1代表已删除）
    private String del;
//点赞人id
    private Long createByUserId;
//点赞人名称
    private String createByUserName;



}

