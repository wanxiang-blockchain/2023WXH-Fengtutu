package com.bage.domain.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AiCreatSdDataDto {
//    @JsonIgnore//这个注解可以让前端不传这个字段时不报错（直接前端传了就过滤了，不要用！）
    private Object alwayson_scripts;
    private List<Object> controlnet_units;
    private double cfg;
    private Long cn;
    private double denoisingStrength;
    private Long height;
    private String image;
    private String model;
    private String negative;
    private String prompt;
    @ApiModelProperty(notes = "翻译前的中文内容")//swagger的注解
    private String promptcn;
    private String sampler;
    private String optimizeModel;
    private Long steps;
    private String token;
    private String userName;
//    @JsonIgnore//这个注解可以让前端不传这个字段时不报错（直接前端传了就过滤了，不要用！）
    private String base64;
    private Long width;
}
