package com.bage.domain.vo;
/**
 * 导出分类列表的Excel VO
 * */
import com.alibaba.excel.annotation.ExcelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ExcelCategoryVo {
    @ExcelProperty("分类名")//告诉easyExcel，导出excel的列名
    private String name;
    //描述
    @ExcelProperty("描述")//告诉easyExcel列名，导出excel的列名
    private String description;

    //状态0:正常,1禁用
    @ExcelProperty("状态0:正常,1禁用")//告诉easyExcel列名，导出excel的列名
    private String status;
}
