package com.bage.domain.entity;


import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
/**
 * (AiConfig)表实体类
 *
 * @author makejava
 * @since 2023-08-22 22:22:00
 */
@SuppressWarnings("serial")
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("ai_config")
public class AiConfig  {
    @TableId
    @ApiModelProperty(notes = "配置id")//swagger的注解
    private Integer id;
    
    private String name;
    
    private String value;



}

