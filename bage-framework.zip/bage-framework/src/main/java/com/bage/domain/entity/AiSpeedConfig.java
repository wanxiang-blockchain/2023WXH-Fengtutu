package com.bage.domain.entity;


import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
/**
 * 快捷生图的相关配置(AiSpeedConfig)表实体类
 *
 * @author makejava
 * @since 2023-06-15 21:49:07
 */
@SuppressWarnings("serial")
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("ai_speed_config")
public class AiSpeedConfig  {
    @TableId
    private String name;

    
    private String tag;
    
    private String sampling;
    
    private Integer cfg;
    
    private String model;
    
    private String type;



}

