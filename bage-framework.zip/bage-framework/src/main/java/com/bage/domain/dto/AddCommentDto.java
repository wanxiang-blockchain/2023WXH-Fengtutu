package com.bage.domain.dto;
/**
* dto（数据传输对象） 因为我们新增评论用了entity下的Comment类，但是后面加入编辑还用这个类就会很乱
 * 所以我们新创建这个dto的类，让这个AddCommentDto类专门用作新增评论的类。但是要去controller去引用一下
 * 这里dto和VO的区别我认为的是：dto是前端传给后端的整理后的格式。vo是后端返回给前端的整理后的格式
* */
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "添加评论dto")
public class AddCommentDto {
    private Long id;
    //评论类型（0代表文章评论，1代表友链评论）
    @ApiModelProperty(notes = "评论类型（0代表文章评论，1代表友链评论）") //swagger的注解
    private String type;
    //文章id
    @ApiModelProperty(notes = "文章id")//swagger的注解
    private Long articleId;
    //根评论id
    private Long rootId;
    //评论内容
    private String content;
    //所回复的目标评论的userid
    private Long toCommentUserId;
    //回复目标评论id
    private Long toCommentId;
    private Long createBy;
    private Date createTime;
    private Long updateBy;
    private Date updateTime;
    //删除标志（0代表未删除，1代表已删除）
    private Integer delFlag;
}
