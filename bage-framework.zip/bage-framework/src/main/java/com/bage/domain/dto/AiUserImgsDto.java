package com.bage.domain.dto;

import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * (AiUserImgs)表实体类
 *
 * @author makejava
 * @since 2023-07-29 14:34:56
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AiUserImgsDto {
    @ApiModelProperty(notes = "图片id")//swagger的注解
    private Integer id;
    @ApiModelProperty(notes = "用户token（userName）")//swagger的注解
    private String userName;
    //图片状态0:删除 1：相册里
    @ApiModelProperty(notes = "图片状态0:删除 1：相册里")//swagger的注解
    private Integer imgStatus;
    //图片审核状态0:通过 1：不通过
    @ApiModelProperty(notes = "图片审核状态0:通过 1：不通过")//swagger的注解
    private Integer examineStatus;
    @ApiModelProperty(notes = "是否为审核员1:是 0：不是")//swagger的注解
    private Integer isCheckMan;
}

