package com.bage.domain.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TextExamineDataDto {
    @ApiModelProperty(notes = "需检测的文本内容，文本字数的上限为2500字") //swagger的注解
    private String prompt;
    private String token;
    @ApiModelProperty(notes = "场景枚举值（1 资料；2 评论；3 论坛；4 社交日志）") //swagger的注解
    private Integer scene;
}
