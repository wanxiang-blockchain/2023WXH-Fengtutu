package com.bage.domain.entity;


import java.io.Serializable;
import java.util.Date;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
/**
 * (AiUserImgs)表实体类
 *
 * @author makejava
 * @since 2023-07-29 14:34:56
 */
@SuppressWarnings("serial")
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("ai_user_imgs")
public class AiUserImgs  {
    @TableId
    @ApiModelProperty(notes = "图片id")//swagger的注解
    private Integer id;
    @ApiModelProperty(notes = "用户token（userName）")//swagger的注解
    private String userName;
    //生成的图片（未读）
    private String imgUrl;
    //图片审核状态0:通过 1：不通过
    @ApiModelProperty(notes = "图片审核状态0:通过 1：不通过")//swagger的注解
    private Integer examineStatus;
    //图片状态0:删除 1：相册里
    @ApiModelProperty(notes = "图片状态0:删除 1：相册里")//swagger的注解
    private Integer imgStatus;
    @TableField(fill = FieldFill.INSERT)//（@TableField这个注解加上后再调用mybatisplus数据库插入动作时就会自动将该字段插入数据库。需要配合我们自定义的bage-framework/src/main/java/com/bage/handler/mybatisplus/MyMetaObjectHandler.java里的方法）
    private Date createTime;
    private String prompt;
    private String promptCn;
    private String model;
    private String negative;
    private Long cn;
    private Long steps;
}

