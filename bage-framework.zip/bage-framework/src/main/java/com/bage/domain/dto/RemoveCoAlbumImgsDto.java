package com.bage.domain.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RemoveCoAlbumImgsDto {
    //移动到目标画册id
    private Long albumId;
    //持有人的用户id
    private Long userId;
    //需要移动的图片id
    private List<Integer> ids;
}
