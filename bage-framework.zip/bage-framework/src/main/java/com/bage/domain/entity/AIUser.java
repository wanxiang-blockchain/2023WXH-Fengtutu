package com.bage.domain.entity;


import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
/**
 * (User)表实体类
 *
 * @author makejava
 * @since 2023-06-07 20:16:24
 */
@SuppressWarnings("serial")
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("ai_user")
public class AIUser {
    @TableId
    private Integer userId;

    
    private String userName;
    
    private String password;
    
    private String defaultTag;
    
    private String negativeTag;
    //生成的图片（未读）
    private String createdImg;
    
    private Integer adViewNumber;
    
    private String usableCount;

    //用户权限 0:普通用户 1：管理员
    @ApiModelProperty(notes = "用户权限 0:普通用户 1：管理员")
    private Integer userLimit;



}

