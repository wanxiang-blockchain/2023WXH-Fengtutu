package com.bage.domain.entity;

import java.util.Date;

import java.util.List;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
/**
 * (CommunityComment)表实体类
 *
 * @author makejava
 * @since 2023-08-23 18:05:28
 */
@SuppressWarnings("serial")
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("community_comment")
public class CommunityComment  {
@TableId
    private Long id;

//文章id
    private Long articleId;
//根评论id
    private Long rootId;
//评论内容
    private String content;
//所回复的目标评论的userid
    private Long toCommentUserId;
//回复目标评论id
    private Long toCommentId;
//评论人id
    private Integer createByUserId;
//评论人名称
    private String createByUserName;

    private Date createTime;

    private Long updateBy;

    private Date updateTime;
//删除标志（0代表未删除，1代表已删除）
    private String del;

    //子评论
    @TableField(exist = false) //告诉mybatisplus这个字段在表里面不存在，查询的时候不要查这个字段
    private List<CommunityComment> children;

}

