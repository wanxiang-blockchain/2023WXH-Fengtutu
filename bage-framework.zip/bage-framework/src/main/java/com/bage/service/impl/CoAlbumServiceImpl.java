package com.bage.service.impl;
import com.bage.domain.ResponseResult;
import com.bage.domain.dto.QueryFromOpenpidDto;
import com.bage.domain.entity.CoAlbum;
import com.bage.domain.entity.CoArticle;
import com.bage.domain.vo.PageVo;
import com.bage.enums.AppHttpCodeEnum;
import com.bage.exception.SystemException;
import com.bage.mapper.CoAlbumMapper;
import com.bage.service.CoAlbumService;
import com.bage.utils.BeanCopyUtils;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;

/**
 * 画册表(CoAlbum)表服务实现类
 *
 * @author makejava
 * @since 2023-08-28 17:09:32
 */
@Service("coAlbumService")
public class CoAlbumServiceImpl extends ServiceImpl<CoAlbumMapper, CoAlbum> implements CoAlbumService {
    @Autowired
    private CoAlbumMapper coAlbumMapper;
    /**
     * 用户添加新的画册
     * **/
    @Override
    public ResponseResult creatNewCoAlbum(CoAlbum coAlbum) {
        //画册名称不能为空
        if(!StringUtils.hasText(coAlbum.getTitle())){
            throw new SystemException(AppHttpCodeEnum.CONTENT_NOT_NULL);//抛出异常
        }
        //设置为非草稿画册
        coAlbum.setIsDraftAlbum("0");
        coAlbum.setDel("0");
        //将数据插入数据库 注意：这里因为我们定义了全局的mybatisplus这个公共方法，所以我们在使用mybatisplus的save方法时会自动帮我们插入我们在类中自定义的字段，比如createBy等，具体可以看MyMetaObjectHandler.java这个文件
        save(coAlbum);
        return ResponseResult.okResult();
    }
    /**
     * 用户添加新的画册
     * **/
    @Override
    public ResponseResult queryCoAlbumList(QueryFromOpenpidDto queryFromOpenpidDto) {
        LambdaQueryWrapper<CoAlbum> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(CoAlbum::getCreateBy, queryFromOpenpidDto.getOpenpid());
        //分页查询
        Page<CoAlbum> page = new Page<>(queryFromOpenpidDto.getPageNum(),queryFromOpenpidDto.getPageSize());
        page(page,queryWrapper);
        List<CoAlbum> coAlbumListVos = BeanCopyUtils.copyBeanList(page.getRecords(), CoAlbum.class);//当前获取到的值为data:[]，不满足前端要求的数据格式
        PageVo pageVo = new PageVo(coAlbumListVos,page.getTotal());//两个属性分别为rows和total，这样封装出来的格式就是data:{rows:[],total:0}
        return ResponseResult.okResult(pageVo);
    }
    /**
     * 用户更新画册
     * **/
    @Override
    public ResponseResult updateCoAlbum(CoAlbum coAlbum) {
        //画册名称不能为空
        if(!StringUtils.hasText(coAlbum.getTitle())){
            throw new SystemException(AppHttpCodeEnum.CONTENT_NOT_NULL);//抛出异常
        }
        coAlbumMapper.updateById(coAlbum);
        return ResponseResult.okResult();
    }
    /**
     * 删除单个画册（逻辑删除）
     * **/
    @Override
    public ResponseResult deleteCoAlbum(Long id) {
        LambdaQueryWrapper<CoAlbum> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(CoAlbum::getId, id);
        CoAlbum coAlbum = coAlbumMapper.selectOne(queryWrapper);
        coAlbum.setDel("1");
        coAlbumMapper.updateById(coAlbum);
        return ResponseResult.okResult();
    }
}
