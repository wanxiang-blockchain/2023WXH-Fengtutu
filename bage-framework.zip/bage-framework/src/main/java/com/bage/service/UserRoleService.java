package com.bage.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.bage.domain.entity.UserRole;

/**
 * 用户角色
 */
public interface UserRoleService extends IService<UserRole> {
}
