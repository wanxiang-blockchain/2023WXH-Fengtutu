package com.bage.service.impl;
import com.bage.domain.ResponseResult;
import com.bage.domain.entity.CoArticle;
import com.bage.domain.entity.CoPraise;
import com.bage.mapper.CoPraiseMapper;
import com.bage.service.CoPraiseService;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * (CoPraise)表服务实现类
 *
 * @author makejava
 * @since 2023-08-23 12:44:27
 */
@Service("coPraiseService")
public class CoPraiseServiceImpl extends ServiceImpl<CoPraiseMapper, CoPraise> implements CoPraiseService {
    @Resource
    private CoPraiseMapper coPraiseMapper;
    /**
     * 删除点赞（逻辑删除）
     * **/
    @Override
    public ResponseResult delCoPraise(Long id) {
        LambdaQueryWrapper<CoPraise> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(CoPraise::getId, id);
        CoPraise oneCoPraise = coPraiseMapper.selectOne(queryWrapper);
        oneCoPraise.setDel("1");
        coPraiseMapper.updateById(oneCoPraise);
        return ResponseResult.okResult();
    }
    /**
     * 根据文章id获取评点赞列表
     * **/
    @Override
    public ResponseResult getPraiseListByArticleId(Long articleId) {
        List<CoPraise> coPraiseList = getPraiseList("articleId", articleId);
        return ResponseResult.okResult(coPraiseList);
    }
    /**
     * 根据用户id获取评点赞列表（自己赞过的）
     * **/
    @Override
    public ResponseResult getPraiseListByCreateByUserId(Long createByUserId) {
        List<CoPraise> coPraiseList = getPraiseList("createByUserId", createByUserId);
        return ResponseResult.okResult(coPraiseList);
    }
    /**
     * 根据用户id获取评点赞列表（自己获得的赞）
     * **/
    @Override
    public ResponseResult getPraiseListByToPraiseUserId(Long toPraiseUserId) {
        List<CoPraise> coPraiseList = getPraiseList("toPraiseUserId", toPraiseUserId);
        return ResponseResult.okResult(coPraiseList);
    }
    @Override
    public List<CoPraise> getPraiseList(String type, Long id) {
        LambdaQueryWrapper<CoPraise> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(CoPraise::getDel, "0");
        if(type == "articleId"){
            queryWrapper.eq(CoPraise::getArticleId, id);
        }
        if(type == "createByUserId"){
            queryWrapper.eq(CoPraise::getCreateByUserId, id);
        }
        if(type == "toPraiseUserId"){
            queryWrapper.eq(CoPraise::getToPraiseUserId, id);
        }
        List<CoPraise> coPraiseList = coPraiseMapper.selectList(queryWrapper);
        return coPraiseList;
    }
}
