package com.bage.service.impl;

import com.bage.constants.SystemConstants;
import com.bage.domain.ResponseResult;
import com.bage.domain.entity.AiMessage;
import com.bage.domain.entity.Link;
import com.bage.domain.entity.Tag;
import com.bage.domain.vo.LinkVo;
import com.bage.domain.vo.TagVo;
import com.bage.mapper.AiMessageMapper;
import com.bage.service.AiMessageService;
import com.bage.utils.BeanCopyUtils;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 各个页面的消息(AiMessage)表服务实现类
 *
 * @author makejava
 * @since 2023-06-13 16:45:27
 */
@Service("aiMessageService")
public class AiMessageServiceImpl extends ServiceImpl<AiMessageMapper, AiMessage> implements AiMessageService {

    @Override
    public ResponseResult getMessage(AiMessage message) {
        LambdaQueryWrapper<AiMessage> wrapper = new LambdaQueryWrapper<>();
        wrapper.select(AiMessage::getSpeedMessage,AiMessage::getHomeMessage,AiMessage::getCreateMessage,AiMessage::getMyPhoneMessage,AiMessage::getMyDeffaultMessage);//select定义了要查询哪些字段，这里定义了只查询id和name字段
        List<AiMessage> list = list(wrapper);
        return ResponseResult.okResult(list);
    }
}

