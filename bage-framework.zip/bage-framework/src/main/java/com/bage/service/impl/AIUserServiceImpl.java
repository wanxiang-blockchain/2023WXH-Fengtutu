package com.bage.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.bage.domain.ResponseResult;
import com.bage.domain.dto.AiConfigDto;
import com.bage.domain.entity.AIUser;
import com.bage.domain.entity.AiConfig;
import com.bage.domain.vo.AIAdCountVo;
import com.bage.domain.vo.AIUserVo;
import com.bage.enums.AppHttpCodeEnum;
import com.bage.exception.SystemException;
import com.bage.mapper.AIUserMapper;
import com.bage.mapper.AiConfigMapper;
import com.bage.service.AIUserService;
import com.bage.utils.BeanCopyUtils;
import com.bage.utils.JwtUtil;
import com.bage.utils.WeChatUtil;
import com.bage.utils.WebUtils;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.jsonwebtoken.Claims;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.bage.utils.JwtUtil.getUserId;

/**
 * (User)表服务实现类
 *
 * @author makejava
 * @since 2023-06-07 20:16:28
 */
@Service("aiUserService")
public class AIUserServiceImpl extends ServiceImpl<AIUserMapper, AIUser> implements AIUserService {
    @Autowired
    private AIUserMapper aIUserMapper;

    @Autowired
    private AiConfigMapper aiConfigMapper;
    /**
     * 登录
     */
    @Override
    public ResponseResult login(AIUser user) {

        // 微信小程序ID
        String appid = "wxae6fd03c53b99951";
        // 微信小程序秘钥
        String secret = "b6b20875aaf2ce7a20d0d41fb01ecd11";

        // 根据小程序传过来的code像这个url发送请求
        String url = "https://api.weixin.qq.com/sns/jscode2session?appid=" + appid + "&secret=" + secret + "&js_code=" + user.getUserName() + "&grant_type=authorization_code";
        // 发送请求，返回Json字符串
        String str = WeChatUtil.httpRequest(url, "GET", null);
        // 转成Json对象 获取openid
        JSONObject jsonObject = JSONObject.parseObject(str);
        String openid = jsonObject.getString("openid");
        String jwt = JwtUtil.createJWT(openid);//jwt的工具类生成token
        //对数据进行是否存在的判断,如果存在用户则直接找到用户的openid直接生成token给前端，否则存入数据库
        if (!userNameExist(openid)) {
            user.setPassword(openid);
            user.setUserName(openid);
            save(user);
        }
        //根据user_name查询用户
        LambdaQueryWrapper<AIUser> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(AIUser::getUserName,openid);
        AIUser aIUser = aIUserMapper.selectOne(queryWrapper);
        AIUserVo aIUserVo = BeanCopyUtils.copyBean(aIUser, AIUserVo.class);
        aIUserVo.setToken(jwt);
        return ResponseResult.okResult(aIUserVo);
    }
    /**
     * 获取用户广告次数
     */
    @Override
    public ResponseResult getAdCount(AIUser user) {
        //根据user_name查询用户
        LambdaQueryWrapper<AIUser> queryWrapper = new LambdaQueryWrapper<>();
        String id = user.getUserName();
        Claims claims = null;
        try {
            claims = JwtUtil.parseJWT(id);
        } catch (Exception e) {
            e.printStackTrace();
            //token超时  token非法
            //响应告诉前端需要重新登录
        }
        String userId = claims.getSubject();
        queryWrapper.eq(AIUser::getUserName,userId );
        AIUser aIUser = aIUserMapper.selectOne(queryWrapper);
        AIAdCountVo aIAdCountVo = BeanCopyUtils.copyBean(aIUser, AIAdCountVo.class);
        return ResponseResult.okResult(aIAdCountVo);
    }
    /**
     * 用户观看广告
     */
    @Override
    public ResponseResult lookedAd(AIUser user) {
        //根据user_name查询用户
        LambdaQueryWrapper<AIUser> queryWrapper = new LambdaQueryWrapper<>();
        String id = user.getUserName();
        Claims claims = null;
        try {
            claims = JwtUtil.parseJWT(id);
        } catch (Exception e) {
            e.printStackTrace();
            //token超时  token非法
            //响应告诉前端需要重新登录
        }
        String userId = claims.getSubject();
        queryWrapper.eq(AIUser::getUserName,userId );
        AIUser aIUser = aIUserMapper.selectOne(queryWrapper);
        //如果用户观看次数小于5则可用次数+1，观看次数+1
        if(aIUser.getAdViewNumber()<5){
            String newUsableCount = String.valueOf((Integer.parseInt(aIUser.getUsableCount())+5));
            Integer newAdViewNumber = aIUser.getAdViewNumber()+1;
            aIUser.setUsableCount(newUsableCount);
            aIUser.setAdViewNumber(newAdViewNumber);
            aIUserMapper.updateById(aIUser);
        }else{
            //否则可用次数为999
            aIUser.setUsableCount("999");
            aIUserMapper.updateById(aIUser);
        }
        return ResponseResult.okResult(aIUser.getUsableCount());
    }
    /**
     * 用户默认标签
     */
    @Override
    public ResponseResult defaultTagUpdate(AIUser user) {
        //根据user_name查询用户
        LambdaQueryWrapper<AIUser> queryWrapper = new LambdaQueryWrapper<>();
        String id = user.getUserName();
        Claims claims = null;
        try {
            claims = JwtUtil.parseJWT(id);
        } catch (Exception e) {
            e.printStackTrace();
            //token超时  token非法
            //响应告诉前端需要重新登录
        }
        String userId = claims.getSubject();
        queryWrapper.eq(AIUser::getUserName,userId );
        AIUser aIUser = aIUserMapper.selectOne(queryWrapper);
        aIUser.setDefaultTag(user.getDefaultTag());
        aIUser.setNegativeTag(user.getNegativeTag());
        aIUserMapper.updateById(aIUser);
        return ResponseResult.okResult(aIUser);
    }
    /**
     * 用户获取奖励次数
     */
    @Override
    public ResponseResult reward(AiConfigDto aiConfigDto) {
        // 获取用户userId
        String userId = getUserId(aiConfigDto.getUserName());
        //根据user_name查询用户
        LambdaQueryWrapper<AIUser> queryWrapperUser = new LambdaQueryWrapper<>();
        queryWrapperUser.eq(AIUser::getUserName,userId );
        AIUser aIUser = aIUserMapper.selectOne(queryWrapperUser);
        // 查询当前奖励代码
        LambdaQueryWrapper<AiConfig> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(AiConfig::getId,aiConfigDto.getId());
        AiConfig aiConfig = aiConfigMapper.selectOne(queryWrapper);
        //判断用户输入的密钥值是否正确，正确的话把可用次数变999
        if(aiConfig.getValue().equals(aiConfigDto.getValue())){
            aIUser.setUsableCount("999");
            aIUserMapper.updateById(aIUser);
            return ResponseResult.okResult(true);
        }else{
            return ResponseResult.errorResult(AppHttpCodeEnum.USABLECOUNT_GET_ERROR);
        }

    }

    //判断用户名是否存在
    private boolean userNameExist(String userName) {
        LambdaQueryWrapper<AIUser> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(AIUser::getUserName,userName);
        return count(queryWrapper)>0;
    }
}

