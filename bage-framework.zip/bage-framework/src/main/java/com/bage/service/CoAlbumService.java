package com.bage.service;

import com.bage.domain.ResponseResult;
import com.bage.domain.dto.CoAlbumDto;
import com.bage.domain.dto.QueryFromOpenpidDto;
import com.bage.domain.entity.CoAlbum;
import com.baomidou.mybatisplus.extension.service.IService;


/**
 * 画册表(CoAlbum)表服务接口
 *
 * @author makejava
 * @since 2023-08-28 17:09:31
 */
public interface CoAlbumService extends IService<CoAlbum> {
    /**
     * 用户添加新的画册
     * **/
    ResponseResult creatNewCoAlbum(CoAlbum coAlbum);
    /**
     * 根据用户openpid获取相册列表
     * **/
    ResponseResult queryCoAlbumList(QueryFromOpenpidDto queryFromOpenpidDto);
    /**
     * 用户更新画册
     * **/
    ResponseResult updateCoAlbum(CoAlbum coAlbum);
    /**
     * 删除单个画册（逻辑删除）
     * **/
    ResponseResult deleteCoAlbum(Long id);
}
