package com.bage.service.impl;

import com.bage.constants.SystemConstants;
import com.bage.domain.ResponseResult;
import com.bage.domain.dto.AiUserImgsDto;
import com.bage.domain.entity.AIUser;
import com.bage.domain.entity.AiTranslate;
import com.bage.domain.entity.Article;
import com.bage.domain.vo.ArticleListVo;
import com.bage.domain.vo.PageVo;
import com.bage.enums.AppHttpCodeEnum;
import com.bage.mapper.AIUserMapper;
import com.bage.mapper.AiUserImgsMapper;
import com.bage.domain.entity.AiUserImgs;
import com.bage.service.AiUserImgsService;
import com.bage.utils.BeanCopyUtils;
import com.bage.utils.JwtUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.jsonwebtoken.Claims;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.*;
import java.util.stream.Collectors;

import static com.bage.constants.SystemConstants.*;
import static com.bage.utils.JwtUtil.getUserId;

/**
 * (AiUserImgs)表服务实现类
 *
 * @author makejava
 * @since 2023-07-29 14:34:58
 */
@Service("aiUserImgsService")
public class AiUserImgsServiceImpl extends ServiceImpl<AiUserImgsMapper, AiUserImgs> implements AiUserImgsService {
    @Autowired
    private AiUserImgsMapper aiUserImgsMapper;
    @Autowired
    private AIUserMapper aIUserMapper;

    /**
     * 将用户生成的图片存入数据库
     * */
    @Override
    public void setUserImgs(AiUserImgs aiUserImgs) {
        save(aiUserImgs);
    }
    /**
     * 获取用户图片列表
     * */
    @Override
    public ResponseResult aiUserImgsList(Integer pageNum, Integer pageSize, AiUserImgsDto aiUserImgsDto) {
        // 获取用户userId
        String userId = getUserId(aiUserImgsDto.getUserName());
        //如果传入了IsCheckMan字段且为1且为管理员，则代表要查询所有用户图片showAllUserImgs为true
        boolean showAllUserImgs = false;
        if(Objects.nonNull(aiUserImgsDto.getIsCheckMan())&&aiUserImgsDto.getIsCheckMan()==1){
            //根据userId查询用户是否为管理员
            LambdaQueryWrapper<AIUser> queryWrapper = new LambdaQueryWrapper<>();
            queryWrapper.eq(AIUser::getUserName,userId);
            AIUser aIUser = aIUserMapper.selectOne(queryWrapper);
            Integer userLimit = aIUser.getUserLimit();
            showAllUserImgs = userLimit==1?true:false;
        }

        // 查询条件
        LambdaQueryWrapper<AiUserImgs> lambdaQueryWrapper = new LambdaQueryWrapper<>();
        // 如果 有userName 就要 查询时要和传入的相同
        lambdaQueryWrapper.eq(!showAllUserImgs, AiUserImgs::getUserName, userId);//当Objects.nonNull(aiUserImgs.getUserName())不为空的时候本条语句才生效
        // 状态是前端传来的的
        lambdaQueryWrapper.eq(Objects.nonNull(aiUserImgsDto.getImgStatus()), AiUserImgs::getImgStatus, aiUserImgsDto.getImgStatus());
        // 审核是前端传来的
        lambdaQueryWrapper.eq(Objects.nonNull(aiUserImgsDto.getExamineStatus()), AiUserImgs::getExamineStatus, aiUserImgsDto.getExamineStatus());
        // 对CreateTime进行降序
        lambdaQueryWrapper.orderByDesc(AiUserImgs::getCreateTime);
        //分页查询
        Page<AiUserImgs> page = new Page<>(pageNum, pageSize);
        page(page, lambdaQueryWrapper);
        List<AiUserImgs> aiUserImgs = page.getRecords();
        //封装查询结果
        PageVo pageVo = new PageVo(aiUserImgs, page.getTotal());//两个属性分别为rows和total，这样封装出来的格式就是data:{rows:[],total:0}
        return ResponseResult.okResult(pageVo);
    }
    /**
     * 用户图片状态修改
     * **/
    @Override
    public ResponseResult aiChangeUserImgStatus(AiUserImgsDto aiUserImgs) {

        // 获取用户userId
        String userId = getUserId(aiUserImgs.getUserName());

        //根据userId查询用户是否为管理员
        LambdaQueryWrapper<AIUser> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(AIUser::getUserName,userId);
        AIUser aIUser = aIUserMapper.selectOne(queryWrapper);
        Integer userLimit = aIUser.getUserLimit();
        //查出对应用户图片
        LambdaQueryWrapper<AiUserImgs> wrapper = new LambdaQueryWrapper<>();
        //查询用户图片（如果为管理员则可查询全部图片）
        wrapper.eq(userLimit==USER_LIMIT_NORMAL,AiUserImgs::getUserName, userId).eq(AiUserImgs::getId, aiUserImgs.getId());
        AiUserImgs aiUserImg = aiUserImgsMapper.selectOne(wrapper);

        //判断用户保存了多少张图片，如果超过20则不能继续保存
        if(userLimit==USER_LIMIT_NORMAL){
            LambdaQueryWrapper<AiUserImgs> wrapperList = new LambdaQueryWrapper<>();
            wrapperList.eq(AiUserImgs::getUserName, userId);
            wrapperList.eq(AiUserImgs::getImgStatus, USER_IMG_STATUS_NORMAL);
            List<AiUserImgs> aiUserImgsList = list(wrapperList);
            //超过20张且继续保存则提示无法保存
            if(aiUserImgsList.size()>19&&aiUserImgs.getImgStatus()==USER_IMG_STATUS_NORMAL){
                return ResponseResult.errorResult(AppHttpCodeEnum.USAIMG_ERROR);
            }
        }
        aiUserImg.setImgStatus(aiUserImgs.getImgStatus());
        aiUserImg.setExamineStatus(aiUserImgs.getExamineStatus());
        //更新图片状态
        aiUserImgsMapper.updateById(aiUserImg);
        return ResponseResult.okResult(true);
    }
    /**
     * 主动执行删除服务器里的未保存的图片接口
     * **/
    @Override
    public ResponseResult aiDiskSpaceChecker(AiUserImgsDto aiUserImgs) {
        // 获取用户userId
        String userId = getUserId(aiUserImgs.getUserName());

        // 根据userId查询用户是否为管理员
        LambdaQueryWrapper<AIUser> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(AIUser::getUserName, userId);
        AIUser aIUser = aIUserMapper.selectOne(queryWrapper);
        Integer userLimit = aIUser.getUserLimit();
        // 如果用户为管理员
        if (userLimit == USER_LIMIT_ADMIN) {
            // 从数据库获取img_status为0的图片名字列表
            List<AiUserImgs> aiUserImgsList = aiUserImgsMapper.selectList(null);

            // 创建一个集合来保存数据库中有记录的图片名字
            Set<String> imageNamesInDatabase = new HashSet<>();
            // 创建一个集合来保存数据库中img_status为1的图片名字
            Set<String> imageNamesStatus1 = new HashSet<>();
            for (AiUserImgs img : aiUserImgsList) {
                if (img.getImgStatus() == SystemConstants.USER_IMG_STATUS_DEL) {
                    imageNamesInDatabase.add(img.getImgUrl()); // 假设 getImgUrl() 返回图片的名字
                } else {
                    imageNamesStatus1.add(img.getImgUrl());
                }
            }

            // 删除数据库中img_status为0的图片(用户没保存的图片)记录并删除服务器文件夹中对应的图片
            for (AiUserImgs img : aiUserImgsList) {
                if (img.getImgStatus() == SystemConstants.USER_IMG_STATUS_DEL) {
                    // 从数据库中删除图片记录
                    aiUserImgsMapper.deleteById(img.getId());

                    // 从服务器文件夹中删除对应的图片
                    String imagePath = img.getImgUrl(); // 假设 getImgUrl() 返回图片的名字
                    File imageFile = new File(imagePath);
                    if (imageFile.exists()) {
                        if (imageFile.delete()) {
                            System.out.println("已删除图片文件: " + imageFile.getAbsolutePath());
                        } else {
                            System.out.println("无法删除图片文件: " + imageFile.getAbsolutePath());
                        }
                    } else {
                        System.out.println("图片文件不存在: " + imageFile.getAbsolutePath());
                    }
                }
            }

            // 现在，删除 /data 文件夹下找不到对应数据库记录且 img_status 为 0 的图片
//            String username = System.getProperty("user.name");
//            String dataF = "/Users/" + username + "/Desktop/ceshi"; // 指定保存图片的路径
//            File dataFolder = new File(dataF);
//            File[] dataFiles = dataFolder.listFiles();
//            if (dataFiles != null) {
//                for (File file : dataFiles) {
//                    if (file.isFile() && !imageNamesStatus1.contains(file.getName()) && !imageNamesInDatabase.contains(file.getName())) {
//                        if (file.delete()) {
//                            System.out.println("已删除 /data 文件夹下找不到对应数据库记录的图片文件: " + file.getAbsolutePath());
//                        } else {
//                            System.out.println("无法删除 /data 文件夹下找不到对应数据库记录的图片文件: " + file.getAbsolutePath());
//                        }
//                    }
//                }
//            }

            return ResponseResult.okResult("服务器图片缓存清除成功");
        } else {
            return ResponseResult.errorResult(AppHttpCodeEnum.USAIMG_ERROR_CLEAN);
        }
    }
}

