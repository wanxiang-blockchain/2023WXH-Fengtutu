package com.bage.service;

import com.bage.domain.ResponseResult;
import com.bage.domain.dto.CreatCoArticleDto;
import com.bage.domain.dto.QueryFromOpenpidDto;
import com.bage.domain.entity.CoArticle;
import com.baomidou.mybatisplus.extension.service.IService;

public interface CoArticleService extends IService<CoArticle> {
    /**
     * 获取发布列表
     * **/
    ResponseResult getArticleList(QueryFromOpenpidDto queryFromOpenpidDto);
    /**
     * 添加新的发布内容
     * **/
    ResponseResult createNewCoArticle(CreatCoArticleDto coArticleDto);
    /**
     * 查询单个发布内容
     * **/
    ResponseResult queryOneCoArticle(Long articleId);
    /**
     * 删除单个发布内容（逻辑删除）
     * **/
    ResponseResult deleteCoArticle(Long articleId);
}
