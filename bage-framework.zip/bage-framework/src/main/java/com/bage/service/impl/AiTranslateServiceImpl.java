package com.bage.service.impl;

import com.bage.constants.SystemConstants;
import com.bage.domain.ResponseResult;
import com.bage.domain.entity.AIUser;
import com.bage.domain.entity.AiMessage;
import com.bage.domain.entity.AiTranslate;
import com.bage.mapper.AIUserMapper;
import com.bage.mapper.AiTranslateMapper;
import com.bage.service.AiTranslateService;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * (AiTranslate)表服务实现类
 *
 * @author makejava
 * @since 2023-06-13 17:31:16
 */
@Service("aiTranslateService")
public class AiTranslateServiceImpl extends ServiceImpl<AiTranslateMapper, AiTranslate> implements AiTranslateService {
    @Autowired
    private AiTranslateMapper aiTranslateMapper;

    @Override
    public ResponseResult getTranslate(AiTranslate translate) {
        LambdaQueryWrapper<AiTranslate> wrapper = new LambdaQueryWrapper<>();
//        wrapper.select(AiTranslate::getName,AiTranslate::getAppid,AiTranslate::getStaus,AiTranslate::getUsed,AiTranslate::getAppkey);//select定义了要查询哪些字段，这里定义了只查询id和name字段
        wrapper.eq(AiTranslate::getStaus, SystemConstants.OK);//select定义了要查询哪些字段，这里定义了只查询id和name字段
        List<AiTranslate> list = list(wrapper);
        return ResponseResult.okResult(list);
    }

    /**
     * 置换翻译额度（当翻译额度快用光时换另外一个翻译key）
     * */
    @Override
    public ResponseResult translationJudgment(AiTranslate translation) {
        LambdaQueryWrapper<AiTranslate> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(AiTranslate::getStaus, "1").eq(AiTranslate::getUsed, "1");
        AiTranslate aiTranslate = aiTranslateMapper.selectOne(wrapper);
        //表里记录的翻译长度
        int translationUseLengthOld = Integer.parseInt(aiTranslate.getTranslationuselength());
        //加长后的新的翻译长度
        int newTranslation = translation.getTranslationuselength().length()+translationUseLengthOld;
        //如果新的翻译长度大于90w则把状态used变成0，Staus变成0,再找一个新的可用的翻译把used、Staus变成1
        if(newTranslation>900000){
            aiTranslate.setStaus("0");
            aiTranslate.setUsed("0");
            aiTranslateMapper.updateById(aiTranslate);
            //找一个新的可用的翻译把used、staus变成1
            LambdaQueryWrapper<AiTranslate> wrapperNew = new LambdaQueryWrapper<>();
            wrapperNew.eq(AiTranslate::getStaus, "1").eq(AiTranslate::getUsed, "0");
            AiTranslate aiTranslateCanUse = aiTranslateMapper.selectOne(wrapperNew.last("LIMIT 1"));
            aiTranslateCanUse.setUsed("1");
            aiTranslateMapper.updateById(aiTranslateCanUse);
        }else{
            //否则直接更新表里的translationUseLength字段
            aiTranslate.setTranslationuselength(String.valueOf(newTranslation));
            aiTranslateMapper.updateById(aiTranslate);
        }
        return ResponseResult.okResult(true);
    }
}

