package com.bage.service.impl;

import com.bage.domain.ResponseResult;
import com.bage.domain.dto.TagListDto;
import com.bage.domain.entity.Tag;
import com.bage.domain.vo.PageVo;
import com.bage.domain.vo.TagVo;
import com.bage.mapper.TagMapper;
import com.bage.service.TagService;
import com.bage.utils.BeanCopyUtils;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

/**
 * 标签(Tag)表服务实现类
 *
 * @author makejava
 * @since 2022-12-26 22:36:15
 */
@Service("tagService")
public class TagServiceImpl extends ServiceImpl<TagMapper, Tag> implements TagService {

    //查询所有标签
    @Override
    public ResponseResult<PageVo> pageTagList(Integer pageNum, Integer pageSize, TagListDto tagListDto) {
        //分页查询
        LambdaQueryWrapper<Tag> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(StringUtils.hasText(tagListDto.getName()),Tag::getName,tagListDto.getName());//eq:等值匹配 标签类的name = 传入参数的name 条件是当dto中的name有值时，则使用这个name == name这个判断。否则这行筛选条件不生效
        queryWrapper.eq(StringUtils.hasText(tagListDto.getRemark()),Tag::getRemark,tagListDto.getRemark());

        Page<Tag> page = new Page<>();
        page.setCurrent(pageNum);
        page.setSize(pageSize);
        page(page, queryWrapper);
        //封装数据返回
        PageVo pageVo = new PageVo(page.getRecords(),page.getTotal()); //第一个参数：数据集合 第二个参数 total
        return ResponseResult.okResult(pageVo);
    }
    //新增标签
    @Override
    public ResponseResult addTag(Tag tag) {
        save(tag);
        return ResponseResult.okResult();
    }
    //删除标签
    @Override
    public ResponseResult removeTag(Long id) {
        removeById(id);//根据id进行逻辑删除
        return ResponseResult.okResult();
    }
    //更新标签
    @Override
    public ResponseResult updateTag(Tag tag) {
        updateById(tag);
        return ResponseResult.okResult();
    }
    //获取标签详情
    @Override
    public ResponseResult getTagInfo(Long id) {
        Tag tag = getById(id);
        return ResponseResult.okResult(tag);
    }
    //查询所有标签
    @Override
    public List<TagVo> listAllTag() {
        LambdaQueryWrapper<Tag> wrapper = new LambdaQueryWrapper<>();
        wrapper.select(Tag::getId,Tag::getName);//select定义了要查询哪些字段，这里定义了只查询id和name字段
        List<Tag> list = list(wrapper);
        List<TagVo> tagVos = BeanCopyUtils.copyBeanList(list, TagVo.class);
        return tagVos;
    }
}

