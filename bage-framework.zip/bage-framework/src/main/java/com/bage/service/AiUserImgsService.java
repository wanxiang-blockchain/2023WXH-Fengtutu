package com.bage.service;

import com.bage.domain.ResponseResult;
import com.bage.domain.dto.AiUserImgsDto;
import com.bage.domain.entity.AiUserImgs;
import com.baomidou.mybatisplus.extension.service.IService;


/**
 * (AiUserImgs)表服务接口
 *
 * @author makejava
 * @since 2023-07-29 14:34:57
 */
public interface AiUserImgsService extends IService<AiUserImgs> {
    /**
     * 将用户生成的图片存入数据库
     * */
    void setUserImgs(AiUserImgs aiUserImgs);
    /**
     * 获取用户图片列表
     * */
    ResponseResult aiUserImgsList(Integer pageNum, Integer pageSize, AiUserImgsDto aiUserImgs);
    /**
     * 用户图片状态修改
     * **/
    ResponseResult aiChangeUserImgStatus(AiUserImgsDto aiUserImgs);
    /**
     * 主动执行删除服务器里的未保存的图片接口
     * **/
    ResponseResult aiDiskSpaceChecker(AiUserImgsDto aiUserImgs);
}

