package com.bage.service.impl;
import com.bage.domain.ResponseResult;
import com.bage.domain.dto.RemoveCoAlbumImgsDto;
import com.bage.domain.entity.*;
import com.bage.enums.AppHttpCodeEnum;
import com.bage.exception.SystemException;
import com.bage.mapper.CoAlbumImgsMapper;
import com.bage.mapper.CoAlbumMapper;
import com.bage.service.CoAlbumImgsService;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.util.List;

/**
 * (CoAlbumImgs)表服务实现类
 *
 * @author makejava
 * @since 2023-08-29 16:55:08
 */
@Service("coAlbumImgsService")
public class CoAlbumImgsServiceImpl extends ServiceImpl<CoAlbumImgsMapper, CoAlbumImgs> implements CoAlbumImgsService {
    @Autowired
    private CoAlbumImgsMapper coAlbumImgsMapper;
    /**
     * 用户添加画册图片（批量）
     * **/
    @Override
    public ResponseResult addCoAlbumImgs(List<CoAlbumImgs> coAlbumImgs) {
        for (CoAlbumImgs imgItem : coAlbumImgs) {
            //TODO 判断不能为空
//            if(!StringUtils.hasText(coAlbum.getTitle())){
//                throw new SystemException(AppHttpCodeEnum.CONTENT_NOT_NULL);//抛出异常
//            }
            //TODO 判断本地生成还是手机上传

            //添加数据库
            save(imgItem);
        }

        return ResponseResult.okResult();
    }
    /**
     * 批量删除图片（逻辑删除）
     * **/
    @Override
    public ResponseResult deleteCoAlbumImgs(List<Integer> ids) {
        for (Integer id : ids) {
            LambdaQueryWrapper<CoAlbumImgs> queryWrapper = new LambdaQueryWrapper<>();
            queryWrapper.eq(CoAlbumImgs::getId, id);
            CoAlbumImgs oneAlbumImg = coAlbumImgsMapper.selectOne(queryWrapper);
            oneAlbumImg.setImgStatus(0);
            coAlbumImgsMapper.updateById(oneAlbumImg);
        }
        return ResponseResult.okResult();
    }
    /**
     * 图片移动（批量）
     * **/
    @Override
    public ResponseResult removeCoAlbumImgs(RemoveCoAlbumImgsDto removeCoAlbumImgsDto) {
        for (Integer id : removeCoAlbumImgsDto.getIds()) {
            LambdaQueryWrapper<CoAlbumImgs> queryWrapper = new LambdaQueryWrapper<>();
            queryWrapper.eq(CoAlbumImgs::getId, id);
            CoAlbumImgs oneAlbumImg = coAlbumImgsMapper.selectOne(queryWrapper);
            oneAlbumImg.setAlbumId(removeCoAlbumImgsDto.getAlbumId());
            coAlbumImgsMapper.updateById(oneAlbumImg);
        }
        return ResponseResult.okResult();
    }
}
