package com.bage.service.impl;

import com.bage.domain.ResponseResult;
import com.bage.domain.entity.AiModel;
import com.bage.service.AiSpeedConfigService;
import com.bage.domain.entity.AiSpeedConfig;
import com.bage.mapper.AiSpeedConfigMapper;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 快捷生图的相关配置(AiSpeedConfig)表服务实现类
 *
 * @author makejava
 * @since 2023-06-15 21:49:07
 */
@Service("aiSpeedConfigService")
public class AiSpeedConfigServiceImpl extends ServiceImpl<AiSpeedConfigMapper, AiSpeedConfig> implements AiSpeedConfigService {
    @Override
    public ResponseResult getSpeedConf(String token) {
        List<AiSpeedConfig> list = null;
        if (true) {
            LambdaQueryWrapper<AiSpeedConfig> wrapper = new LambdaQueryWrapper<>();
            wrapper.select(AiSpeedConfig::getName,AiSpeedConfig::getTag,AiSpeedConfig::getCfg,AiSpeedConfig::getModel,AiSpeedConfig::getType,AiSpeedConfig::getSampling);//select定义了要查询哪些字段，这里定义了只查询id和name字段
            list = list(wrapper);
        }
        return ResponseResult.okResult(list);
    }
}

