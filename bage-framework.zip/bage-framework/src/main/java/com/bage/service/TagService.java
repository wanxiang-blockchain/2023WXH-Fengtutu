package com.bage.service;

import com.bage.domain.ResponseResult;
import com.bage.domain.dto.TagListDto;
import com.bage.domain.entity.Tag;
import com.bage.domain.vo.PageVo;
import com.bage.domain.vo.TagVo;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;


/**
 * 标签(Tag)表服务接口
 *
 * @author makejava
 * @since 2022-12-26 22:36:14
 */
public interface TagService extends IService<Tag> {
    //查询标签列表
    ResponseResult<PageVo> pageTagList(Integer pageNum, Integer pageSize, TagListDto tagListDto);
    //新增标签
    ResponseResult addTag(Tag tag);
    //删除标签
    ResponseResult removeTag(Long id);
    //更新标签
    ResponseResult updateTag(Tag tag);
    //获取标签详情
    ResponseResult getTagInfo(Long id);
    //查询所有标签
    List<TagVo> listAllTag();
}

