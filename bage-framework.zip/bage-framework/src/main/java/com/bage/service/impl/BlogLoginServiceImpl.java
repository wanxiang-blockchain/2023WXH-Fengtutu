package com.bage.service.impl;

import com.bage.domain.ResponseResult;
import com.bage.domain.entity.LoginUser;
import com.bage.domain.entity.User;
import com.bage.domain.entity.UserInfoVo;
import com.bage.domain.vo.BlogUserLoginVo;
import com.bage.service.BlogLoginService;
import com.bage.utils.BeanCopyUtils;
import com.bage.utils.JwtUtil;
import com.bage.utils.RedisCache;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Service//要注入容器所以加这个注解
public class BlogLoginServiceImpl implements BlogLoginService {//此类要实现BlogLoginService，所以implements BlogLoginService

    @Autowired
    private AuthenticationManager authenticationManager;//把authenticationManager注入到容器中，但是需要我们自己重写方法。该方法写在bage-blog，bage-blog/src/main/java/com/bage/config/SecurityConfig.java里，因为前台的登录配置文件只有前台需要

    @Autowired
    private RedisCache redisCache;//因为RedisCache工具类加了Component注解所以直接注入就可以了

    @Override
    public ResponseResult login(User user) {
        UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(user.getUserName(),user.getPassword());
        //这里使用我们自己重写的方法会返回查到的用户信息（！很长的逻辑，可以好好看看，在第33课）
        Authentication authenticate = authenticationManager.authenticate(authenticationToken);//实际上authenticationManager最终会调用userDetailService去进行用户认证，但是默认UserDetailService是从内存中认证的，但是我们要的是从数据库中user表进行查询认证的，所以我们要重新创建UserDetailService的实现类。因为我们查的是同一个库同一个表，所以就把这个文件放在bage-framework下了
        //判断是否认证通过
        if(Objects.isNull(authenticate)){
            throw new RuntimeException("用户名或密码错误");
        }
        //获取userid 生成token
        LoginUser loginUser = (LoginUser) authenticate.getPrincipal();//authenticate.getPrincipal()是我们返回的的主体，把它强转成loginUser，不懂得话可以打断点看里面的属性，看哪个是loginUser类型，不用特意记
        String userId = loginUser.getUser().getId().toString();//因为JwtUtil工具类接收的String类型，所以我们把userId转换成string类型
        String jwt = JwtUtil.createJWT(userId);//jwt的工具类生成token
        //把用户信息存入redis
        redisCache.setCacheObject("bloglogin:"+userId,loginUser);//key为bloglogin:id 要存的对象为loginUser

        //把token和userinfo封装 返回
        //把User转换成UserInfoVo，拿到UserInfoVo   因为我们接口要的返回格式有userInfo和token，所以我们要用VO转一下，这里面userInfo也可以创建一个VO，和ts同理
        UserInfoVo userInfoVo = BeanCopyUtils.copyBean(loginUser.getUser(), UserInfoVo.class);
        //BlogUserLoginVo里面有userInfo和token两个字段，但是里面的属性要付值，一个是token，一个是userInfo，token就是jwt，userInfo就是userInfoVo
        BlogUserLoginVo vo = new BlogUserLoginVo(jwt,userInfoVo);
        return ResponseResult.okResult(vo);
    }

    @Override
    public ResponseResult logout() {
        //获取token 解析获取userid
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        LoginUser loginUser = (LoginUser) authentication.getPrincipal();
        //获取userid
        Long userId = loginUser.getUser().getId();
        //删除redis中的用户信息
        redisCache.deleteObject("bloglogin:"+userId);
        return ResponseResult.okResult();
    }
}
