package com.bage.service;

import com.bage.domain.ResponseResult;
import com.bage.domain.entity.AiModel;
import com.baomidou.mybatisplus.extension.service.IService;


/**
 * (AiModel)表服务接口
 *
 * @author makejava
 * @since 2023-06-15 20:43:17
 */
public interface AiModelService extends IService<AiModel> {

    ResponseResult getModelList(String token);
}

