package com.bage.service;

import com.bage.domain.ResponseResult;
import com.bage.domain.entity.AiTranslate;
import com.baomidou.mybatisplus.extension.service.IService;


/**
 * (AiTranslate)表服务接口
 *
 * @author makejava
 * @since 2023-06-13 17:31:16
 */
public interface AiTranslateService extends IService<AiTranslate> {

    ResponseResult getTranslate(AiTranslate translate);

    ResponseResult translationJudgment(AiTranslate translate);
}

