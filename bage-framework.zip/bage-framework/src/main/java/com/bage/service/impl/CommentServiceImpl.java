package com.bage.service.impl;

import com.bage.constants.SystemConstants;
import com.bage.domain.ResponseResult;
import com.bage.domain.entity.Comment;
import com.bage.domain.vo.CommentVo;
import com.bage.domain.vo.PageVo;
import com.bage.enums.AppHttpCodeEnum;
import com.bage.exception.SystemException;
import com.bage.mapper.CommentMapper;
import com.bage.service.CommentService;
import com.bage.service.UserService;
import com.bage.utils.BeanCopyUtils;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;

/**
 * 评论表(Comment)表服务实现类
 *
 * @author makejava
 * @since 2022-12-20 21:38:40
 */
@Service("commentService")
public class CommentServiceImpl extends ServiceImpl<CommentMapper, Comment> implements CommentService {

    @Autowired
    private UserService userService;

    @Override
    public ResponseResult commentList(String commentType, Long articleId, Integer pageNum, Integer pageSize) {
        //查询对应文章的根评论
        LambdaQueryWrapper<Comment> queryWrapper = new LambdaQueryWrapper<>();
        //对articleId进行判断
        queryWrapper.eq(SystemConstants.ARTICLE_COMMENT.equals(commentType),Comment::getArticleId,articleId);//针对Comment中的ArticleId字段，具体值为传入的articleId   如果SystemConstants.ARTICLE_COMMENT.equals(commentType)为true才会加上这个条件【也就是只有当查询类型为文章列表commentType=0时，这句eq查询条件才生效】
        //根评论 rootId为-1
        queryWrapper.eq(Comment::getRootId,-1);

        //评论类型
        queryWrapper.eq(Comment::getType,commentType);

        //分页查询
        Page<Comment> page = new Page(pageNum,pageSize);
        page(page,queryWrapper);//当前页的评论数据

        List<CommentVo> commentVoList = toCommentVoList(page.getRecords());

        //查询所有根评论对应的子评论集合，并且赋值给对应的属性
        for (CommentVo commentVo : commentVoList) {//遍历VO
            //查询对应的子评论
            List<CommentVo> children = getChildren(commentVo.getId());//根评论id相等即可以查到对应的子评论
            //赋值给commentVo里面的children
            commentVo.setChildren(children);
        }


        return ResponseResult.okResult(new PageVo(commentVoList,page.getTotal()));
    }

    @Override
    public ResponseResult addComment(Comment comment) {
        //评论内容不能为空
        if(!StringUtils.hasText(comment.getContent())){
            throw new SystemException(AppHttpCodeEnum.CONTENT_NOT_NULL);//抛出异常
        }
        //将数据插入数据库 注意：这里因为我们定义了全局的mybatisplus这个公共方法，所以我们在使用mybatisplus的save方法时会自动帮我们插入我们在类中自定义的字段，比如createBy等，具体可以看MyMetaObjectHandler.java这个文件
        save(comment);
        return ResponseResult.okResult();
    }

    /**
     * 根据根评论的id查询所对应的子评论的集合，并且返回的要是VO的list的集合
     * @param id 根评论的id
     * @return
     */
    private List<CommentVo> getChildren(Long id) {

        LambdaQueryWrapper<Comment> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(Comment::getRootId,id);
        queryWrapper.orderByAsc(Comment::getCreateTime);//子评论根据创建时间进行排序
        List<Comment> comments = list(queryWrapper);

        List<CommentVo> commentVos = toCommentVoList(comments);
        return commentVos;
    }

    //将Comment集合转换成CommentVo集合
    private List<CommentVo> toCommentVoList(List<Comment> list){
        //因为BeanCopyUtils拷贝了我们大部分字段，但是nickName是CommentVo也就是表里面是没有的，所以这里这里我们需要自己查出来并塞入CommentVo
        List<CommentVo> commentVos = BeanCopyUtils.copyBeanList(list, CommentVo.class);
        //遍历vo集合
        for (CommentVo commentVo : commentVos) {
            //通过creatyBy查询用户的昵称并赋值
            String nickName = userService.getById(commentVo.getCreateBy()).getNickName();
            commentVo.setUsername(nickName);
            //通过toCommentUserId查询用户的昵称并赋值
            //如果toCommentUserId不为-1才进行查询（证明他确实是回复了某条评论的，是有对方的用户id的）
            if(commentVo.getToCommentUserId()!=-1){
                String toCommentUserName = userService.getById(commentVo.getToCommentUserId()).getNickName();
                commentVo.setToCommentUserName(toCommentUserName);
            }
        }
        return commentVos;
    }
}

