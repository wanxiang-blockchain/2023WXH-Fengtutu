package com.bage.service;

import com.bage.domain.ResponseResult;
import com.bage.domain.entity.AiMessage;
import com.baomidou.mybatisplus.extension.service.IService;


/**
 * 各个页面的消息(AiMessage)表服务接口
 *
 * @author makejava
 * @since 2023-06-13 16:45:27
 */
public interface AiMessageService extends IService<AiMessage> {

    ResponseResult getMessage(AiMessage message);
}

