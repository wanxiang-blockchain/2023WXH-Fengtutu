package com.bage.service.impl;
/*
* 实现UserDetailsService进行用户校验，重写了security默认的方法
* */
import com.bage.constants.SystemConstants;
import com.bage.domain.entity.LoginUser;
import com.bage.mapper.MenuMapper;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.bage.domain.entity.User;
import com.bage.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

@Service//注入容器实现替换security的用户校验
public class UserDetailsServiceImpl implements UserDetailsService {

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private MenuMapper menuMapper;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        //根据用户名查询用户信息
        LambdaQueryWrapper<User> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(User::getUserName,username);
        User user = userMapper.selectOne(queryWrapper);
        //判断是否查到用户  如果没查到抛出异常
        if(Objects.isNull(user)){
            throw new RuntimeException("用户不存在");
        }
        //返回用户信息
        if(user.getType().equals(SystemConstants.ADMAIN)){//判断是否是后台管理系统的用户
            List<String> list = menuMapper.selectPermsByUserId(user.getId());//拿到权限list集合
            return new LoginUser(user,list);//将用户信息user和权限list数据封装到LoginUser当中，需要在LoginUser中增加全员变量permissions才能这样使用
        }
        return new LoginUser(user,null);//如果不是后台管理系统的用户只会有user传进去，没有权限
    }
}
