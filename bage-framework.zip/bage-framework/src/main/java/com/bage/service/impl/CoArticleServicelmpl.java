package com.bage.service.impl;

import com.bage.domain.ResponseResult;
import com.bage.domain.dto.CreatCoArticleDto;
import com.bage.domain.dto.QueryFromOpenpidDto;
import com.bage.domain.entity.*;
import com.bage.domain.vo.PageVo;
import com.bage.mapper.CoArticleMapper;
import com.bage.mapper.CoPraiseMapper;
import com.bage.mapper.CommunityCommentMapper;
import com.bage.service.CoArticleService;
import com.bage.service.CoPraiseService;
import com.bage.service.CommunityCommentService;
import com.bage.utils.BeanCopyUtils;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.util.List;

@Service("coArticleService")
public class CoArticleServicelmpl extends ServiceImpl<CoArticleMapper, CoArticle> implements CoArticleService {
    @Autowired
    private CoArticleMapper coArticleMapper;
    @Autowired
    private CommunityCommentMapper communityCommentMapper;
    @Resource
    private CoPraiseMapper coPraiseMapper;
    @Resource
    private CommunityCommentService communityCommentService;
    @Resource
    private CoPraiseService coPraiseService;
    /**
     * 获取发布列表
     * **/
    @Override
    public ResponseResult getArticleList(QueryFromOpenpidDto queryFromOpenpidDto) {
        LambdaQueryWrapper<CoArticle> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(CoArticle::getDel, "0");
        if(!StringUtils.hasText(queryFromOpenpidDto.getOpenpid())){
            queryWrapper.eq(CoArticle::getCreateBy, queryFromOpenpidDto.getOpenpid());
        }
        //做统计
        List<CoArticle> coArticleList = coArticleMapper.selectList(queryWrapper);
        for (CoArticle articleItem : coArticleList) {
            //统计评论数
            LambdaQueryWrapper<CommunityComment> queryCoCommentWrapper = new LambdaQueryWrapper<>();
            queryCoCommentWrapper.eq(CommunityComment::getArticleId, articleItem.getId());
            List<CommunityComment> coCommentList = communityCommentMapper.selectList(queryCoCommentWrapper);
            articleItem.setCommentCount((long) coCommentList.size());
            //统计点赞数
            LambdaQueryWrapper<CoPraise> queryCoPraiseWrapper = new LambdaQueryWrapper<>();
            queryCoPraiseWrapper.eq(CoPraise::getArticleId, articleItem.getId());
            List<CoPraise> coPraiseList = coPraiseMapper.selectList(queryCoPraiseWrapper);
            articleItem.setPraiseCount((long) coPraiseList.size());
        }
        //分页查询
        Page<CoArticle> page = new Page<>(queryFromOpenpidDto.getPageNum(),queryFromOpenpidDto.getPageSize());
        page(page,queryWrapper);
//        List<CoArticle> pageList = page.getRecords();
        //封装查询结果
        List<CoArticle> coArticleListVos = BeanCopyUtils.copyBeanList(page.getRecords(), CoArticle.class);//当前获取到的值为data:[]，不满足前端要求的数据格式
        PageVo pageVo = new PageVo(coArticleListVos,page.getTotal());//两个属性分别为rows和total，这样封装出来的格式就是data:{rows:[],total:0}
        return ResponseResult.okResult(pageVo);
    }

    /**
     * 添加新的发布内容
     * **/
    @Override
    public ResponseResult createNewCoArticle(CreatCoArticleDto coArticleDto) {
//        LambdaQueryWrapper<CoArticle> queryWrapper = new LambdaQueryWrapper<>();
//        List<CoArticle> coArticleList = coArticleMapper.selectList(queryWrapper);
//        return null;
        CoArticle coArticle = BeanCopyUtils.copyBean(coArticleDto, CoArticle.class);//把articleDto拷贝成Article（因为下面的方法要的是Article类型）
        save(coArticle);//插入到article表里面（因为这个方法是直接写在ArticleServiceImpl.java下，所以直接调用save就是存在article表里）
        //注意：当mybatisplus执行完插入操作后会把最新的这条记录的id赋值给你传进来这条对象的id属性，所以如果想获取刚刚插入的这条的id只要调用article对象的getId方法即可

//        List<ArticleTag> articleTags = coArticleDto.getTags().stream()//转换成stream流
//                .map(tagId -> new ArticleTag(article.getId(), tagId))//把标签id转换成ArticleTag对象。映射完后都是ArticleTag了
//                .collect(Collectors.toList());//把上面映射完的ArticleTag收集成list集合

        //添加 博客和标签的关联
//        articleTagService.saveBatch(articleTags);
        return ResponseResult.okResult();
    }
    /**
     * 查询单个发布内容
     * **/
    @Override
    public ResponseResult queryOneCoArticle(Long articleId) {
        LambdaQueryWrapper<CoArticle> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(CoArticle::getId, articleId);
        CoArticle oneCoArticle = coArticleMapper.selectOne(queryWrapper);
        return ResponseResult.okResult(oneCoArticle);
    }
    /**
     * 删除单个发布内容（逻辑删除）
     * **/
    @Override
    public ResponseResult deleteCoArticle(Long articleId) {
        LambdaQueryWrapper<CoArticle> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(CoArticle::getId, articleId);
        CoArticle oneCoArticle = coArticleMapper.selectOne(queryWrapper);
        oneCoArticle.setDel("1");
        coArticleMapper.updateById(oneCoArticle);
        //删除对应的文章的所有评论
        LambdaQueryWrapper<CommunityComment> queryCommentWrapper = new LambdaQueryWrapper<>();
        queryCommentWrapper.eq(CommunityComment::getArticleId, articleId);
        List<CommunityComment> coCommentList = communityCommentMapper.selectList(queryCommentWrapper);
        coCommentList.forEach(item -> {
            communityCommentService.delCommunityComment(item.getId());
        });
        //删除文章对应的点赞
        List<CoPraise> coPraiseList = coPraiseService.getPraiseList("articleId", oneCoArticle.getId());
        coPraiseList.forEach(item -> {
            coPraiseService.delCoPraise(item.getId());
        });
        return ResponseResult.okResult();
    }
}
