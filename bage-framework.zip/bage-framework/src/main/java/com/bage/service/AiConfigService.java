package com.bage.service;

import com.bage.domain.ResponseResult;
import com.bage.domain.entity.AiConfig;
import com.baomidou.mybatisplus.extension.service.IService;


/**
 * (AiConfig)表服务接口
 *
 * @author makejava
 * @since 2023-08-22 22:22:02
 */
public interface AiConfigService extends IService<AiConfig> {

}
