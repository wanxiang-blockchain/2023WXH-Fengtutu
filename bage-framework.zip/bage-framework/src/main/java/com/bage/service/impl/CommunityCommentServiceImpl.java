package com.bage.service.impl;

import com.bage.domain.ResponseResult;
import com.bage.domain.entity.CommunityComment;
import com.bage.enums.AppHttpCodeEnum;
import com.bage.exception.SystemException;
import com.bage.mapper.CommunityCommentMapper;
import com.bage.service.CommunityCommentService;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * (CommunityComment)表服务实现类
 *
 * @author makejava
 * @since 2023-08-23 18:05:31
 */
@Service("communityCommentService")
public class CommunityCommentServiceImpl extends ServiceImpl<CommunityCommentMapper, CommunityComment> implements CommunityCommentService {
    @Resource
    private CommunityCommentMapper communityCommentMapper;
    /**
     * 删除评论（逻辑删除）
     * **/
    @Override
    public ResponseResult delCommunityComment(Long id) {
        LambdaQueryWrapper<CommunityComment> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(CommunityComment::getId, id);
        CommunityComment oneCommunityComment = communityCommentMapper.selectOne(queryWrapper);
        oneCommunityComment.setDel("1");
        communityCommentMapper.updateById(oneCommunityComment);
        if(oneCommunityComment.getRootId() == -1){
            //如果等于-1，则是文章的根评论，要删掉根评论以及根评论的所有子评论
            LambdaQueryWrapper<CommunityComment> delList = new LambdaQueryWrapper<>();
            delList.eq(CommunityComment::getRootId, id);
            List<CommunityComment> coCommentList = communityCommentMapper.selectList(delList);
            coCommentList.forEach(item -> {
                item.setDel("1");
                communityCommentMapper.updateById(item);
            });

        }
        return ResponseResult.okResult();
    }

    /**
     * 通过文章id获取评论列表（结构化）
     * **/
    @Override
    public ResponseResult getCoCommentListById(Long id) {
        LambdaQueryWrapper<CommunityComment> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(CommunityComment::getDel, "0");
        queryWrapper.eq(CommunityComment::getArticleId, id);
        List<CommunityComment> coCommentList = communityCommentMapper.selectList(queryWrapper);
        List<CommunityComment> parentCommentList = new ArrayList<>();
        coCommentList.forEach(item -> {
            if(item.getRootId() == -1){
                parentCommentList.add(item);
            };
        });
        parentCommentList.forEach(item -> {
            List<CommunityComment> childrenCommentList = new ArrayList<>();
            coCommentList.forEach(data -> {
                if(Objects.equals(data.getRootId(), item.getId())){
                    childrenCommentList.add(data);
                };
            });
            item.setChildren(childrenCommentList);
        });
        return ResponseResult.okResult(parentCommentList);
    }
    /**
     * 新增评论
     * **/
    @Override
    public ResponseResult addCommunityComment(CommunityComment coComment) {
        //评论内容不能为空
        if(!StringUtils.hasText(coComment.getContent())){
            throw new SystemException(AppHttpCodeEnum.CONTENT_NOT_NULL);//抛出异常
        }
        //将数据插入数据库 注意：这里因为我们定义了全局的mybatisplus这个公共方法，所以我们在使用mybatisplus的save方法时会自动帮我们插入我们在类中自定义的字段，比如createBy等，具体可以看MyMetaObjectHandler.java这个文件
        save(coComment);
        return ResponseResult.okResult();
    }
}
