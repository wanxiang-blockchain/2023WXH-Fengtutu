package com.bage.service;
/**
* 登录登出
* */
import com.bage.domain.ResponseResult;
import com.bage.domain.entity.User;

public interface LoginService {
    ResponseResult login(User user);

    ResponseResult logout();
}
