package com.bage.service.impl;

import com.bage.domain.ResponseResult;
import com.bage.service.AiConfigService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.bage.mapper.AiConfigMapper;
import com.bage.domain.entity.AiConfig;
import org.springframework.stereotype.Service;

/**
 * (AiConfig)表服务实现类
 *
 * @author makejava
 * @since 2023-08-22 22:22:03
 */
@Service("aiConfigService")
public class AiConfigServiceImpl extends ServiceImpl<AiConfigMapper, AiConfig> implements AiConfigService {


}
