package com.bage.service;

import com.bage.domain.ResponseResult;
import com.bage.domain.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;


/**
 * 用户表(User)表服务接口
 *
 * @author makejava
 * @since 2022-12-20 22:46:08
 */
public interface UserService extends IService<User> {

    ResponseResult userInfo();

    //更新用户信息
    ResponseResult updateUserInfo(User user);

    ResponseResult register(User user);
    //获取用户列表
    ResponseResult selectUserPage(User user, Integer pageNum, Integer pageSize);
    //检查用户名称唯一性
    boolean checkUserNameUnique(String userName);
    //检查手机号唯一性
    boolean checkPhoneUnique(User user);
    //检查邮箱唯一性
    boolean checkEmailUnique(User user);
    //新增用户
    ResponseResult addUser(User user);
    //修改用户
    void updateUser(User user);
}

