package com.bage.service;

import com.bage.domain.ResponseResult;
import com.bage.domain.entity.AiSpeedConfig;
import com.baomidou.mybatisplus.extension.service.IService;


/**
 * 快捷生图的相关配置(AiSpeedConfig)表服务接口
 *
 * @author makejava
 * @since 2023-06-15 21:49:07
 */
public interface AiSpeedConfigService extends IService<AiSpeedConfig> {

    ResponseResult getSpeedConf(String token);
}

