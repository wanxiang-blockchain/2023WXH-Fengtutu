package com.bage.service.impl;

import com.bage.domain.ResponseResult;
import com.bage.domain.entity.AIUser;
import com.bage.domain.entity.AiModel;
import com.bage.service.AiModelService;
import com.bage.mapper.AiModelMapper;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * (AiModel)表服务实现类
 *
 * @author makejava
 * @since 2023-06-15 20:43:18
 */
@Service("aiModelService")
public class AiModelServiceImpl extends ServiceImpl<AiModelMapper, AiModel> implements AiModelService {

    @Override
    public ResponseResult getModelList(String token) {
        List<AiModel> list = null;
        if (true) {
            LambdaQueryWrapper<AiModel> wrapper = new LambdaQueryWrapper<>();
            wrapper.select(AiModel::getName,AiModel::getValue);//select定义了要查询哪些字段，这里定义了只查询id和name字段
             list = list(wrapper);
        }
        return ResponseResult.okResult(list);
    }
    //判断用户名是否存在
//    private boolean userNameExist(String userName) {
//        LambdaQueryWrapper<AIUser> queryWrapper = new LambdaQueryWrapper<>();
//        queryWrapper.eq(AIUser::getUserName,userName);
//        return count(queryWrapper)>0;
//    }
}

