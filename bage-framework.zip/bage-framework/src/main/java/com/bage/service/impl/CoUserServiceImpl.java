package com.bage.service.impl;

import com.bage.domain.ResponseResult;
import com.bage.domain.entity.AIUser;
import com.bage.domain.entity.CoUser;
import com.bage.mapper.AIUserMapper;
import com.bage.service.CoUserService;
import com.bage.utils.JwtUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.jsonwebtoken.Claims;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.bage.mapper.CoUserMapper;

/**
 * (CoUser)表服务实现类
 *
 * @author makejava
 * @since 2023-08-16 19:53:18
 */
@Service("coUserService")
public class CoUserServiceImpl extends ServiceImpl<CoUserMapper, CoUser> implements CoUserService {

    @Autowired
    private CoUserMapper coUserMapper;
    /**
     * 获取用户默认标签设置
     * **/
    @Override
    public ResponseResult defaultTagUpdate(CoUser user) {
        //根据user_name查询用户
        LambdaQueryWrapper<CoUser> queryWrapper = new LambdaQueryWrapper<>();
        String id = user.getUserName();
        Claims claims = null;
        try {
            claims = JwtUtil.parseJWT(id);
        } catch (Exception e) {
            e.printStackTrace();
            //token超时  token非法
            //响应告诉前端需要重新登录
        }
        String userId = claims.getSubject();
        queryWrapper.eq(CoUser::getUserName,userId );
        CoUser aIUser = coUserMapper.selectOne(queryWrapper);
        aIUser.setDefaultTag(user.getDefaultTag());
        aIUser.setNegativeTag(user.getNegativeTag());
        coUserMapper.updateById(aIUser);
        return ResponseResult.okResult(aIUser);
    }
}

