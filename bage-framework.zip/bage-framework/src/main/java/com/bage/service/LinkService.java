package com.bage.service;

import com.bage.domain.ResponseResult;
import com.bage.domain.entity.Link;
import com.bage.domain.vo.PageVo;
import com.baomidou.mybatisplus.extension.service.IService;


/**
 * 友链(Link)表服务接口
 *
 * @author makejava
 * @since 2022-12-04 20:06:55
 */
public interface LinkService extends IService<Link> {

    ResponseResult getAllLink();
    //分页获取友链列表
    PageVo selectLinkPage(Link link, Integer pageNum, Integer pageSize);
}

