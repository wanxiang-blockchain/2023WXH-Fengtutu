package com.bage.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bage.domain.entity.UserRole;

/**
 * 用户角色
 */
public interface UserRoleMapper extends BaseMapper<UserRole> {
}