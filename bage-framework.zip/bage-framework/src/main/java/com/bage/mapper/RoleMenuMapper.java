package com.bage.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bage.domain.entity.RoleMenu;

/**
 * 角色菜单
 */
public interface RoleMenuMapper extends BaseMapper<RoleMenu> {
}
