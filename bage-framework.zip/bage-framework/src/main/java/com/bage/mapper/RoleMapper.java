package com.bage.mapper;

import com.bage.domain.entity.Role;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.List;


/**
 * 角色信息表(Role)表数据库访问层
 *
 * @author makejava
 * @since 2022-12-28 22:24:40
 */
public interface RoleMapper extends BaseMapper<Role> {
    //查询用户所具有的角色信息
    List<String> selectRoleKeyByUserId(Long id);//在RoleMapper.xml里实现具体自定义sql
    //当前用户所具有的角色id列表
    List<Long> selectRoleIdByUserId(Long userId);//在RoleMapper.xml里实现具体自定义sql
}

