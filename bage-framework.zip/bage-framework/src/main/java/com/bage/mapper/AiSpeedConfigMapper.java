package com.bage.mapper;

import com.bage.domain.entity.AiSpeedConfig;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


/**
 * 快捷生图的相关配置(AiSpeedConfig)表数据库访问层
 *
 * @author makejava
 * @since 2023-06-15 21:49:07
 */
public interface AiSpeedConfigMapper extends BaseMapper<AiSpeedConfig> {

}

