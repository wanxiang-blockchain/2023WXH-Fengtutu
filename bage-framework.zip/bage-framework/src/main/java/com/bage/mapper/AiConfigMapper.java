package com.bage.mapper;

import com.bage.domain.entity.AiConfig;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.stereotype.Repository;


/**
 * (AiConfig)表数据库访问层
 *
 * @author makejava
 * @since 2023-08-22 22:22:01
 */
@Repository
public interface AiConfigMapper extends BaseMapper<AiConfig> {

}
