package com.bage.mapper;

import com.bage.domain.entity.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


/**
 * 用户表(User)表数据库访问层
 *
 * @author makejava
 * @since 2022-12-04 21:53:44
 */
public interface UserMapper extends BaseMapper<User> {

}

