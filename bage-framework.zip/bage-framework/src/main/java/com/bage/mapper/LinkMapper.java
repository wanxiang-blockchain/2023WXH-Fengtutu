package com.bage.mapper;

import com.bage.domain.entity.Link;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


/**
 * 友链(Link)表数据库访问层
 *
 * @author makejava
 * @since 2022-12-04 20:06:49
 */
public interface LinkMapper extends BaseMapper<Link> {

}

