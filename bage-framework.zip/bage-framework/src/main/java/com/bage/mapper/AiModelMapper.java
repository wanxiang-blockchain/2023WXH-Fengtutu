package com.bage.mapper;

import com.bage.domain.entity.AiModel;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


/**
 * (AiModel)表数据库访问层
 *
 * @author makejava
 * @since 2023-06-15 20:43:17
 */
public interface AiModelMapper extends BaseMapper<AiModel> {

}

