package com.bage.mapper;

import com.bage.domain.entity.AiTranslate;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.stereotype.Repository;


/**
 * (AiTranslate)表数据库访问层
 *
 * @author makejava
 * @since 2023-06-13 17:31:16
 */
@Repository
public interface AiTranslateMapper extends BaseMapper<AiTranslate> {

}

