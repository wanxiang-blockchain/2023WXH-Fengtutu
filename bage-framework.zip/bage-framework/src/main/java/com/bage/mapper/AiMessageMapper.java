package com.bage.mapper;

import com.bage.domain.entity.AiMessage;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;


/**
 * 各个页面的消息(AiMessage)表数据库访问层
 *
 * @author makejava
 * @since 2023-06-13 16:45:24
 */
public interface AiMessageMapper extends BaseMapper<AiMessage> {

}

