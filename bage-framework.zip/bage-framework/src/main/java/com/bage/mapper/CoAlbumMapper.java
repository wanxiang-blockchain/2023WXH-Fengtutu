package com.bage.mapper;

import com.bage.domain.entity.CoAlbum;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.stereotype.Repository;


/**
 * 画册表(CoAlbum)表数据库访问层
 *
 * @author makejava
 * @since 2023-08-28 17:09:30
 */
@Repository
public interface CoAlbumMapper extends BaseMapper<CoAlbum> {

}

