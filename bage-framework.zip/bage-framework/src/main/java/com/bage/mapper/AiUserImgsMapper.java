package com.bage.mapper;

import com.bage.domain.entity.AiUserImgs;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.stereotype.Repository;


/**
 * (AiUserImgs)表数据库访问层
 *
 * @author makejava
 * @since 2023-07-29 14:34:54
 */
@Repository //不加这个注解会让其它地方找不到AiUserImgsMapper这个方法，报无法自动装配。找不到 'AiUserImgsMapper' 类型的 Bean
public interface AiUserImgsMapper extends BaseMapper<AiUserImgs> {

}

