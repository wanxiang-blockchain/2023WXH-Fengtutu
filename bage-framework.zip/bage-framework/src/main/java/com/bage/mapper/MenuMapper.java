package com.bage.mapper;

import com.bage.domain.entity.Menu;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.List;


/**
 * 菜单权限表(Menu)表数据库访问层
 *
 * @author makejava
 * @since 2022-12-28 22:16:09
 */
public interface MenuMapper extends BaseMapper<Menu> {
    //否则返回用户所具有的权限信息
    List<String> selectPermsByUserId(Long id);//在MenuMapper.xml里实现具体自定义sql
    //如果是管理员，获取所有符合要求的Menu
    List<Menu> selectAllRouterMenu();
    //如果不是管理员获取当前用户所具有的Menu
    List<Menu> selectRouterMenuTreeByUserId(Long userId);
    //加载对应角色菜单列表树
    List<Long> selectMenuListByRoleId(Long roleId);
}

