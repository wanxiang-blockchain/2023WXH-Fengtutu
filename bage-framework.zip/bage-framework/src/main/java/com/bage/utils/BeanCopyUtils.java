package com.bage.utils;
/*
* BeanCopy拷贝插件，我们在查询表时先是把实体类（数据库）中的所有表字段都查出来。但是这些字段不是我们都需要的，此时我们在VO中配置需要的字段，通过这个
* 拷贝方法可以帮我们把需要的字段按照VO中配置好的字段拷贝给相应的变量
* */
import org.springframework.beans.BeanUtils;

import java.util.List;
import java.util.stream.Collectors;

public class BeanCopyUtils {

    private BeanCopyUtils() {
    }

    public static <V> V copyBean(Object source,Class<V> clazz) {
        //创建目标对象
        V result = null;
        try {
            result = clazz.newInstance();
            //实现属性copy
            BeanUtils.copyProperties(source, result);
        } catch (Exception e) {
            e.printStackTrace();
        }
        //返回结果
        return result;
    }
    public static <O,V> List<V> copyBeanList(List<O> list,Class<V> clazz){
        return list.stream()
                .map(o -> copyBean(o, clazz))
                .collect(Collectors.toList());
    }
}
