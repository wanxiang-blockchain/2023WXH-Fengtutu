package com.bage.handler.exception;
/*
 *如果Controller出现任何意外会在这里进行处理
 * */
import com.bage.domain.ResponseResult;
import com.bage.enums.AppHttpCodeEnum;
import com.bage.exception.SystemException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;


@RestControllerAdvice//相当于对Controller的增强，如果Controller出现任何意外在这里进行处理
@Slf4j//这个注解可以直接让我们适用log这个成员变量（酸辣粉）
public class GlobalExceptionHandler {

    //SystemException之内的异常
    @ExceptionHandler(SystemException.class)//标识，让systemExceptionHandler去处理SystemException
    public ResponseResult systemExceptionHandler(SystemException e){
        //打印异常信息
        log.error("出现了异常！ {}",e);//后面的e是完整的对象信息
        //从异常对象中获取提示信息封装返回
        return ResponseResult.errorResult(e.getCode(),e.getMsg());
    }

    //除了SystemException之外的系统抛出的意料之外的异常
    @ExceptionHandler(Exception.class)
    public ResponseResult exceptionHandler(Exception e){
        //打印异常信息
        log.error("出现了异常！ {}",e);
        //从异常对象中获取提示信息封装返回
        return ResponseResult.errorResult(AppHttpCodeEnum.SYSTEM_ERROR.getCode(),e.getMessage());//直接打印异常信息返回给前端
    }
}
