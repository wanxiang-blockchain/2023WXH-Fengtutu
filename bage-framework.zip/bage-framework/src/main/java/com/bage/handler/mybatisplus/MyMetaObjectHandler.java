package com.bage.handler.mybatisplus;

import com.baomidou.mybatisplus.core.handlers.MetaObjectHandler;
import com.bage.utils.SecurityUtils;
import org.apache.ibatis.reflection.MetaObject;
import org.springframework.stereotype.Component;

import java.util.Date;
/*
 * mybatisplus 提供的开放的接口，让我们自定义规则去在某些特定的接口插入或者更新时自动帮我们插入某些字段
 * 比如在新增文章评论接口和更新评论接口就都需要插入用户信息给数据库，这时候我们就可以在这里进行统一插入，避免每个
 * service都写一遍
 * 使用方法：在实体类里面将需要自动填充的字段使用@TableField(fill=FieldFill.INSERT)\@TableField(fill=FieldFill.INSERT_UPDATE)注解
 * */
@Component
public class MyMetaObjectHandler implements MetaObjectHandler {
    @Override
    public void insertFill(MetaObject metaObject) {//如果进行插入操作
        Long userId = null;
        try {
            userId = SecurityUtils.getUserId();//如果注册用户时没有用户id
        } catch (Exception e) {
            e.printStackTrace();
            userId = -1L;//表示是自己创建
        }
        this.setFieldValByName("createTime", new Date(), metaObject);
        this.setFieldValByName("createBy",userId , metaObject);
        this.setFieldValByName("updateTime", new Date(), metaObject);
        this.setFieldValByName("updateBy", userId, metaObject);
    }

    @Override
    public void updateFill(MetaObject metaObject) {//如果是更新操作
        this.setFieldValByName("updateTime", new Date(), metaObject);
        this.setFieldValByName(" ", SecurityUtils.getUserId(), metaObject);
    }
}