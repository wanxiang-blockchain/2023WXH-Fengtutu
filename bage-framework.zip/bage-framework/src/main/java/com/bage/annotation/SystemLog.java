package com.bage.annotation;
/*
* 自定义注解：系统日志注解，在需要打印日志的接口加上此注解即可
* */

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME) //注解会保持在哪个阶段
@Target(ElementType.METHOD) //注解可以加在哪些东西上面
public @interface SystemLog {
    String businessName();
}
