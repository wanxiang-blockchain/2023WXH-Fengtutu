|-- com
|-- annotation  #自定义注解存放文件
|   |-- SystemLog.java   #自定义的系统日志相关注解
|-- aspect  #切面类文件
|   |-- LogAspect.java  #切面类：简单的来说，就是动态的在方法的指定位置添加指定的代码。 比如我们想在指定的位置添加log日志
|-- config
|   |-- FastJsonRedisSerializer.java  # Redis使用FastJson序列化
|   |-- MbatisPlusConfig.java  #MbatisPlus的分页配置，不需要自己记，直接复制即可，如果不配置会导致分页page失效
|   |-- RedisConfig.java # Redis的配置
|   |-- WebConfig.java # 公共的web相关配置1.web跨域配置 2.fastJson配置（处理返回给前端的JSON格式插件，比如日期格式）
|-- constants #常量文件夹，用来存放枚举
|   |-- SystemConstants.java #自定义的枚举
|-- domain # 存放数据结构的地方
|   |-- ResponseResult.java
|   |-- dto # （数据传输对象） 前端传给传给后端的整理后的数据结构
|   |   |-- AddArticleDto.java
|   |   |-- AddCommentDto.java
|   |   |-- AddTagDto.java
|   |   |-- ArticleDto.java
|   |   |-- ChangeRoleStatusDto.java
|   |   |-- EditTagDto.java
|   |   |-- TagListDto.java
|   |-- entity # 如数据库结构的entity类
|   |   |-- Article.java
|   |   |-- ArticleTag.java
|   |   |-- Category.java
|   |   |-- Comment.java
|   |   |-- Link.java
|   |   |-- LoginUser.java
|   |   |-- Menu.java
|   |   |-- Role.java
|   |   |-- RoleMenu.java
|   |   |-- Tag.java
|   |   |-- User.java
|   |   |-- UserInfoVo.java
|   |   |-- UserRole.java
|   |-- vo #自定义的后端返回给前端的整理后的数据结构view object
|       |-- AdminUserInfoVo.java
|       |-- ArticleDetailVo.java
|       |-- ArticleListVo.java
|       |-- ArticleVo.java
|       |-- BlogUserLoginVo.java
|       |-- CategoryVo.java
|       |-- CommentVo.java
|       |-- ExcelCategoryVo.java
|       |-- HotArticleVo.java
|       |-- LinkVo.java
|       |-- MenuTreeVo.java
|       |-- MenuVo.java
|       |-- PageVo.java
|       |-- RoleMenuTreeSelectVo.java
|       |-- RoutersVo.java
|       |-- TagVo.java
|       |-- UserInfoAndRoleIdsVo.java
|       |-- UserVo.java
|-- enums #枚举文件
|   |-- AppHttpCodeEnum.java # http请求的相关枚举
|-- exception #全局请求异常处理文件
|   |-- SystemException.java #系统统一异常处理文件
|-- handler
|   |-- exception #异常存放文件
|   |   |-- GlobalExceptionHandler.java #全局Controller出现任何意外会在这里进行处理
|   |-- mybatisplus #mybatisplus相关的文件
|   |   |-- MyMetaObjectHandler.java #我的自定义mybatisplus方法的文件，里面自定义了某些特定的接口插入或者更新时自动帮我们插入某些字段的方法
|   |-- security #SpringSecurity相关文件
|       |-- AccessDeniedHandlerImpl.java #AccessDeniedHandler 授权失败处理器，自定义SpringSecurity返回给前端的内容
|       |-- AuthenticationEntryPointImpl.java #AuthenticationEntryPoint token认证失败处理器，自定义SpringSecurity返回给前端的内容
|-- mapper # mapper相关文件，存放了对应service的默认mybatisplus提供的sql方法，有了它就可以继承并使用数据库类对应的entity通过id查寻数据库之类的方法
|   |-- ArticleMapper.java
|   |-- ArticleTagMapper.java
|   |-- CategoryMapper.java
|   |-- CommentMapper.java
|   |-- LinkMapper.java
|   |-- MenuMapper.java
|   |-- RoleMapper.java
|   |-- RoleMenuMapper.java
|   |-- TagMapper.java
|   |-- UserMapper.java
|   |-- UserRoleMapper.java
|-- service #服务层，里面存放具体接口的实现方法的函数声明，直接对应controller里的接口方法
|   |-- ArticleService.java
|   |-- ArticleTagService.java
|   |-- BlogLoginService.java
|   |-- CategoryService.java
|   |-- CommentService.java
|   |-- LinkService.java
|   |-- LoginService.java
|   |-- MenuService.java
|   |-- RoleMenuService.java
|   |-- RoleService.java
|   |-- TagService.java
|   |-- UploadService.java
|   |-- UserRoleService.java
|   |-- UserService.java
|   |-- impl  # impl里面是自定义的具体接口实现方法细节
|       |-- ArticleServiceImpl.java
|       |-- ArticleTagServiceImpl.java
|       |-- BlogLoginServiceImpl.java
|       |-- CategoryServiceImpl.java
|       |-- CommentServiceImpl.java
|       |-- LinkServiceImpl.java
|       |-- MenuServiceImpl.java
|       |-- OssUploadService.java
|       |-- PermissionService.java
|       |-- RoleMenuServiceImpl.java
|       |-- RoleServiceImpl.java
|       |-- SystemLoginServiceImpl.java
|       |-- TagServiceImpl.java
|       |-- UserDetailsServiceImpl.java
|       |-- UserRoleServiceImpl.java
|       |-- UserServiceImpl.java
|-- utils #工具文件
|-- BeanCopyUtils.java #从entity中拷贝需要的字段给vo
|-- JwtUtil.java #Jwt相关工具方法
|-- PathUtils.java #生成文件path路径，比如导出的excel文件名加上时间戳
|-- RedisCache.java # Redis缓存的方法
|-- SecurityUtils.java # Security相关的数据处理
|-- SystemConverter.java #后台管理系统菜单管理相关处理 菜单树处理
|-- WebUtils.java #前端相关的方法 导出excel 将字符串渲染到客户端，将json写入到响应中
