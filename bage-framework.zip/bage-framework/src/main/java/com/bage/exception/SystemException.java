package com.bage.exception;
/*
* 统一异常处理
* 如果前端传递的参数有问题等非法情况我们统一在这里进行处理，把异常中的信息封装成ResponseResult响应给前端
* */
import com.bage.enums.AppHttpCodeEnum;

/**
 * @Author 三更  B站： https://space.bilibili.com/663528522
 */
public class SystemException extends RuntimeException{

    private int code;

    private String msg;

    public int getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }

    public SystemException(AppHttpCodeEnum httpCodeEnum) {//接收枚举，把枚举的codemessage付值给异常对象的codemessage
        super(httpCodeEnum.getMsg());
        this.code = httpCodeEnum.getCode();
        this.msg = httpCodeEnum.getMsg();
    }

}
