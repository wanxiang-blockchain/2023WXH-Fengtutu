/**
 * Created by hao.cheng on 2017/4/13.
 */
import React, { useEffect, useState } from 'react';
import screenfull from 'screenfull';
import { Link } from 'react-router-dom';
import avater from '../style/imgs/b1.jpg';
import SiderCustom from './SiderCustom';
import { Menu, Layout, Badge, Popover, Dropdown } from 'antd';
import { gitOauthToken, gitOauthInfo } from '../service';
import { parseQuery } from '../utils';
import { useHistory } from 'react-router-dom';
// import { PwaInstaller } from './widget';
import { useAlita } from 'redux-alita';
import umbrella from 'umbrella-storage';
import { useSwitch } from '../utils/hooks';
import {
    ArrowsAltOutlined,
    BarsOutlined,
    MenuFoldOutlined,
    MenuUnfoldOutlined,
    NotificationOutlined,
} from '@ant-design/icons';
const { Header } = Layout;
const SubMenu = Menu.SubMenu;
const MenuItemGroup = Menu.ItemGroup;

type HeaderCustomProps = {
    toggle: () => void;
    collapsed: boolean;
    user: any;
    responsive?: any;
    path?: string;
};

const HeaderCustom = (props: HeaderCustomProps) => {
    const [user, setUser] = useState<any>();
    const [responsive] = useAlita('responsive', { light: true });
    const [visible, turn] = useSwitch();
    const history = useHistory();
    const myImages = [
        {
            id: 3,
            url: require('../images/m3.jpeg'),
            des: "Positive: cinematic photo crazy insane, high energy, magic, hyper realistic, detailed and realistic portrait of a woman, round eyes and short messy hair shot outside, wearing a white t shirt, skin texture, chapped lips, soft natural lighting, portrait photography, 85mm lens, magical photography",
            publish: true,
            message: 8,
            heart: 21,
            listResult: [
                {
                    "name": {
                        "last": "樱桃豆豆"
                    },
                    "picture": {
                        "large": require('../images/a1.jpeg'),
                    },
                    "description": "海姑娘"
                },
                {
                    "name": {
                        "last": "jeck"
                    },
                    "picture": {
                        "large": require('../images/a2.png'),
                    },
                    "description": "这个色调好喜欢"
                },
                {
                    "name": {
                        "last": "elliezer"
                    },
                    "picture": {
                        "large": require('../images/a3.png'),
                    },
                    "description": "我为啥做不出这样的图？"
                },
                {
                    "name": {
                        "last": "核桃"
                    },
                    "picture": {
                        "large": require('../images/a4.jpeg'),
                    },
                    "description": "厉害了！"
                },
                {
                    "name": {
                        "last": "不知天高地厚"
                    },
                    "picture": {
                        "large": require('../images/a1.jpeg'),
                    },
                    "description": "好美啊"
                },
                {
                    "name": {
                        "last": "农夫三拳有点疼"
                    },
                    "picture": {
                        "large": require('../images/a3.png'),
                    },
                    "description": "专业专业"
                },
                {
                    "name": {
                        "last": "桃子coo"
                    },
                    "picture": {
                        "large": require('../images/a5.jpeg'),
                    },
                    "description": "6啊老铁"
                },
        
                {
                    "name": {
                        "last": "ak行"
                    },
                    "picture": {
                        "large": require('../images/a5.jpeg'),
                    },
                    "description": "一般般"
                },
        
            ]
        },
        {
            id: 1,
            url: require('../images/m20.png'),
            des: "frilly hairstyle, latex dress, torso, body, 8k, ultra-detailed, highres, rainbow skin, shattered glass effect, (best quality, masterpiece:1.2), (deformad neon light:1.3), soft particles of fractal fire, volumetric lighting",
            publish: true,
            message: 13,
            heart: 86,
            listResult: [
                {
                    "name": {
                        "last": "巴达不达"
                    },
                    "picture": {
                        "large": require('../images/a5.jpeg'),
                    },
                    "description": "这个设计还可以，但色调更饱和点就好了"
                },
                {
                    "name": {
                        "last": "晴天snnynny"
                    },
                    "picture": {
                        "large": require('../images/a6.jpeg'),
                    },
                    "description": "一般般"
                },
                {
                    "name": {
                        "last": "jeffrey"
                    },
                    "picture": {
                        "large": require('../images/a7.jpeg'),
                    },
                    "description": "6啊老铁"
                },
                {
                    "name": {
                        "last": "西瓜太凉"
                    },
                    "picture": {
                        "large": require('../images/a8.jpeg'),
                    },
                    "description": "教教我怎么设计呗"
                },
                {
                    "name": {
                        "last": "小布丁"
                    },
                    "picture": {
                        "large": require('../images/a4.jpeg'),
                    },
                    "description": "yyds"
                },
                {
                    "name": {
                        "last": "请回答2021"
                    },
                    "picture": {
                        "large": require('../images/a9.jpeg'),
                    },
                    "description": "还行"
                },
                {
                    "name": {
                        "last": "nicky"
                    },
                    "picture": {
                        "large": require('../images/a6.jpeg'),
                    },
                    "description": "不知道这个怎么搞"
                },
        
                {
                    "name": {
                        "last": "linda"
                    },
                    "picture": {
                        "large": require('../images/a10.jpeg'),
                    },
                    "description": "这个真是随便玩玩……"
                },
        
            ]
        },
        {
            id: 2,
            url: require('../images/m2.jpeg'),
            des: "art by Peter Cross, Technical illustration, Raging epic, landscape, background, Stars in the sky, psychedelic colors, taiji, Golden ratio",
            publish: true,
            message: 6,
            heart: 23,
            listResult: [
                {
                    "name": {
                        "last": "zero"
                    },
                    "picture": {
                        "large": require('../images/a10.jpeg'),
                    },
                    "description": "挺好的呀，这设计感"
                },
                {
                    "name": {
                        "last": "窗"
                    },
                    "picture": {
                        "large": require('../images/a5.jpeg'),
                    },
                    "description": "这个风格我喜欢"
                },
                {
                    "name": {
                        "last": "农夫三拳有点疼"
                    },
                    "picture": {
                        "large": require('../images/a11.jpeg'),
                    },
                    "description": "一般般"
                },
                {
                    "name": {
                        "last": "eliezer"
                    },
                    "picture": {
                        "large": require('../images/a12.jpeg'),
                    },
                    "description": "感觉太大众化"
                },
                {
                    "name": {
                        "last": "朋克大地"
                    },
                    "picture": {
                        "large": require('../images/a13.jpeg'),
                    },
                    "description": "挺好的"
                },
                {
                    "name": {
                        "last": "布达拉佩斯"
                    },
                    "picture": {
                        "large": require('../images/a14.jpeg'),
                    },
                    "description": "这个我喜欢"
                },
                
        
            ]
        },

        {
            id: 4,
            url: require('../images/m4.jpeg'),
            des: "an optical illusion of the universe inside a glass jar, intricate detail, volumetric lighting, epic composition, hyper detailed, ultra realistic, sharp focus, octane render, volumetric",
            publish: true,
            message: 55,
            heart: 12,
            listResult: [
                {
                    "name": {
                        "last": "三拳两头"
                    },
                    "picture": {
                        "large": require('../images/a15.jpeg'),
                    },
                    "description": "这个我喜欢"
                },
                {
                    "name": {
                        "last": "桃子coo"
                    },
                    "picture": {
                        "large": require('../images/a16.jpeg'),
                    },
                    "description": "喜欢喜欢喜欢"
                },
                {
                    "name": {
                        "last": "jeffrey"
                    },
                    "picture": {
                        "large": require('../images/a1.jpeg'),
                    },
                    "description": "这张好看了"
                },
                {
                    "name": {
                        "last": "lisa"
                    },
                    "picture": {
                        "large": require('../images/a17.jpeg'),
                    },
                    "description": "还行还行"
                },
                {
                    "name": {
                        "last": "小安"
                    },
                    "picture": {
                        "large": require('../images/a18.jpeg'),
                    },
                    "description": "没生成出来这张"
                },
        
            ]
        },
        {
            id: 5,
            url: require('../images/m18.jpeg'),
            des: "masterpiece, highly detailed, realistic, lakeside, beside a lake, foliage, forest, (standing on a wooden pier:1.4), 1girl cute, kawaii",
            publish: true,
            message: 20,
            heart: 33,
            listResult: [
                {
                    "name": {
                        "last": "农夫三拳有点疼"
                    },
                    "picture": {
                        "large": require('../images/a19.jpeg'),
                    },
                    "description": "夏日清凉风哈哈哈"
                },
                {
                    "name": {
                        "last": "核桃"
                    },
                    "picture": {
                        "large": require('../images/a18.jpeg'),
                    },
                    "description": "一般般，太大众"
                },
                {
                    "name": {
                        "last": "jenny"
                    },
                    "picture": {
                        "large": require('../images/a17.jpeg'),
                    },
                    "description": "小清新"
                },
                {
                    "name": {
                        "last": "皮卡拉卡"
                    },
                    "picture": {
                        "large": require('../images/a16.jpeg'),
                    },
                    "description": "小女生的画作"
                },
                {
                    "name": {
                        "last": "再会"
                    },
                    "picture": {
                        "large": require('../images/a13.jpeg'),
                    },
                    "description": "有点普通了"
                },
                
        
            ]
        },
        {
            id: 6,
            url: require('../images/m16.jpeg'),
            des: "FluffyStyle award winning beautiful portrait commission of a male furry anthro albino wolf fursona with a tail and a cute beautiful attractive detailed furry face wearing stylish black",
            publish: true,
            message: 10,
            heart: 0,
            listResult: [
                {
                    "name": {
                        "last": "桃子coo"
                    },
                    "picture": {
                        "large": require('../images/a14.jpeg'),
                    },
                    "description": "这是女娲吗哈哈哈哈"
                },
                {
                    "name": {
                        "last": "小史"
                    },
                    "picture": {
                        "large": require('../images/a12.jpeg'),
                    },
                    "description": "好看啊"
                },
                {
                    "name": {
                        "last": "nicy"
                    },
                    "picture": {
                        "large": require('../images/a2.png'),
                    },
                    "description": "好看好看的"
                },
                {
                    "name": {
                        "last": "flutancy"
                    },
                    "picture": {
                        "large": require('../images/a8.jpeg'),
                    },
                    "description": "我喜欢这个风格！"
                },
                {
                    "name": {
                        "last": "再会"
                    },
                    "picture": {
                        "large": require('../images/a10.jpeg'),
                    },
                    "description": "这张艺术了"
                },
            
        
            ]
        },
        {
            id: 7,
            url: require('../images/m7.jpeg'),
            des: "an optical illusion of the universe inside a glass jar, intricate detail, volumetric lighting, epic composition, hyper detailed, ultra realistic, sharp focus, octane render, volumetric",
            publish: true,
            message: 0,
            heart: 0
        },
        {
            id: 8,
            url: require('../images/m8.jpeg'),
            des: "asterpiece, best quality, intricate detail, 1girl, sooogs, black shirt, urban, street, walking, light smile, holding water bottle",
            publish: true,
            message: 31,
            heart: 25
        },
        {
            id: 9,
            url: require('../images/m9.jpeg'),
            des: "FluffyStyle award winning beautiful portrait commission of a male furry anthro albino wolf fursona with a tail and a cute beautiful attractive detailed furry face wearing stylish black",
            publish: true,
            message: 2,
            heart: 6
        },
        {
            id: 11,
            url: require('../images/m11.jpeg'),
            des: "masterpiece, highly detailed, realistic, lakeside, beside a lake, foliage, forest, (standing on a wooden pier:1.4), 1girl cute, kawaii",
            publish: true,
            message: 3,
            heart: 0
        },
        {
            id: 12,
            url: require('../images/m12.jpeg'),
            des: "an optical illusion of the universe inside a glass jar, intricate detail, volumetric lighting, epic composition, hyper detailed, ultra realistic, sharp focus, octane render, volumetric",
            publish: true,
            message: 16,
            heart: 6
        },
        {
            id: 13,
            url: require('../images/m13.jpeg'),
            des: "asterpiece, best quality, intricate detail, 1girl, sooogs, black shirt, urban, street, walking, light smile, holding water bottle",
            publish: true,
            message: 5,
            heart: 17
        },
        {
            id: 14,
            url: require('../images/m14.jpeg'),
            des: "cinematic photo cinematic film still a activist cat rally, protesting against war, making a peace sign",
            publish: true,
            message: 5,
            heart: 0
        },
        {
            id: 15,
            url: require('../images/m15.jpeg'),
            des: "FluffyStyle award winning beautiful portrait commission of a male furry anthro albino wolf fursona with a tail and a cute beautiful attractive detailed furry face wearing stylish black",
            publish: true,
            message: 2,
            heart: 0
        },
        {
            id: 16,
            url: require('../images/m6.jpeg'),
            des: "asterpiece, best quality, intricate detail, 1girl, sooogs, black shirt, urban, street, walking, light smile, holding water bottle",
            publish: true,
            message: 16,
            heart: 11
        },
        {
            id: 17,
            url: require('../images/m17.jpeg'),
            des: "FluffyStyle award winning beautiful portrait commission of a male furry anthro albino wolf fursona with a tail and a cute beautiful attractive detailed furry face wearing stylish black",
            publish: true,
            message: 2,
            heart: 3
        },
        {
            id: 18,
            url: require('../images/m5.jpeg'),
            des: "an optical illusion of the universe inside a glass jar, intricate detail, volumetric lighting, epic composition, hyper detailed, ultra realistic, sharp focus, octane render, volumetric",
            publish: true,
            message: 16,
            heart: 6
        },
        {
            id: 19,
            url: require('../images/m19.jpeg'),
            des: "asterpiece, best quality, intricate detail, 1girl, sooogs, black shirt, urban, street, walking, light smile, holding water bottle",
            publish: true,
            message: 1,
            heart: 0
        },
        {
            id: 20,
            url: require('../images/m1.jpeg'),
            des: "masterpiece, highly detailed, realistic, lakeside, beside a lake, foliage, forest, (standing on a wooden pier:1.4), 1girl cute, kawaii",
            publish: true,
            message: 0,
            heart: 2
        },
        {
            id: 21,
            url: require('../images/m21.jpeg'),
            des: "an optical illusion of the universe inside a glass jar, intricate detail, volumetric lighting, epic composition, hyper detailed, ultra realistic, sharp focus, octane render, volumetric",
            publish: true,
            message: 0,
            heart: 1
        },
        {
            id: 22,
            url: require('../images/m22.jpeg'),
            des: "FluffyStyle award winning beautiful portrait commission of a male furry anthro albino wolf fursona with a tail and a cute beautiful attractive detailed furry face wearing stylish black",
            publish: true,
            message: 0,
            heart: 3
        },
        {
            id: 23,
            url: require('../images/m23.jpeg'),
            des: "art by Peter Cross, Technical illustration, Raging epic, landscape, background, Stars in the sky, psychedelic colors, taiji, Golden ratio",
            publish: true,
            message: 15,
            heart: 6
        },
        {
            id: 24,
            url: require('../images/m24.jpeg'),
            des: "FluffyStyle award winning beautiful portrait commission of a male furry anthro albino wolf fursona with a tail and a cute beautiful attractive detailed furry face wearing stylish black",
            publish: true,
            message: 3,
            heart: 21
        },
        {
            id: 25,
            url: require('../images/m25.jpeg'),
            des: "an optical illusion of the universe inside a glass jar, intricate detail, volumetric lighting, epic composition, hyper detailed, ultra realistic, sharp focus, octane render, volumetric",
            publish: true,
            message: 9,
            heart: 3
        },
        {
            id: 26,
            url: require('../images/m26.jpeg'),
            des: "frilly hairstyle, latex dress, torso, body, 8k, ultra-detailed, highres, rainbow skin, shattered glass effect, (best quality, masterpiece:1.2), (deformad neon light:1.3), soft particles of fractal fire, volumetric lighting",
            publish: true,
            message: 7,
            heart: 1
        },
        {
            id: 27,
            url: require('../images/m27.jpeg'),
            des: "art by Peter Cross, Technical illustration, Raging epic, landscape, background, Stars in the sky, psychedelic colors, taiji, Golden ratio",
            publish: true,
            message: 23,
            heart: 82
        },
    ]
    const myMyImages = [
        {
            id: 19,
            url: require('../images/g1.jpeg'),
            des: "art by Peter Cross, Technical illustration, Raging epic, landscape, background, Stars in the sky, psychedelic colors, taiji, Golden ratio",
            publish: true,
            message: 0,
            heart: 0,
            qianbao: "0xf8756eb399bbe17d3a8c20ca996d02006a81a0d2",
            listResult: []
        },
        {
            id: 20,
            url: require('../images/m1.jpeg'),
            des: "an optical illusion of the universe inside a glass jar, intricate detail, volumetric lighting, epic composition, hyper detailed, ultra realistic, sharp focus, octane render, volumetric",
            publish: true,
            message: 6,
            heart: 32,
            listResult: [
                {
                    "name": {
                        "last": "巴达不达"
                    },
                    "picture": {
                        "large": require('../images/a5.jpeg'),
                    },
                    "description": "这个设计还可以，但色调更饱和点就好了"
                },
                {
                    "name": {
                        "last": "晴天snnynny"
                    },
                    "picture": {
                        "large": require('../images/a6.jpeg'),
                    },
                    "description": "一般般"
                },
                {
                    "name": {
                        "last": "jeffrey"
                    },
                    "picture": {
                        "large": require('../images/a7.jpeg'),
                    },
                    "description": "6啊老铁"
                },
                {
                    "name": {
                        "last": "西瓜太凉"
                    },
                    "picture": {
                        "large": require('../images/a8.jpeg'),
                    },
                    "description": "教教我怎么设计呗"
                },
                {
                    "name": {
                        "last": "小布丁"
                    },
                    "picture": {
                        "large": require('../images/a4.jpeg'),
                    },
                    "description": "yyds"
                },
                {
                    "name": {
                        "last": "请回答2021"
                    },
                    "picture": {
                        "large": require('../images/a9.jpeg'),
                    },
                    "description": "还行"
                },
                {
                    "name": {
                        "last": "nicky"
                    },
                    "picture": {
                        "large": require('../images/a6.jpeg'),
                    },
                    "description": "不知道这个怎么搞"
                },
        
                {
                    "name": {
                        "last": "linda"
                    },
                    "picture": {
                        "large": require('../images/a10.jpeg'),
                    },
                    "description": "这个真是随便玩玩……"
                },
        
            ]
        },
        {
            id: 21,
            url: require('../images/m21.jpeg'),
            des: "masterpiece, highly detailed, realistic, lakeside, beside a lake, foliage, forest, (standing on a wooden pier:1.4), 1girl cute, kawaii",
            publish: true,
            message: 5,
            heart: 6,
            listResult: [
                {
                    "name": {
                        "last": "zero"
                    },
                    "picture": {
                        "large": require('../images/a10.jpeg'),
                    },
                    "description": "挺好的呀，这设计感"
                },
                {
                    "name": {
                        "last": "窗"
                    },
                    "picture": {
                        "large": require('../images/a5.jpeg'),
                    },
                    "description": "这个风格我喜欢"
                },
                {
                    "name": {
                        "last": "农夫三拳有点疼"
                    },
                    "picture": {
                        "large": require('../images/a11.jpeg'),
                    },
                    "description": "一般般"
                },
                {
                    "name": {
                        "last": "eliezer"
                    },
                    "picture": {
                        "large": require('../images/a12.jpeg'),
                    },
                    "description": "感觉太大众化"
                },
                {
                    "name": {
                        "last": "朋克大地"
                    },
                    "picture": {
                        "large": require('../images/a13.jpeg'),
                    },
                    "description": "挺好的"
                },
                {
                    "name": {
                        "last": "布达拉佩斯"
                    },
                    "picture": {
                        "large": require('../images/a14.jpeg'),
                    },
                    "description": "这个我喜欢"
                },
                
        
            ]
        },
        {
            id: 22,
            url: require('../images/m22.jpeg'),
            des: "an optical illusion of the universe inside a glass jar, intricate detail, volumetric lighting, epic composition, hyper detailed, ultra realistic, sharp focus, octane render, volumetric",
            publish: true,
            message: 21,
            heart: 12,
            listResult: [
                {
                    "name": {
                        "last": "三拳两头"
                    },
                    "picture": {
                        "large": require('../images/a15.jpeg'),
                    },
                    "description": "这个我喜欢"
                },
                {
                    "name": {
                        "last": "桃子coo"
                    },
                    "picture": {
                        "large": require('../images/a16.jpeg'),
                    },
                    "description": "喜欢喜欢喜欢"
                },
                {
                    "name": {
                        "last": "jeffrey"
                    },
                    "picture": {
                        "large": require('../images/a1.jpeg'),
                    },
                    "description": "这张好看了"
                },
                {
                    "name": {
                        "last": "lisa"
                    },
                    "picture": {
                        "large": require('../images/a17.jpeg'),
                    },
                    "description": "还行还行"
                },
                {
                    "name": {
                        "last": "小安"
                    },
                    "picture": {
                        "large": require('../images/a18.jpeg'),
                    },
                    "description": "没生成出来这张"
                },
        
            ]
        },
        {
            id: 23,
            url: require('../images/m23.jpeg'),
            des: "FluffyStyle award winning beautiful portrait commission of a male furry anthro albino wolf fursona with a tail and a cute beautiful attractive detailed furry face wearing stylish black",
            publish: true,
            message: 7,
            heart: 6,
            listResult: [
                {
                    "name": {
                        "last": "农夫三拳有点疼"
                    },
                    "picture": {
                        "large": require('../images/a19.jpeg'),
                    },
                    "description": "夏日清凉风哈哈哈"
                },
                {
                    "name": {
                        "last": "核桃"
                    },
                    "picture": {
                        "large": require('../images/a18.jpeg'),
                    },
                    "description": "一般般，太大众"
                },
                {
                    "name": {
                        "last": "jenny"
                    },
                    "picture": {
                        "large": require('../images/a17.jpeg'),
                    },
                    "description": "小清新"
                },
                {
                    "name": {
                        "last": "皮卡拉卡"
                    },
                    "picture": {
                        "large": require('../images/a16.jpeg'),
                    },
                    "description": "小女生的画作"
                },
                {
                    "name": {
                        "last": "再会"
                    },
                    "picture": {
                        "large": require('../images/a13.jpeg'),
                    },
                    "description": "有点普通了"
                },
                
        
            ]
        },
        {
            id: 24,
            url: require('../images/m24.jpeg'),
            des: "an optical illusion of the universe inside a glass jar, intricate detail, volumetric lighting, epic composition, hyper detailed, ultra realistic, sharp focus, octane render, volumetric",
            publish: true,
            message: 8,
            heart: 9,
            listResult: [
                {
                    "name": {
                        "last": "桃子coo"
                    },
                    "picture": {
                        "large": require('../images/a14.jpeg'),
                    },
                    "description": "这是女娲吗哈哈哈哈"
                },
                {
                    "name": {
                        "last": "小史"
                    },
                    "picture": {
                        "large": require('../images/a12.jpeg'),
                    },
                    "description": "好看啊"
                },
                {
                    "name": {
                        "last": "nicy"
                    },
                    "picture": {
                        "large": require('../images/a2.png'),
                    },
                    "description": "好看好看的"
                },
                {
                    "name": {
                        "last": "flutancy"
                    },
                    "picture": {
                        "large": require('../images/a8.jpeg'),
                    },
                    "description": "我喜欢这个风格！"
                },
                {
                    "name": {
                        "last": "再会"
                    },
                    "picture": {
                        "large": require('../images/a10.jpeg'),
                    },
                    "description": "这张艺术了"
                },
            
        
            ]
        },
        {
            id: 25,
            url: require('../images/m25.jpeg'),
            des: "Anime artwork, open trunk of a car, filled with trash, Woman, long hair, art by J.C. Leyendecker",
            publish: false,
            message: 0,
            heart: 0
        },
        {
            id: 26,
            url: require('../images/m26.jpeg'),
            des: "masterpiece, highly detailed, realistic, lakeside, beside a lake, foliage, forest, (standing on a wooden pier:1.4), 1girl cute, kawaii",
            publish: false,
            message: 0,
            heart: 0
        },
        {
            id: 27,
            url: require('../images/m27.jpeg'),
            des: "art by Peter Cross, Technical illustration, Raging epic, landscape, background, Stars in the sky, psychedelic colors, taiji, Golden ratio",
            publish: true,
            message: 11,
            heart: 5
        },
    ]
    const myMyImages2 = [
        {
            id: 19,
            url: require('../images/g2.jpeg'),
            des: "art by Peter Cross, Technical illustration, Raging epic, landscape, background, Stars in the sky, psychedelic colors, taiji, Golden ratio",
            publish: true,
            message: 0,
            heart: 0,
            qianbao: "0xf8756eb399bbe17d3a8c20ca996d02006a81a0d2",
            listResult: []
        },
        {
            id: 20,
            url: require('../images/m1.jpeg'),
            des: "an optical illusion of the universe inside a glass jar, intricate detail, volumetric lighting, epic composition, hyper detailed, ultra realistic, sharp focus, octane render, volumetric",
            publish: true,
            message: 6,
            heart: 32,
            listResult: [
                {
                    "name": {
                        "last": "巴达不达"
                    },
                    "picture": {
                        "large": require('../images/a5.jpeg'),
                    },
                    "description": "这个设计还可以，但色调更饱和点就好了"
                },
                {
                    "name": {
                        "last": "晴天snnynny"
                    },
                    "picture": {
                        "large": require('../images/a6.jpeg'),
                    },
                    "description": "一般般"
                },
                {
                    "name": {
                        "last": "jeffrey"
                    },
                    "picture": {
                        "large": require('../images/a7.jpeg'),
                    },
                    "description": "6啊老铁"
                },
                {
                    "name": {
                        "last": "西瓜太凉"
                    },
                    "picture": {
                        "large": require('../images/a8.jpeg'),
                    },
                    "description": "教教我怎么设计呗"
                },
                {
                    "name": {
                        "last": "小布丁"
                    },
                    "picture": {
                        "large": require('../images/a4.jpeg'),
                    },
                    "description": "yyds"
                },
                {
                    "name": {
                        "last": "请回答2021"
                    },
                    "picture": {
                        "large": require('../images/a9.jpeg'),
                    },
                    "description": "还行"
                },
                {
                    "name": {
                        "last": "nicky"
                    },
                    "picture": {
                        "large": require('../images/a6.jpeg'),
                    },
                    "description": "不知道这个怎么搞"
                },
        
                {
                    "name": {
                        "last": "linda"
                    },
                    "picture": {
                        "large": require('../images/a10.jpeg'),
                    },
                    "description": "这个真是随便玩玩……"
                },
        
            ]
        },
        {
            id: 21,
            url: require('../images/m21.jpeg'),
            des: "masterpiece, highly detailed, realistic, lakeside, beside a lake, foliage, forest, (standing on a wooden pier:1.4), 1girl cute, kawaii",
            publish: true,
            message: 5,
            heart: 6,
            listResult: [
                {
                    "name": {
                        "last": "zero"
                    },
                    "picture": {
                        "large": require('../images/a10.jpeg'),
                    },
                    "description": "挺好的呀，这设计感"
                },
                {
                    "name": {
                        "last": "窗"
                    },
                    "picture": {
                        "large": require('../images/a5.jpeg'),
                    },
                    "description": "这个风格我喜欢"
                },
                {
                    "name": {
                        "last": "农夫三拳有点疼"
                    },
                    "picture": {
                        "large": require('../images/a11.jpeg'),
                    },
                    "description": "一般般"
                },
                {
                    "name": {
                        "last": "eliezer"
                    },
                    "picture": {
                        "large": require('../images/a12.jpeg'),
                    },
                    "description": "感觉太大众化"
                },
                {
                    "name": {
                        "last": "朋克大地"
                    },
                    "picture": {
                        "large": require('../images/a13.jpeg'),
                    },
                    "description": "挺好的"
                },
                {
                    "name": {
                        "last": "布达拉佩斯"
                    },
                    "picture": {
                        "large": require('../images/a14.jpeg'),
                    },
                    "description": "这个我喜欢"
                },
                
        
            ]
        },
        {
            id: 22,
            url: require('../images/m22.jpeg'),
            des: "an optical illusion of the universe inside a glass jar, intricate detail, volumetric lighting, epic composition, hyper detailed, ultra realistic, sharp focus, octane render, volumetric",
            publish: true,
            message: 21,
            heart: 12,
            listResult: [
                {
                    "name": {
                        "last": "三拳两头"
                    },
                    "picture": {
                        "large": require('../images/a15.jpeg'),
                    },
                    "description": "这个我喜欢"
                },
                {
                    "name": {
                        "last": "桃子coo"
                    },
                    "picture": {
                        "large": require('../images/a16.jpeg'),
                    },
                    "description": "喜欢喜欢喜欢"
                },
                {
                    "name": {
                        "last": "jeffrey"
                    },
                    "picture": {
                        "large": require('../images/a1.jpeg'),
                    },
                    "description": "这张好看了"
                },
                {
                    "name": {
                        "last": "lisa"
                    },
                    "picture": {
                        "large": require('../images/a17.jpeg'),
                    },
                    "description": "还行还行"
                },
                {
                    "name": {
                        "last": "小安"
                    },
                    "picture": {
                        "large": require('../images/a18.jpeg'),
                    },
                    "description": "没生成出来这张"
                },
        
            ]
        },
        {
            id: 23,
            url: require('../images/m23.jpeg'),
            des: "FluffyStyle award winning beautiful portrait commission of a male furry anthro albino wolf fursona with a tail and a cute beautiful attractive detailed furry face wearing stylish black",
            publish: true,
            message: 7,
            heart: 6,
            listResult: [
                {
                    "name": {
                        "last": "农夫三拳有点疼"
                    },
                    "picture": {
                        "large": require('../images/a19.jpeg'),
                    },
                    "description": "夏日清凉风哈哈哈"
                },
                {
                    "name": {
                        "last": "核桃"
                    },
                    "picture": {
                        "large": require('../images/a18.jpeg'),
                    },
                    "description": "一般般，太大众"
                },
                {
                    "name": {
                        "last": "jenny"
                    },
                    "picture": {
                        "large": require('../images/a17.jpeg'),
                    },
                    "description": "小清新"
                },
                {
                    "name": {
                        "last": "皮卡拉卡"
                    },
                    "picture": {
                        "large": require('../images/a16.jpeg'),
                    },
                    "description": "小女生的画作"
                },
                {
                    "name": {
                        "last": "再会"
                    },
                    "picture": {
                        "large": require('../images/a13.jpeg'),
                    },
                    "description": "有点普通了"
                },
                
        
            ]
        },
        {
            id: 24,
            url: require('../images/m24.jpeg'),
            des: "an optical illusion of the universe inside a glass jar, intricate detail, volumetric lighting, epic composition, hyper detailed, ultra realistic, sharp focus, octane render, volumetric",
            publish: true,
            message: 8,
            heart: 9,
            listResult: [
                {
                    "name": {
                        "last": "桃子coo"
                    },
                    "picture": {
                        "large": require('../images/a14.jpeg'),
                    },
                    "description": "这是女娲吗哈哈哈哈"
                },
                {
                    "name": {
                        "last": "小史"
                    },
                    "picture": {
                        "large": require('../images/a12.jpeg'),
                    },
                    "description": "好看啊"
                },
                {
                    "name": {
                        "last": "nicy"
                    },
                    "picture": {
                        "large": require('../images/a2.png'),
                    },
                    "description": "好看好看的"
                },
                {
                    "name": {
                        "last": "flutancy"
                    },
                    "picture": {
                        "large": require('../images/a8.jpeg'),
                    },
                    "description": "我喜欢这个风格！"
                },
                {
                    "name": {
                        "last": "再会"
                    },
                    "picture": {
                        "large": require('../images/a10.jpeg'),
                    },
                    "description": "这张艺术了"
                },
            
        
            ]
        },
        {
            id: 25,
            url: require('../images/m25.jpeg'),
            des: "Anime artwork, open trunk of a car, filled with trash, Woman, long hair, art by J.C. Leyendecker",
            publish: false,
            message: 0,
            heart: 0
        },
        {
            id: 26,
            url: require('../images/m26.jpeg'),
            des: "masterpiece, highly detailed, realistic, lakeside, beside a lake, foliage, forest, (standing on a wooden pier:1.4), 1girl cute, kawaii",
            publish: false,
            message: 0,
            heart: 0
        },
        {
            id: 27,
            url: require('../images/m27.jpeg'),
            des: "art by Peter Cross, Technical illustration, Raging epic, landscape, background, Stars in the sky, psychedelic colors, taiji, Golden ratio",
            publish: true,
            message: 11,
            heart: 5
        },
    ]
    const mainPage = [
        {
            id: 19,
            url: require('../images/m19.jpeg'),
            des: "FluffyStyle award winning beautiful portrait commission of a male furry anthro albino wolf fursona with a tail and a cute beautiful attractive detailed furry face wearing stylish black",
            publish: true,
            message: 5,
            heart: 0,
            listResult: [
                {
                    "name": {
                        "last": "樱桃豆豆"
                    },
                    "picture": {
                        "large": require('../images/a1.jpeg'),
                    },
                    "description": "海姑娘"
                },
                {
                    "name": {
                        "last": "jeck"
                    },
                    "picture": {
                        "large": require('../images/a2.png'),
                    },
                    "description": "这个色调好喜欢"
                },
                {
                    "name": {
                        "last": "elliezer"
                    },
                    "picture": {
                        "large": require('../images/a3.png'),
                    },
                    "description": "我为啥做不出这样的图？"
                },
                {
                    "name": {
                        "last": "核桃"
                    },
                    "picture": {
                        "large": require('../images/a4.jpeg'),
                    },
                    "description": "厉害了！"
                },
                {
                    "name": {
                        "last": "不知天高地厚"
                    },
                    "picture": {
                        "large": require('../images/a1.jpeg'),
                    },
                    "description": "好美啊"
                },
                {
                    "name": {
                        "last": "农夫三拳有点疼"
                    },
                    "picture": {
                        "large": require('../images/a3.png'),
                    },
                    "description": "专业专业"
                },
                {
                    "name": {
                        "last": "桃子coo"
                    },
                    "picture": {
                        "large": require('../images/a5.jpeg'),
                    },
                    "description": "6啊老铁"
                },
        
                {
                    "name": {
                        "last": "ak行"
                    },
                    "picture": {
                        "large": require('../images/a5.jpeg'),
                    },
                    "description": "一般般"
                },
        
            ]
        },
        {
            id: 2,
            url: require('../images/s2.jpeg'),
            des: "asterpiece, best quality, intricate detail, 1girl, sooogs, black shirt, urban, street, walking, light smile, holding water bottle",
            publish: true,
            message: 6,
            heart: 2,
            listResult: [
                {
                    "name": {
                        "last": "巴达不达"
                    },
                    "picture": {
                        "large": require('../images/a5.jpeg'),
                    },
                    "description": "这个设计还可以，但色调更饱和点就好了"
                },
                {
                    "name": {
                        "last": "晴天snnynny"
                    },
                    "picture": {
                        "large": require('../images/a6.jpeg'),
                    },
                    "description": "一般般"
                },
                {
                    "name": {
                        "last": "jeffrey"
                    },
                    "picture": {
                        "large": require('../images/a7.jpeg'),
                    },
                    "description": "6啊老铁"
                },
                {
                    "name": {
                        "last": "西瓜太凉"
                    },
                    "picture": {
                        "large": require('../images/a8.jpeg'),
                    },
                    "description": "教教我怎么设计呗"
                },
                {
                    "name": {
                        "last": "小布丁"
                    },
                    "picture": {
                        "large": require('../images/a4.jpeg'),
                    },
                    "description": "yyds"
                },
                {
                    "name": {
                        "last": "请回答2021"
                    },
                    "picture": {
                        "large": require('../images/a9.jpeg'),
                    },
                    "description": "还行"
                },
                {
                    "name": {
                        "last": "nicky"
                    },
                    "picture": {
                        "large": require('../images/a6.jpeg'),
                    },
                    "description": "不知道这个怎么搞"
                },
        
                {
                    "name": {
                        "last": "linda"
                    },
                    "picture": {
                        "large": require('../images/a10.jpeg'),
                    },
                    "description": "这个真是随便玩玩……"
                },
        
            ]

        },
        {
            id: 5,
            url: require('../images/s5.jpeg'),
            des: "cinematic photo cinematic film still a activist cat rally, protesting against war, making a peace sign",
            publish: true,
            message: 5,
            heart: 1,
            listResult: [
                {
                    "name": {
                        "last": "zero"
                    },
                    "picture": {
                        "large": require('../images/a10.jpeg'),
                    },
                    "description": "挺好的呀，这设计感"
                },
                {
                    "name": {
                        "last": "窗"
                    },
                    "picture": {
                        "large": require('../images/a5.jpeg'),
                    },
                    "description": "这个风格我喜欢"
                },
                {
                    "name": {
                        "last": "农夫三拳有点疼"
                    },
                    "picture": {
                        "large": require('../images/a11.jpeg'),
                    },
                    "description": "一般般"
                },
                {
                    "name": {
                        "last": "eliezer"
                    },
                    "picture": {
                        "large": require('../images/a12.jpeg'),
                    },
                    "description": "感觉太大众化"
                },
                {
                    "name": {
                        "last": "朋克大地"
                    },
                    "picture": {
                        "large": require('../images/a13.jpeg'),
                    },
                    "description": "挺好的"
                },
                {
                    "name": {
                        "last": "布达拉佩斯"
                    },
                    "picture": {
                        "large": require('../images/a14.jpeg'),
                    },
                    "description": "这个我喜欢"
                },
                
        
            ]
        },
        {
            id: 20,
            url: require('../images/m1.jpeg'),
            des: "FluffyStyle award winning beautiful portrait commission of a male furry anthro albino wolf fursona with a tail and a cute beautiful attractive detailed furry face wearing stylish black",
            publish: true,
            message: 10,
            heart: 6,
            listResult: [
                {
                    "name": {
                        "last": "三拳两头"
                    },
                    "picture": {
                        "large": require('../images/a15.jpeg'),
                    },
                    "description": "这个我喜欢"
                },
                {
                    "name": {
                        "last": "桃子coo"
                    },
                    "picture": {
                        "large": require('../images/a16.jpeg'),
                    },
                    "description": "喜欢喜欢喜欢"
                },
                {
                    "name": {
                        "last": "jeffrey"
                    },
                    "picture": {
                        "large": require('../images/a1.jpeg'),
                    },
                    "description": "这张好看了"
                },
                {
                    "name": {
                        "last": "lisa"
                    },
                    "picture": {
                        "large": require('../images/a17.jpeg'),
                    },
                    "description": "还行还行"
                },
                {
                    "name": {
                        "last": "小安"
                    },
                    "picture": {
                        "large": require('../images/a18.jpeg'),
                    },
                    "description": "没生成出来这张"
                },
        
            ]
        },
        {
            id: 7,
            url: require('../images/s7.jpeg'),
            des: "cinematic photo cinematic film still a activist cat rally, protesting against war, making a peace sign",
            publish: true,
            message: 8,
            heart: 0,
            listResult: [
                {
                    "name": {
                        "last": "农夫三拳有点疼"
                    },
                    "picture": {
                        "large": require('../images/a19.jpeg'),
                    },
                    "description": "夏日清凉风哈哈哈"
                },
                {
                    "name": {
                        "last": "核桃"
                    },
                    "picture": {
                        "large": require('../images/a18.jpeg'),
                    },
                    "description": "一般般，太大众"
                },
                {
                    "name": {
                        "last": "jenny"
                    },
                    "picture": {
                        "large": require('../images/a17.jpeg'),
                    },
                    "description": "小清新"
                },
                {
                    "name": {
                        "last": "皮卡拉卡"
                    },
                    "picture": {
                        "large": require('../images/a16.jpeg'),
                    },
                    "description": "小女生的画作"
                },
                {
                    "name": {
                        "last": "再会"
                    },
                    "picture": {
                        "large": require('../images/a13.jpeg'),
                    },
                    "description": "有点普通了"
                },
                
        
            ]
        },
        {
            id: 21,
            url: require('../images/m21.jpeg'),
            des: "asterpiece, best quality, intricate detail, 1girl, sooogs, black shirt, urban, street, walking, light smile, holding water bottle",
            publish: true,
            message: 11,
            heart: 17,
            listResult: [
                {
                    "name": {
                        "last": "桃子coo"
                    },
                    "picture": {
                        "large": require('../images/a14.jpeg'),
                    },
                    "description": "这是女娲吗哈哈哈哈"
                },
                {
                    "name": {
                        "last": "小史"
                    },
                    "picture": {
                        "large": require('../images/a12.jpeg'),
                    },
                    "description": "好看啊"
                },
                {
                    "name": {
                        "last": "nicy"
                    },
                    "picture": {
                        "large": require('../images/a2.png'),
                    },
                    "description": "好看好看的"
                },
                {
                    "name": {
                        "last": "flutancy"
                    },
                    "picture": {
                        "large": require('../images/a8.jpeg'),
                    },
                    "description": "我喜欢这个风格！"
                },
                {
                    "name": {
                        "last": "再会"
                    },
                    "picture": {
                        "large": require('../images/a10.jpeg'),
                    },
                    "description": "这张艺术了"
                },
            
        
            ]
        },
        {
            id: 8,
            url: require('../images/s1.jpeg'),
            des: "shallow depth of field, vignette, highly detailed, high budget, bokeh, cinemascope, moody, epic, gorgeous, film grain, grainy",
            publish: false,
            message: 0,
            heart: 0
        },
        {
            id: 22,
            url: require('../images/m22.jpeg'),
            des: "cinematic photo cinematic film still a activist cat rally, protesting against war, making a peace sign",
            publish: false,
            message: 0,
            heart: 0
        },
        {
            id: 23,
            url: require('../images/m23.jpeg'),
            des: "poorly drawn, [bad : wrong] anatomy, [extra | missing | floating | disconnected] limb, (mutated hands and fingers), blurry",
            publish: false,
            message: 0,
            heart: 0
        },
        {
            id: 24,
            url: require('../images/m24.jpeg'),
            des: "shallow depth of field, vignette, highly detailed, high budget, bokeh, cinemascope, moody, epic, gorgeous, film grain, grainy",
            publish: true,
            message: 2,
            heart: 0
        },
        {
            id: 25,
            url: require('../images/m25.jpeg'),
            des: "asterpiece, best quality, intricate detail, 1girl, sooogs, black shirt, urban, street, walking, light smile, holding water bottle",
            publish: true,
            message: 0,
            heart: 0
        },
        {
            id: 26,
            url: require('../images/m26.jpeg'),
            des: "asterpiece, best quality, intricate detail, 1girl, sooogs, black shirt, urban, street, walking, light smile, holding water bottle",
            publish: true,
            message: 0,
            heart: 0
        },
        {
            id: 27,
            url: require('../images/m27.jpeg'),
            des: "an optical illusion of the universe inside a glass jar, intricate detail, volumetric lighting, epic composition, hyper detailed, ultra realistic, sharp focus, octane render, volumetric",
            publish: true,
            message: 0,
            heart: 0
        },
    ]

    const storeImages = [
        {
            id: 1,
            url: require('../images/s1.jpeg'),
            des: "Anime artwork, open trunk of a car, filled with trash, Woman, long hair, art by J.C. Leyendecker",
            message: 23,
            heart: 86,
            listResult: [
                {
                    "name": {
                        "last": "樱桃豆豆"
                    },
                    "picture": {
                        "large": require('../images/a1.jpeg'),
                    },
                    "description": "海姑娘"
                },
                {
                    "name": {
                        "last": "jeck"
                    },
                    "picture": {
                        "large": require('../images/a2.png'),
                    },
                    "description": "这个色调好喜欢"
                },
                {
                    "name": {
                        "last": "elliezer"
                    },
                    "picture": {
                        "large": require('../images/a3.png'),
                    },
                    "description": "我为啥做不出这样的图？"
                },
                {
                    "name": {
                        "last": "核桃"
                    },
                    "picture": {
                        "large": require('../images/a4.jpeg'),
                    },
                    "description": "厉害了！"
                },
                {
                    "name": {
                        "last": "不知天高地厚"
                    },
                    "picture": {
                        "large": require('../images/a1.jpeg'),
                    },
                    "description": "好美啊"
                },
                {
                    "name": {
                        "last": "农夫三拳有点疼"
                    },
                    "picture": {
                        "large": require('../images/a3.png'),
                    },
                    "description": "专业专业"
                },
                {
                    "name": {
                        "last": "桃子coo"
                    },
                    "picture": {
                        "large": require('../images/a5.jpeg'),
                    },
                    "description": "6啊老铁"
                },
        
                {
                    "name": {
                        "last": "ak行"
                    },
                    "picture": {
                        "large": require('../images/a5.jpeg'),
                    },
                    "description": "一般般"
                },
        
            ]
        },
        {
            id: 2,
            url: require('../images/s2.jpeg'),
            des: "asterpiece, best quality, intricate detail, 1girl, sooogs, black shirt, urban, street, walking, light smile, holding water bottle",
            message: 13,
            heart: 18,
            listResult: [
                {
                    "name": {
                        "last": "巴达不达"
                    },
                    "picture": {
                        "large": require('../images/a5.jpeg'),
                    },
                    "description": "这个设计还可以，但色调更饱和点就好了"
                },
                {
                    "name": {
                        "last": "晴天snnynny"
                    },
                    "picture": {
                        "large": require('../images/a6.jpeg'),
                    },
                    "description": "一般般"
                },
                {
                    "name": {
                        "last": "jeffrey"
                    },
                    "picture": {
                        "large": require('../images/a7.jpeg'),
                    },
                    "description": "6啊老铁"
                },
                {
                    "name": {
                        "last": "西瓜太凉"
                    },
                    "picture": {
                        "large": require('../images/a8.jpeg'),
                    },
                    "description": "教教我怎么设计呗"
                },
                {
                    "name": {
                        "last": "小布丁"
                    },
                    "picture": {
                        "large": require('../images/a4.jpeg'),
                    },
                    "description": "yyds"
                },
                {
                    "name": {
                        "last": "请回答2021"
                    },
                    "picture": {
                        "large": require('../images/a9.jpeg'),
                    },
                    "description": "还行"
                },
                {
                    "name": {
                        "last": "nicky"
                    },
                    "picture": {
                        "large": require('../images/a6.jpeg'),
                    },
                    "description": "不知道这个怎么搞"
                },
        
                {
                    "name": {
                        "last": "linda"
                    },
                    "picture": {
                        "large": require('../images/a10.jpeg'),
                    },
                    "description": "这个真是随便玩玩……"
                },
        
            ]

        },
        {
            id: 3,
            url: require('../images/s3.jpeg'),
            des: "FluffyStyle award winning beautiful portrait commission of a male furry anthro albino wolf fursona with a tail and a cute beautiful attractive detailed furry face wearing stylish black",
            message: 16,
            heart: 22,
            listResult: [
                {
                    "name": {
                        "last": "zero"
                    },
                    "picture": {
                        "large": require('../images/a10.jpeg'),
                    },
                    "description": "挺好的呀，这设计感"
                },
                {
                    "name": {
                        "last": "窗"
                    },
                    "picture": {
                        "large": require('../images/a5.jpeg'),
                    },
                    "description": "这个风格我喜欢"
                },
                {
                    "name": {
                        "last": "农夫三拳有点疼"
                    },
                    "picture": {
                        "large": require('../images/a11.jpeg'),
                    },
                    "description": "一般般"
                },
                {
                    "name": {
                        "last": "eliezer"
                    },
                    "picture": {
                        "large": require('../images/a12.jpeg'),
                    },
                    "description": "感觉太大众化"
                },
                {
                    "name": {
                        "last": "朋克大地"
                    },
                    "picture": {
                        "large": require('../images/a13.jpeg'),
                    },
                    "description": "挺好的"
                },
                {
                    "name": {
                        "last": "布达拉佩斯"
                    },
                    "picture": {
                        "large": require('../images/a14.jpeg'),
                    },
                    "description": "这个我喜欢"
                },
                
        
            ]
        },
        {
            id: 4,
            url: require('../images/s4.jpeg'),
            des: "art by Peter Cross, Technical illustration, Raging epic, landscape, background, Stars in the sky, psychedelic colors, taiji, Golden ratio",
            message: 13,
            heart: 29,
            listResult: [
                {
                    "name": {
                        "last": "三拳两头"
                    },
                    "picture": {
                        "large": require('../images/a15.jpeg'),
                    },
                    "description": "这个我喜欢"
                },
                {
                    "name": {
                        "last": "桃子coo"
                    },
                    "picture": {
                        "large": require('../images/a16.jpeg'),
                    },
                    "description": "喜欢喜欢喜欢"
                },
                {
                    "name": {
                        "last": "jeffrey"
                    },
                    "picture": {
                        "large": require('../images/a1.jpeg'),
                    },
                    "description": "这张好看了"
                },
                {
                    "name": {
                        "last": "lisa"
                    },
                    "picture": {
                        "large": require('../images/a17.jpeg'),
                    },
                    "description": "还行还行"
                },
                {
                    "name": {
                        "last": "小安"
                    },
                    "picture": {
                        "large": require('../images/a18.jpeg'),
                    },
                    "description": "没生成出来这张"
                },
        
            ]
        },
        {
            id: 5,
            url: require('../images/s5.jpeg'),
            des: "cinematic photo cinematic film still a activist cat rally, protesting against war, making a peace sign",
            message: 9,
            heart: 0,
            listResult: [
                {
                    "name": {
                        "last": "农夫三拳有点疼"
                    },
                    "picture": {
                        "large": require('../images/a19.jpeg'),
                    },
                    "description": "夏日清凉风哈哈哈"
                },
                {
                    "name": {
                        "last": "核桃"
                    },
                    "picture": {
                        "large": require('../images/a18.jpeg'),
                    },
                    "description": "一般般，太大众"
                },
                {
                    "name": {
                        "last": "jenny"
                    },
                    "picture": {
                        "large": require('../images/a17.jpeg'),
                    },
                    "description": "小清新"
                },
                {
                    "name": {
                        "last": "皮卡拉卡"
                    },
                    "picture": {
                        "large": require('../images/a16.jpeg'),
                    },
                    "description": "小女生的画作"
                },
                {
                    "name": {
                        "last": "再会"
                    },
                    "picture": {
                        "large": require('../images/a13.jpeg'),
                    },
                    "description": "有点普通了"
                },
                
        
            ]
        },
        {
            id: 6,
            url: require('../images/s6.jpeg'),
            des: "asterpiece, best quality, intricate detail, 1girl, sooogs, black shirt, urban, street, walking, light smile, holding water bottle",
            message: 6,
            heart: 0,
            listResult: [
                {
                    "name": {
                        "last": "桃子coo"
                    },
                    "picture": {
                        "large": require('../images/a14.jpeg'),
                    },
                    "description": "这是女娲吗哈哈哈哈"
                },
                {
                    "name": {
                        "last": "小史"
                    },
                    "picture": {
                        "large": require('../images/a12.jpeg'),
                    },
                    "description": "好看啊"
                },
                {
                    "name": {
                        "last": "nicy"
                    },
                    "picture": {
                        "large": require('../images/a2.png'),
                    },
                    "description": "好看好看的"
                },
                {
                    "name": {
                        "last": "flutancy"
                    },
                    "picture": {
                        "large": require('../images/a8.jpeg'),
                    },
                    "description": "我喜欢这个风格！"
                },
                {
                    "name": {
                        "last": "再会"
                    },
                    "picture": {
                        "large": require('../images/a10.jpeg'),
                    },
                    "description": "这张艺术了"
                },
            
        
            ]
        },
        {
            id: 7,
            url: require('../images/s7.jpeg'),
            des: "cinematic photo cinematic film still a activist cat rally, protesting against war, making a peace sign",
            message: 0,
            heart: 0
        },
        {
            id: 8,
            url: require('../images/s8.jpeg'),
            des: "art by Peter Cross, Technical illustration, Raging epic, landscape, background, Stars in the sky, psychedelic colors, taiji, Golden ratio",
            message: 32,
            heart: 22
        },
        {
            id: 9,
            url: require('../images/s9.jpeg'),
            des: "FluffyStyle award winning beautiful portrait commission of a male furry anthro albino wolf fursona with a tail and a cute beautiful attractive detailed furry face wearing stylish black",
            message: 3,
            heart: 12
        },
        {
            id: 10,
            url: require('../images/s10.jpeg'),
            des: "FluffyStyle award winning beautiful portrait commission of a male furry anthro albino wolf fursona with a tail and a cute beautiful attractive detailed furry face wearing stylish black",
            message: 8,
            heart: 15
        },
        {
            id: 11,
            url: require('../images/s11.jpeg'),
            des: "art by Peter Cross, Technical illustration, Raging epic, landscape, background, Stars in the sky, psychedelic colors, taiji, Golden ratio",
            message: 0,
            heart: 5
        },
        {
            id: 12,
            url: require('../images/s12.jpeg'),
            des: "Anime artwork, open trunk of a car, filled with trash, Woman, long hair, art by J.C. Leyendecker",
            message: 0,
            heart: 7
        },
        {
            id: 13,
            url: require('../images/s13.jpeg'),
            des: "art by Peter Cross, Technical illustration, Raging epic, landscape, background, Stars in the sky, psychedelic colors, taiji, Golden ratio",
            message: 17,
            heart: 6
        },
        {
            id: 14,
            url: require('../images/s14.jpeg'),
            des: "Anime artwork, open trunk of a car, filled with trash, Woman, long hair, art by J.C. Leyendecker",
            message: 22,
            heart: 13
        },
        {
            id: 15,
            url: require('../images/s15.jpeg'),
            des: "Anime artwork, open trunk of a car, filled with trash, Woman, long hair, art by J.C. Leyendecker",
            message: 23,
            heart: 86
        },
        {
            id: 16,
            url: require('../images/s16.jpeg'),
            des: "masterpiece, highly detailed, realistic, lakeside, beside a lake, foliage, forest, (standing on a wooden pier:1.4), 1girl cute, kawaii",
            message: 10,
            heart: 3
        },
        {
            id: 17,
            url: require('../images/s17.jpeg'),
            des: "art by Peter Cross, Technical illustration, Raging epic, landscape, background, Stars in the sky, psychedelic colors, taiji, Golden ratio",
            message: 0,
            heart: 1
        },
        {
            id: 18,
            url: require('../images/s18.jpeg'),
            des: "an optical illusion of the universe inside a glass jar, intricate detail, volumetric lighting, epic composition, hyper detailed, ultra realistic, sharp focus, octane render, volumetric",
            message: 0,
            heart: 0
        },

    ]

    useEffect(() => {
        localStorage.setItem("myImages", JSON.stringify(myImages));
        localStorage.setItem("myMyImages", JSON.stringify(myMyImages));
        localStorage.setItem("myMyImages2", JSON.stringify(myMyImages2));
        localStorage.setItem("storeImages", JSON.stringify(storeImages));
        localStorage.setItem("mainPage", JSON.stringify(mainPage));

        const query = parseQuery();
        let storageUser = umbrella.getLocalStorage('user');

        if (!storageUser && query.code) {
            gitOauthToken(query.code as string).then((res: any) => {
                gitOauthInfo(res.access_token).then((info: any) => {
                    setUser({
                        user: info,
                    });
                    umbrella.setLocalStorage('user', info);
                });
            });
        } else {
            setUser({
                user: storageUser,
            });
        }
    }, []);

    const screenFull = () => {
        if (screenfull.isEnabled) {
            screenfull.toggle();
        }
    };
    const menuClick = (e: any) => {
        window.scrollTo(0, 0)
        e.key === 'logout' && logout();
    };
    const logout = () => {
        localStorage.setItem("user", "");
        history.push('/login');
    };
    const menu = (
        <Menu style={{ backgroundColor: "#313753" }}>
            <Menu.Item key="logout">
                <span style={{ color: "#fff" }} onClick={() => { window.location.hash = '/app/ui/MainPage' }}>个人中心</span>
            </Menu.Item>
            <Menu.Item key="logout">
                <span style={{ color: "#fff" }} onClick={logout}>退出登录</span>
            </Menu.Item>
        </Menu>
    );
    return (
        <Header className="custom-theme header" style={{ position: "sticky", top: "0" }}>
            {/* {responsive?.isMobile ? (
                <Popover
                    content={<SiderCustom popoverHide={turn.turnOff} />}
                    trigger="click"
                    placement="bottomLeft"
                    visible={visible}
                    onVisibleChange={(visible) => (visible ? turn.turnOn() : turn.turnOff())}
                >
                    <BarsOutlined className="header__trigger custom-trigger" />
                </Popover>
            ) : props.collapsed ? (
                <MenuUnfoldOutlined
                    className="header__trigger custom-trigger"
                    onClick={props.toggle}
                />
            ) : (
                <MenuFoldOutlined
                    className="header__trigger custom-trigger"
                    onClick={props.toggle}
                />
            )} */}
            <Menu
                mode="horizontal"
                style={{ lineHeight: '64px', float: 'right' }}
                onClick={menuClick}
                defaultSelectedKeys={['/app/ui/buttons']}
            >
                {/* <Menu.Item key="pwa">
                    <PwaInstaller />
                </Menu.Item> */}
                <Menu.Item key={"/app/ui/buttons"}>
                    <Link to={"/app/ui/buttons"}>
                        <span className="nav-text">首页</span>
                    </Link>
                </Menu.Item>
                <Menu.Item key={"/app/ui/spins"}>
                    <Link to={"/app/ui/spins"}>
                        <span className="nav-text">炼图</span>
                    </Link>
                </Menu.Item>
                <Menu.Item key={"/app/ui/ImagesPage?ai"}>
                    <Link to={"/app/ui/ImagesPage?ai"}>
                        <span className="nav-text">AI作品展</span>
                    </Link>
                </Menu.Item>
                <Menu.Item key={"/app/ui/ImagesPage?shop"}>
                    <Link to={"/app/ui/ImagesPage?shop"}>
                        <span className="nav-text">商户作品展</span>
                    </Link>
                </Menu.Item>

                <Menu.Item key={"/app/ui/Cooperate"}>
                    <Link to={"/app/ui/Cooperate"}>
                        <span className="nav-text">进行合作</span>
                    </Link>
                </Menu.Item>
                <Menu.Item key="full">
                    <ArrowsAltOutlined onClick={screenFull} />
                </Menu.Item>
                <Menu.Item key="1">
                    <Badge count={25} overflowCount={10} style={{ marginLeft: 10 }}>
                        <NotificationOutlined />
                    </Badge>
                </Menu.Item>
                <Dropdown overlay={menu} placement="bottomRight">
                    <span className="avatar">
                        <img src={require('../images/head.jpg')} alt="头像" />
                        <i className="on bottom b-white" />
                    </span>
                </Dropdown>
                {/* <SubMenu
                    title={
                        <span className="avatar">
                            <img src={avater} alt="头像" />
                            <i className="on bottom b-white" />
                        </span>
                    }
                >
                    <MenuItemGroup title="用户中心">
                        <Menu.Item key="setting:1">你好 - {user?.userName}</Menu.Item>
                        <Menu.Item key="setting:2">个人信息</Menu.Item>
                        <Menu.Item key="logout">
                            <span onClick={logout}>退出登录</span>
                        </Menu.Item>
                    </MenuItemGroup>
                    <MenuItemGroup title="设置中心">
                        <Menu.Item key="setting:3">个人设置</Menu.Item>
                        <Menu.Item key="setting:4">系统设置</Menu.Item>
                    </MenuItemGroup>
                </SubMenu> */}
            </Menu>
            <style>{`
                    .ant-menu-horizontal > .ant-menu-item > a{
                        color: #43dfe7;
                    }
                    .ant-menu-horizontal > .ant-menu-item > a:hover{
                        color: #43dfe7;
                    }
                    .ant-menu-horizontal > .ant-menu-item-selected > a {
                        color: #fff;
                    }
                    .ant-menu-horizontal > .ant-menu-item-selected > a:hover {
                        color: #fff;
                    }
                    
                `}</style>
        </Header>
    );
};

export default HeaderCustom;
