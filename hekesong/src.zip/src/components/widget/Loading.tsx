import React from 'react';

export default () => (
    <div
        style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}
    >
        页面加载中...
    </div>
);
