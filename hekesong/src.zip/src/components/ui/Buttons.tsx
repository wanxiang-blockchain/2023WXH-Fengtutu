/**
 * Created by hao.cheng on 2017/4/23.
 */
import React, { useEffect } from 'react';
import { Row, Col, Card, Carousel, Image, Button, Modal, Progress, Spin } from 'antd';
import { DoubleRightOutlined } from '@ant-design/icons';
import { HeartTwoTone, MessageOutlined } from '@ant-design/icons';
import BreadcrumbCustom from '../widget/BreadcrumbCustom';
import { RadioChangeEvent } from 'antd/lib/radio';
import { ButtonSize } from 'antd/lib/button';
import { DownOutlined, LeftOutlined, RightOutlined } from '@ant-design/icons';

type ButtonsState = {
    size: ButtonSize;
    loading: boolean;
    iconLoading: boolean;
    drawerOpen: boolean;
    imageData: any;
    startPublish: boolean;
    countDownTime: any;
    loadingText: any;
    spinLoading: boolean
};
const contentStyle: React.CSSProperties = {
    height: '160px',
    color: '#fff',
    lineHeight: '160px',
    textAlign: 'center',
    background: '#364d79',
};
class Buttons extends React.Component<any, ButtonsState> {
    constructor(props: any) {
        super(props);
        this.state = {
            size: 'middle',
            loading: false,
            iconLoading: false,
            drawerOpen: false,
            imageData: {},
            startPublish: false,
            countDownTime: 0,
            loadingText: "正在生成签名……",
            spinLoading: false
        };
    }
    container = document.querySelector(".app_layout");

    componentDidMount() {
        if (this.container) {
            this.container.scrollTo(0, 0);
        }
        this.setState({ spinLoading: true });
        setTimeout(() => {
            this.setState({ spinLoading: false });
        }, 1000);
    }
    myImage: any = JSON.parse(localStorage.getItem("myImages") || "[]")
    storeImages: any = JSON.parse(localStorage.getItem("storeImages") || "[]")
    handleSizeChange = (e: RadioChangeEvent) => {
        this.setState({ size: e.target.value });
    };
    handleMenuClick = (e: any) => {
        console.log('click', e);
    };
    enterLoading = () => {
        this.setState({ loading: true });
    };
    enterIconLoading = () => {
        this.setState({ iconLoading: true });
    };
    drawerOnClose = () => {
        this.setState({
            drawerOpen: false,
        });
    };
    openDrawer = (type: any) => {
        // this.setState({
        //     drawerOpen: true,
        // });
        window.location.hash = `/app/ui/ImagesPage?${type}`
    };
    publishImage = (data: any) => {
        // if(data.publish){
        //     window.location.hash = '/app/ui/ImageDetail'
        // }else{
        //     this.setState({ imageData: data });
        //     this.setState({ loading: true });
        // }
        localStorage.setItem("imageData", JSON.stringify(data))
        window.location.hash = '/app/ui/ImageDetail?outside'

    }
    startPublish = () => {
        this.setState({ loading: false });

        this.setState({ startPublish: true });
        this.countStart()

    }
    countStart = () => {
        let countDownTime = this.state.countDownTime
        let timer = window.setInterval(() => {
            if (countDownTime > 99) {
                window.clearInterval(timer);
            } else {
                this.setState({ countDownTime: (countDownTime++) }, () => {
                    if (countDownTime == 51) {
                        this.setState({ loadingText: "正在上链……" })
                    }
                    if (countDownTime == 100) {
                        let copyimage = this.myImage
                        copyimage.forEach((element: any) => {
                            if (element.id === this.state.imageData.id) {
                                element.publish = true
                            }
                        });
                        this.setState({ loadingText: "上链成功" })
                        localStorage.setItem("myImages", JSON.stringify(copyimage));
                        setTimeout(() => {
                            this.setState({ startPublish: false });
                        }, 1500);
                        // window.setInterval(() => {
                        //     this.setState({ startPublish: false });
                        // }, 1500)

                    }
                });
            }
        }, 20)
    }
    render() {
        // const size = this.state.size;
        // const menu = (
        //     <Menu onClick={this.handleMenuClick}>
        //         <Menu.Item key="1">1st item</Menu.Item>
        //         <Menu.Item key="2">2nd item</Menu.Item>
        //         <Menu.Item key="3">3rd item</Menu.Item>
        //     </Menu>
        // );
        return (
            <div className="gutter-example button-demo">
                {/* <BreadcrumbCustom breads={['UI', '按钮']} />
                <Row gutter={16}>
                    <Col className="gutter-row" md={12}>
                        <div className="gutter-box">
                            <Card bordered={false}>
                                <Button type="primary">Primary</Button>
                                <Button>Default</Button>
                                <Button type="dashed">Dashed</Button>
                                <Button danger>Danger</Button>
                            </Card>
                        </div>
                    </Col>
                    <Col className="gutter-row" md={12}>
                        <div className="gutter-box">
                            <Card bordered={false}>
                                <Button type="primary" shape="circle" icon="search" />
                                <Button type="primary" icon="search">
                                    Search
                                </Button>
                                <Button shape="circle" icon="search" />
                                <Button icon="search">Search</Button>
                                <br />
                                <Button shape="circle" icon="search" />
                                <Button icon="search">Search</Button>
                                <Button type="dashed" shape="circle" icon="search" />
                                <Button type="dashed" icon="search">
                                    Search
                                </Button>
                            </Card>
                        </div>
                    </Col>
                    <Col className="gutter-row" md={12}>
                        <div className="gutter-box">
                            <Card bordered={false}>
                                <Radio.Group value={size} onChange={this.handleSizeChange}>
                                    <Radio.Button value="large">Large</Radio.Button>
                                    <Radio.Button value="middle">Middle</Radio.Button>
                                    <Radio.Button value="small">Small</Radio.Button>
                                </Radio.Group>
                                <br />
                                <br />
                                <Button type="primary" shape="circle" icon="download" size={size} />
                                <Button type="primary" icon="download" size={size}>
                                    Download
                                </Button>
                                <Button type="primary" size={size}>
                                    Normal
                                </Button>
                                <br />
                                <Button.Group size={size}>
                                    <Button type="primary">
                                        <LeftOutlined />
                                        Backward
                                    </Button>
                                    <Button type="primary">
                                        Forward
                                        <RightOutlined />
                                    </Button>
                                </Button.Group>
                            </Card>
                        </div>
                    </Col>
                    <Col className="gutter-row" md={12}>
                        <div className="gutter-box">
                            <Card bordered={false}>
                                <Button type="primary">primary</Button>
                                <Button>secondary</Button>
                                <Dropdown overlay={menu}>
                                    <Button>
                                        more <DownOutlined />
                                    </Button>
                                </Dropdown>
                            </Card>
                        </div>
                    </Col>
                    <Col className="gutter-row" md={12}>
                        <div className="gutter-box">
                            <Card bordered={false}>
                                <Button type="primary" loading>
                                    Loading
                                </Button>
                                <Button type="primary" size="small" loading>
                                    Loading
                                </Button>
                                <br />
                                <Button
                                    type="primary"
                                    loading={this.state.loading}
                                    onClick={this.enterLoading}
                                >
                                    Click me!
                                </Button>
                                <Button
                                    type="primary"
                                    icon="poweroff"
                                    loading={this.state.iconLoading}
                                    onClick={this.enterIconLoading}
                                >
                                    Click me!
                                </Button>
                                <br />
                                <Button shape="circle" loading />
                                <Button type="primary" shape="circle" loading />
                            </Card>
                        </div>
                    </Col>
                </Row>
                <style>{`
                    .button-demo .ant-btn {
                        margin-right: 8px;
                        margin-bottom: 12px;
                    }
                `}</style> */}
                <Spin spinning={this.state.spinLoading}>

                    <Row gutter={16}>
                        <Col className="gutter-row" md={24}>
                            <div className="gutter-box">
                                <Card bordered={false}>
                                    <Carousel autoplay>
                                        <div className='background'>
                                            <Image
                                                className='carousel-image'
                                                src={require('../../images/66.jpg')}
                                            />
                                        </div>
                                        <div className='background'>
                                            <Image
                                                className='carousel-image'
                                                src={require('../../images/1.png')}
                                            />
                                        </div>
                                        <div className='background'>
                                            <Image
                                                className='carousel-image'
                                                src={require('../../images/11.jpg')}
                                            />
                                        </div>
                                        <div className='background'>
                                            <Image
                                                className='carousel-image'
                                                src={require('../../images/2.jpg')}
                                            />
                                        </div>
                                        <div className='background'>
                                            <Image
                                                className='carousel-image'
                                                src={require('../../images/10.jpg')}
                                            />
                                        </div>
                                        <div className='background'>
                                            <Image
                                                className='carousel-image'
                                                src={require('../../images/3.jpg')}
                                            />
                                        </div>
                                    </Carousel>
                                </Card>
                            </div>
                        </Col>
                        <Col className="gutter-row" md={24}>
                            <div className="gutter-box">
                                <Card bordered={false}>
                                    <div style={{ width: "125px", fontSize: "18px", margin: "0 auto", color: "#25262C" }}>AI作品展</div>
                                    <Row gutter={16}>
                                        <Col className="gutter-row" md={4}>
                                            <div className="gutter-box">
                                                <Card bordered={false} className='mycard'>
                                                    {/* <div className={`publish ${this.myImage[0].publish ? "success" : "waitting"}`}></div>
                                                <div className='publistText'>{this.myImage[0].publish ? "已发布" : "未发布"}</div> */}
                                                    <Image
                                                        className='my-album-image'
                                                        src={this.myImage[0]?.url}
                                                        preview={false}
                                                        onClick={() => this.publishImage(this.myImage[0])}
                                                    />
                                                    <div>
                                                        <div>
                                                            <span style={{ marginRight: "20px", fontSize: "20px" }}>
                                                                <MessageOutlined style={{ color: "#C1C2C5", margin: "0 15px 0 0" }} />
                                                                <span style={{ color: "#C1C2C5" }}>{this.myImage[0]?.message}</span>
                                                            </span>
                                                            <span style={{ marginRight: "20px", fontSize: "20px" }}>
                                                                <HeartTwoTone twoToneColor="#eb2f96" style={{ margin: "0 15px" }} />
                                                                <span style={{ color: "#C1C2C5" }}>{this.myImage[0]?.heart}</span>
                                                            </span>
                                                        </div>
                                                    </div>
                                                </Card>
                                            </div>
                                        </Col>

                                        <Col className="gutter-row" md={4}>
                                            <div className="gutter-box">
                                                <Card bordered={false} className='mycard'>
                                                    {/* <div className={`publish ${this.myImage[1].publish ? "success" : "waitting"}`}></div>
                                                <div className='publistText'>{this.myImage[1].publish ? "已发布" : "未发布"}</div> */}
                                                    <Image
                                                        className='my-album-image'
                                                        src={this.myImage[1]?.url}
                                                        preview={false}
                                                        onClick={() => this.publishImage(this.myImage[1])}
                                                    />
                                                    <div>
                                                        <div>
                                                            <span style={{ marginRight: "20px", fontSize: "20px" }}>
                                                                <MessageOutlined style={{ color: "#C1C2C5", margin: "0 15px 0 0" }} />
                                                                <span style={{ color: "#C1C2C5" }}>{this.myImage[1]?.message}</span>
                                                            </span>
                                                            <span style={{ marginRight: "20px", fontSize: "20px" }}>
                                                                <HeartTwoTone twoToneColor="#eb2f96" style={{ margin: "0 15px" }} />
                                                                <span style={{ color: "#C1C2C5" }}>{this.myImage[1]?.heart}</span>
                                                            </span>
                                                        </div>
                                                    </div>
                                                </Card>
                                            </div>
                                        </Col>
                                        <Col className="gutter-row" md={4}>
                                            <div className="gutter-box">
                                                <Card bordered={false} className='mycard'>
                                                    {/* <div className={`publish ${this.myImage[2].publish ? "success" : "waitting"}`}></div>
                                                <div className='publistText'>{this.myImage[2].publish ? "已发布" : "未发布"}</div> */}
                                                    <Image
                                                        className='my-album-image'
                                                        src={this.myImage[2]?.url}
                                                        preview={false}
                                                        onClick={() => this.publishImage(this.myImage[2])}
                                                    />
                                                    <div>
                                                        <div>
                                                            <span style={{ marginRight: "20px", fontSize: "20px" }}>
                                                                <MessageOutlined style={{ color: "#C1C2C5", margin: "0 15px 0 0" }} />
                                                                <span style={{ color: "#C1C2C5" }}>{this.myImage[2]?.message}</span>
                                                            </span>
                                                            <span style={{ marginRight: "20px", fontSize: "20px" }}>
                                                                <HeartTwoTone twoToneColor="#eb2f96" style={{ margin: "0 15px" }} />
                                                                <span style={{ color: "#C1C2C5" }}>{this.myImage[2]?.heart}</span>
                                                            </span>
                                                        </div>
                                                    </div>
                                                </Card>
                                            </div>
                                        </Col>
                                        <Col className="gutter-row" md={4}>
                                            <div className="gutter-box">
                                                <Card bordered={false} className='mycard'>
                                                    {/* <div className={`publish ${this.myImage[3].publish ? "success" : "waitting"}`}></div>
                                                <div className='publistText'>{this.myImage[3].publish ? "已发布" : "未发布"}</div> */}
                                                    <Image
                                                        className='my-album-image'
                                                        src={this.myImage[3]?.url}
                                                        preview={false}
                                                        onClick={() => this.publishImage(this.myImage[3])}
                                                    />
                                                    <div>
                                                        <div>
                                                            <span style={{ marginRight: "20px", fontSize: "20px" }}>
                                                                <MessageOutlined style={{ color: "#C1C2C5", margin: "0 15px 0 0" }} />
                                                                <span style={{ color: "#C1C2C5" }}>{this.myImage[3]?.message}</span>
                                                            </span>
                                                            <span style={{ marginRight: "20px", fontSize: "20px" }}>
                                                                <HeartTwoTone twoToneColor="#eb2f96" style={{ margin: "0 15px" }} />
                                                                <span style={{ color: "#C1C2C5" }}>{this.myImage[3]?.heart}</span>
                                                            </span>
                                                        </div>
                                                    </div>
                                                </Card>
                                            </div>
                                        </Col>
                                        <Col className="gutter-row" md={4}>
                                            <div className="gutter-box">
                                                <Card bordered={false} className='mycard'>
                                                    {/* <div className={`publish ${this.myImage[4].publish ? "success" : "waitting"}`}></div>
                                                <div className='publistText'>{this.myImage[4].publish ? "已发布" : "未发布"}</div> */}
                                                    <Image
                                                        className='my-album-image'
                                                        src={this.myImage[4]?.url}
                                                        preview={false}
                                                        onClick={() => this.publishImage(this.myImage[4])}
                                                    />
                                                    <div>
                                                        <div>
                                                            <span style={{ marginRight: "20px", fontSize: "20px" }}>
                                                                <MessageOutlined style={{ color: "#C1C2C5", margin: "0 15px 0 0" }} />
                                                                <span style={{ color: "#C1C2C5" }}>{this.myImage[4]?.message}</span>
                                                            </span>
                                                            <span style={{ marginRight: "20px", fontSize: "20px" }}>
                                                                <HeartTwoTone twoToneColor="#eb2f96" style={{ margin: "0 15px" }} />
                                                                <span style={{ color: "#C1C2C5" }}>{this.myImage[4]?.heart}</span>
                                                            </span>
                                                        </div>
                                                    </div>
                                                </Card>
                                            </div>
                                        </Col>
                                        <Col className="gutter-row" md={4}>
                                            <div className="gutter-box">
                                                <Card bordered={false} className='mycard'>
                                                    {/* <div className={`publish ${this.myImage[5].publish ? "success" : "waitting"}`}></div>
                                                <div className='publistText'>{this.myImage[5].publish ? "已发布" : "未发布"}</div> */}
                                                    <Image
                                                        className='my-album-image'
                                                        src={this.myImage[5]?.url}
                                                        preview={false}
                                                        onClick={() => this.publishImage(this.myImage[5])}
                                                    />
                                                    <div>
                                                        <div>
                                                            <span style={{ marginRight: "20px", fontSize: "20px" }}>
                                                                <MessageOutlined style={{ color: "#C1C2C5", margin: "0 15px 0 0" }} />
                                                                <span style={{ color: "#C1C2C5" }}>{this.myImage[5]?.message}</span>
                                                            </span>
                                                            <span style={{ marginRight: "20px", fontSize: "20px" }}>
                                                                <HeartTwoTone twoToneColor="#eb2f96" style={{ margin: "0 15px" }} />
                                                                <span style={{ color: "#C1C2C5" }}>{this.myImage[5]?.heart}</span>
                                                            </span>
                                                        </div>
                                                    </div>
                                                </Card>
                                            </div>
                                        </Col>

                                    </Row>
                                    <Button onClick={() => this.openDrawer("ai")} style={{ float: "right" }}>
                                        更多
                                        <DoubleRightOutlined />
                                    </Button>
                                </Card>
                            </div>
                        </Col>
                        <Col className="gutter-row" md={24}>
                            <div className="gutter-box">
                                <Card bordered={false}>
                                    <div style={{ width: "125px", fontSize: "18px", margin: "0 auto", color: "#25262C" }}>商户作品展</div>
                                    <Row gutter={16}>
                                        <Col className="gutter-row" md={4}>
                                            <div className="gutter-box">
                                                <Card bordered={false}>
                                                    <Image
                                                        className='my-album-image'
                                                        src={this.storeImages[0].url}
                                                        preview={false}
                                                        onClick={() => this.publishImage(this.storeImages[0])}
                                                    />
                                                    <div>
                                                        <div>
                                                            <span style={{ marginRight: "20px", fontSize: "20px" }}>
                                                                <MessageOutlined style={{ color: "#C1C2C5", margin: "0 15px 0 0" }} />
                                                                <span style={{ color: "#C1C2C5" }}>{this.storeImages[0]?.message}</span>
                                                            </span>
                                                            <span style={{ marginRight: "20px", fontSize: "20px" }}>
                                                                <HeartTwoTone twoToneColor="#eb2f96" style={{ margin: "0 15px" }} />
                                                                <span style={{ color: "#C1C2C5" }}>{this.storeImages[0]?.heart}</span>
                                                            </span>
                                                        </div>
                                                    </div>
                                                </Card>
                                            </div>
                                        </Col>

                                        <Col className="gutter-row" md={4}>
                                            <div className="gutter-box">
                                                <Card bordered={false}>
                                                    <Image
                                                        className='my-album-image'
                                                        src={this.storeImages[1]?.url}
                                                        preview={false}
                                                        onClick={() => this.publishImage(this.storeImages[1])}
                                                    />
                                                    <div>
                                                        <div>
                                                            <span style={{ marginRight: "20px", fontSize: "20px" }}>
                                                                <MessageOutlined style={{ color: "#C1C2C5", margin: "0 15px 0 0" }} />
                                                                <span style={{ color: "#C1C2C5" }}>{this.storeImages[1]?.message}</span>
                                                            </span>
                                                            <span style={{ marginRight: "20px", fontSize: "20px" }}>
                                                                <HeartTwoTone twoToneColor="#eb2f96" style={{ margin: "0 15px" }} />
                                                                <span style={{ color: "#C1C2C5" }}>{this.storeImages[1]?.heart}</span>
                                                            </span>
                                                        </div>
                                                    </div>
                                                </Card>
                                            </div>
                                        </Col>
                                        <Col className="gutter-row" md={4}>
                                            <div className="gutter-box">
                                                <Card bordered={false}>
                                                    <Image
                                                        className='my-album-image'
                                                        src={this.storeImages[2]?.url}
                                                        preview={false}
                                                        onClick={() => this.publishImage(this.storeImages[2])}
                                                    />
                                                    <div>
                                                        <div>
                                                            <span style={{ marginRight: "20px", fontSize: "20px" }}>
                                                                <MessageOutlined style={{ color: "#C1C2C5", margin: "0 15px 0 0" }} />
                                                                <span style={{ color: "#C1C2C5" }}>{this.storeImages[2]?.message}</span>
                                                            </span>
                                                            <span style={{ marginRight: "20px", fontSize: "20px" }}>
                                                                <HeartTwoTone twoToneColor="#eb2f96" style={{ margin: "0 15px" }} />
                                                                <span style={{ color: "#C1C2C5" }}>{this.storeImages[2]?.heart}</span>
                                                            </span>
                                                        </div>
                                                    </div>
                                                </Card>
                                            </div>
                                        </Col>
                                        <Col className="gutter-row" md={4}>
                                            <div className="gutter-box">
                                                <Card bordered={false}>
                                                    <Image
                                                        className='my-album-image'
                                                        src={this.storeImages[3]?.url}
                                                        preview={false}
                                                        onClick={() => this.publishImage(this.storeImages[3])}
                                                    />
                                                    <div>
                                                        <div>
                                                            <span style={{ marginRight: "20px", fontSize: "20px" }}>
                                                                <MessageOutlined style={{ color: "#C1C2C5", margin: "0 15px 0 0" }} />
                                                                <span style={{ color: "#C1C2C5" }}>{this.storeImages[3]?.message}</span>
                                                            </span>
                                                            <span style={{ marginRight: "20px", fontSize: "20px" }}>
                                                                <HeartTwoTone twoToneColor="#eb2f96" style={{ margin: "0 15px" }} />
                                                                <span style={{ color: "#C1C2C5" }}>{this.storeImages[3]?.heart}</span>
                                                            </span>
                                                        </div>
                                                    </div>
                                                </Card>
                                            </div>
                                        </Col>
                                        <Col className="gutter-row" md={4}>
                                            <div className="gutter-box">
                                                <Card bordered={false}>
                                                    <Image
                                                        className='my-album-image'
                                                        src={this.storeImages[4]?.url}
                                                        preview={false}
                                                        onClick={() => this.publishImage(this.storeImages[4])}
                                                    />
                                                    <div>
                                                        <div>
                                                            <span style={{ marginRight: "20px", fontSize: "20px" }}>
                                                                <MessageOutlined style={{ color: "#C1C2C5", margin: "0 15px 0 0" }} />
                                                                <span style={{ color: "#C1C2C5" }}>{this.storeImages[4]?.message}</span>
                                                            </span>
                                                            <span style={{ marginRight: "20px", fontSize: "20px" }}>
                                                                <HeartTwoTone twoToneColor="#eb2f96" style={{ margin: "0 15px" }} />
                                                                <span style={{ color: "#C1C2C5" }}>{this.storeImages[4]?.heart}</span>
                                                            </span>
                                                        </div>
                                                    </div>
                                                </Card>
                                            </div>
                                        </Col>
                                        <Col className="gutter-row" md={4}>
                                            <div className="gutter-box">
                                                <Card bordered={false}>
                                                    <Image
                                                        className='my-album-image'
                                                        src={this.storeImages[5]?.url}
                                                        preview={false}
                                                        onClick={() => this.publishImage(this.storeImages[5])}
                                                    />
                                                    <div>
                                                        <div>
                                                            <span style={{ marginRight: "20px", fontSize: "20px" }}>
                                                                <MessageOutlined style={{ color: "#C1C2C5", margin: "0 15px 0 0" }} />
                                                                <span style={{ color: "#C1C2C5" }}>{this.storeImages[5]?.message}</span>
                                                            </span>
                                                            <span style={{ marginRight: "20px", fontSize: "20px" }}>
                                                                <HeartTwoTone twoToneColor="#eb2f96" style={{ margin: "0 15px" }} />
                                                                <span style={{ color: "#C1C2C5" }}>{this.storeImages[5]?.heart}</span>
                                                            </span>
                                                        </div>
                                                    </div>
                                                </Card>
                                            </div>
                                        </Col>

                                    </Row>
                                    <Button onClick={() => this.openDrawer("shop")} style={{ float: "right" }}>
                                        更多
                                        <DoubleRightOutlined />
                                    </Button>
                                </Card>
                            </div>
                        </Col>
                        <Modal title={null} visible={this.state.loading} footer={null} style={{ textAlign: "center" }} onCancel={() => this.setState({ loading: false })} maskClosable={false}>
                            <Row gutter={16}>
                                <Col className="gutter-row" md={12}>
                                    <div className="gutter-box">
                                        <Card bordered={false}>
                                            <Image
                                                className='my-album-image'
                                                src={this.state.imageData.url}
                                            />
                                        </Card>
                                    </div>
                                </Col>
                                <Col className="gutter-row" md={12}>
                                    <div className="gutter-box">
                                        <Card bordered={false}>
                                            <div>{this.state.imageData?.des}</div>
                                            <Button onClick={this.startPublish}>
                                                开始发布
                                            </Button>
                                            <Button onClick={() => { window.location.hash = '/app/ui/ImageDetail?notPublish' }}>
                                                查看详情
                                            </Button>
                                        </Card>
                                    </div>
                                </Col>

                            </Row>
                        </Modal>
                        <Modal title={null} visible={this.state.startPublish} footer={null} style={{ textAlign: "center" }} closable={false} maskClosable={false}>
                            <Progress type="circle" percent={this.state.countDownTime} strokeColor={{ '0%': '#108ee9', '100%': '#87d068' }} />
                            <div style={{ color: "#C1C2C5", margin: "20px 0" }}>{this.state.loadingText}</div>
                        </Modal>
                    </Row>
                </Spin>

                {/* <Drawer
                    title="Drawer with extra actions"
                    width={500}
                    onClose={this.drawerOnClose}
                    visible={this.state.drawerOpen}
                >
                    <Space>
                        <Button onClick={this.drawerOnClose}>Cancel</Button>
                        <Button type="primary" onClick={this.drawerOnClose}>
                            OK
                        </Button>
                    </Space>
                </Drawer> */}
                <style>{`
                    .gutter-box {
                        text-align: center;
                        
                    }
                    .ant-modal-body {
                        background-color: #25262C;
                    }
                    .ant-progress-circle .ant-progress-text {
                        color: #C1C2C5;
                    }
                    .slick-track{
                        height:378px;
                    }
                    .background {
                        background: #9f63d2;
                    }
                    .ant-image-img {
                        height:380px;
                        width: 100%;
                        
                    }
                    .button-demo .ant-btn {
                        margin-right: 8px;
                        margin-bottom: 12px;
                    }
                    .mycard {
                        posititon: relative;
                    }
                    .publish {
                        width: 0;
                        height: 0;
                        border-top: 43px solid skyblue;
                        border-right: 100px solid transparent;
                        position: absolute;
                        z-index: 20;
                    }
                    .success {
                        border-block-color: #86f165;
                    }
                    .waitting {
                        border-block-color: #f9ee33;
                    }
                    .publistText{
                        position: absolute;
                        color: #fff;
                        z-index: 25;
                        top: 28px;
                        left: 28px;
                    }
                `}</style>
            </div>
        );
    }
}

export default Buttons;
