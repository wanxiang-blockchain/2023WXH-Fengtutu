/**
 * Created by hao.cheng on 2017/4/23.
 */
import React from 'react';
import * as moment from 'moment';
import { Row, Col, Card, List, Image, Button, Avatar, Modal, Progress, Spin } from 'antd';
import { HeartTwoTone, MessageOutlined } from '@ant-design/icons';
import BreadcrumbCustom from '../widget/BreadcrumbCustom';
import { RadioChangeEvent } from 'antd/lib/radio';
import { ButtonSize } from 'antd/lib/button';
import { DownOutlined, LeftOutlined, RightOutlined } from '@ant-design/icons';

type ButtonsState = {
    size: ButtonSize;
    loading: boolean;
    iconLoading: boolean;
    drawerOpen: boolean;
    startPublish: boolean;
    countDownTime: any;
    loadingText: any;
    nowDate: any;
    spinLoading: boolean,
    chainData: any,
};
const contentStyle: React.CSSProperties = {
    height: '160px',
    color: '#fff',
    lineHeight: '160px',
    textAlign: 'center',
    background: '#364d79',
};
class Buttons extends React.Component<any, ButtonsState> {
    constructor(props: any) {
        super(props);
        this.state = {
            size: 'middle',
            loading: false,
            iconLoading: false,
            drawerOpen: false,
            startPublish: false,
            countDownTime: 0,
            loadingText: "正在生成签名……",
            nowDate: null,
            spinLoading: false,
            chainData: {
                hash: "",
                chain: ""
            }
        };
    }
    container = document.querySelector(".app_layout");
    radomData = (min: any, max: any) => {
        return Math.floor(Math.random() * (max - min)) + min
    }
    componentDidMount() {
        if (this.container) {
            this.container.scrollTo(0, 0);
        }
        this.setState({ spinLoading: true });
        setTimeout(() => {
            this.setState({ spinLoading: false });
        }, 1000);
        let chainData: any = {}
        switch (this.radomData(0, 10)) {
            case 1:
                chainData = {
                    hash: "0xb95c882f8cebd601986168fd8cbfe37e3bb681768986168f8db1b9ff8cebd601",
                    chain: "18032327"
                }
                break;
            case 2:
                chainData = {
                    hash: "0xc5e889293381ae0c84c8990b3fb76e3b68170b1352352e8de8db1b9f26ff36d0",
                    chain: "15037333"
                }
                break;
            case 3:
                chainData = {
                    hash: "0xc0dd49fa1c79100419958c8da1726b4c8990419958c0b1352e8db1b9f21835a7",
                    chain: "12035687"
                }
                break;
            case 4:
                chainData = {
                    hash: "0xfba10ed4b1ff818bb5b4d1440fbc8d6ae0c84c898bb5b4d41852e8db1a1726b4",
                    chain: "18122370"
                }
                break;
            case 5:
                chainData = {
                    hash: "0x448ef82943bde9550652a440b980ebe0c84c89e955061352e8db1440b980ebe0",
                    chain: "17212357"
                }
                break;
            case 6:
                chainData = {
                    hash: "0x514d3aca70f976fb7db233096820a3c84c8976fb7db23b68170b135233096820",
                    chain: "13672567"
                }
                break;
            case 7:
                chainData = {
                    hash: "0x1914f71922b3ae8552aed7761d7aa3c8990b3f2aed7761db13521b9f761d7a63",
                    chain: "1176309"
                }
                break;
            case 8:
                chainData = {
                    hash: "0xa217e0b82af5bef7bfc83dc6d245c8284c883dc6d245c3b61352e8db1245c828",
                    chain: "17232677"
                }
                break;
            case 9:
                chainData = {
                    hash: "0x328de3dc02a6cc4f3920f7d93a4da4c4c90f393a4da0b1352e8dba4da4c4c899",
                    chain: "19356937"
                }
                break;
            case 10:
                chainData = {
                    hash: "0xc15935722a37a00e060882a1e4682a1ee3b68170b1352e8db12a1e4624da00e0",
                    chain: "15672378"
                }
                break;
            default:
                chainData = {
                    hash: "0xc678e9293381ae0c84c8990b3fb1835a776e3b68170b1352e8db1b9f26ff68e9",
                    chain: "18032327"
                }
                break;

        }
        this.setState({ chainData });
    }



    imageData = JSON.parse(localStorage.getItem("imageData") || "{}")
    myMyImages: any = JSON.parse(localStorage.getItem("myMyImages") || "[]")
    handleSizeChange = (e: RadioChangeEvent) => {
        this.setState({ size: e.target.value });
    };
    handleMenuClick = (e: any) => {
        console.log('click', e);
    };
    enterLoading = () => {
        this.setState({ loading: true });
    };
    enterIconLoading = () => {
        this.setState({ iconLoading: true });
    };
    drawerOnClose = () => {
        this.setState({
            drawerOpen: false,
        });
    };
    openDrawer = () => {
        this.setState({
            drawerOpen: true,
        });
    };
    startPublish = () => {
        let copyimage = this.myMyImages
        copyimage.forEach((element: any) => {
            if (element.id === this.imageData.id) {
                element.publish = true
            }
        });
        localStorage.setItem("myMyImages", JSON.stringify(copyimage));

        this.setState({ startPublish: true });
        this.countStart()
    }
    fixZero = (num: any, length: any) => {
        let str = "" + num;
        let len = str.length;
        let s = "";
        for (let i = length; i-- > len;) {
            s += "0";
        }
        return s + str;
    }
    countStart = () => {
        let countDownTime = this.state.countDownTime
        let timer = window.setInterval(() => {
            if (countDownTime > 99) {
                window.clearInterval(timer);
            } else {
                this.setState({ countDownTime: (countDownTime++) }, () => {
                    if (countDownTime == 51) {
                        this.setState({ loadingText: "正在上链……" })
                    }
                    if (countDownTime == 100) {
                        // let copyimage = this.myImage
                        // copyimage.forEach((element: any) => {
                        //     if (element.id === this.state.imageData.id) {
                        //         element.publish = true
                        //     }
                        // });
                        this.setState({ loadingText: "上链成功" })
                        // localStorage.setItem("myImages", JSON.stringify(copyimage));
                        let date = new Date()
                        let month = date.getMonth() + 1;

                        let nowDate = date.getFullYear() + "/" + this.fixZero(month, 2) + "/" + this.fixZero(date.getDate(), 2) + " " + this.fixZero(date.getHours(), 2) + ":" + this.fixZero(date.getMinutes(), 2) + ":" + this.fixZero(date.getSeconds(), 2)
                        this.setState({ nowDate });
                        setTimeout(() => {
                            this.setState({ startPublish: false });
                            if (window.location.hash.indexOf("fromCooperate") != -1) {
                                window.location.hash = '/app/ui/ImageDetail?toCooperate'
                            } else {
                                window.location.hash = '/app/ui/ImageDetail'
                            }
                        }, 1500);
                        // window.setInterval(() => {
                        //     this.setState({ startPublish: false });
                        //     if(window.location.hash.indexOf("fromCooperate") != -1){
                        //         window.location.hash = '/app/ui/ImageDetail?toCooperate'
                        //     }else{
                        //         window.location.hash = '/app/ui/ImageDetail'
                        //     }

                        // }, 1500)

                    }
                });
            }
        }, 30)
    }
    toCooperate = () => {
        window.location.hash = '/app/ui/MerchantImage'
    }
    goTraceability = () => {
        if (window.location.hash.indexOf("outside") === -1) {
            window.location.hash = '/app/ui/Traceability'
        } else {
            window.location.hash = '/app/ui/Traceability?outside'
        }

    }
    render() {
        let showBottom1: any = null
        let showBottom2: any = null
        // if (window.location.hash.indexOf("outside") === -1) {
        if (window.location.hash.indexOf("notPublish") === -1) {
            showBottom1 = <Button type="primary" style={{ float: "right" }} onClick={this.goTraceability}>
                作品溯源
            </Button>
        }
        if (window.location.hash.indexOf("toCooperate") != -1) {
            showBottom2 = <Button type="primary" style={{ float: "right", marginRight: "20px" }} onClick={this.toCooperate}>
                去合作
            </Button>
        }
        // }
        return (
            <div className="gutter-example button-demo">
                <Spin spinning={this.state.spinLoading}>
                    <Row gutter={16}>
                        <Col className="gutter-row" md={24}>
                            <div className="gutter-box">
                                <Card bordered={false}>
                                    <Row gutter={16}>
                                        <Col className="gutter-row" md={8}>
                                            <div className="gutter-box">
                                                <Card bordered={false}>
                                                    <Image
                                                        className='my-album-image'
                                                        src={this.imageData.url}
                                                        preview={false}
                                                    />
                                                </Card>
                                            </div>
                                        </Col>
                                        <Col className="gutter-row" md={16}>
                                            <div className="gutter-box" style={{ backgroundColor: "#000" }}>
                                                <Card bordered={false}>
                                                    <div style={{ backgroundColor: "#25262C", height: "50px" }}>
                                                        <span style={{ marginRight: "20px", fontSize: "20px" }}>
                                                            <MessageOutlined style={{ color: "#fff", margin: "0 15px" }} />
                                                            <span style={{ color: "#fff" }}>{this.imageData.message}</span>
                                                        </span>
                                                        <span style={{ marginRight: "20px", fontSize: "20px" }}>
                                                            <HeartTwoTone twoToneColor="#eb2f96" style={{ margin: "0 15px" }} />
                                                            <span style={{ color: "#fff" }}>{this.imageData.heart}</span>
                                                        </span>
                                                        {showBottom1}
                                                        {showBottom2}

                                                    </div>

                                                    <Card bordered={false} style={{ height: "200px", overflowY: "auto", backgroundColor: "#000" }}>
                                                        <List
                                                            className="demo-loadmore-list"
                                                            // loading={true}
                                                            itemLayout="horizontal"
                                                            // loadMore={loadMore}
                                                            dataSource={this.imageData?.listResult}
                                                            style={{ backgroundColor: "#25262C", margin: "10px 15px 0 15px" }}
                                                            renderItem={(item: any) => (
                                                                <List.Item>
                                                                    <List.Item.Meta
                                                                        avatar={<Avatar src={item.picture.large} />}
                                                                        title={item.name?.last}
                                                                        description={item.description}
                                                                    />
                                                                </List.Item>
                                                            )}
                                                        />
                                                    </Card>
                                                </Card>
                                                {
                                                    window.location.hash.indexOf("notPublish") != -1 ?
                                                        <div style={{ backgroundColor: "#000" }}>
                                                            <Button type="primary" style={{ margin: "20px" }} onClick={this.startPublish}>
                                                                开始发布
                                                            </Button>
                                                        </div>
                                                        :
                                                        <div>
                                                            <div style={{ color: "#fff", margin: "15px", fontSize: "16px" }}>链上信息</div>
                                                            <Card bordered={false} style={{ backgroundColor: "#25262C", margin: "0 15px" }}>
                                                                <div style={{ margin: "15px" }}>
                                                                    <div style={{ color: "#fff", margin: "10px 0" }}>作品哈希：</div>
                                                                    {/* <div style={{ color: "#fff" }}>{this.state.chainData.hash}</div> */}
                                                                    <div style={{ color: "#fff" }}>{this.imageData?.chainData?.hash || ""}</div>
                                                                </div>
                                                                <div style={{ margin: "15px" }}>
                                                                    <div style={{ color: "#fff", margin: "10px 0" }}>作品区块：</div>
                                                                    {/* <div style={{ color: "#fff" }}>{this.state.chainData.chain}</div> */}
                                                                    <div style={{ color: "#fff" }}>{this.imageData?.chainData?.chain || ""}</div>
                                                                </div>
                                                                <div style={{ margin: "15px" }}>
                                                                    <div style={{ color: "#fff", margin: "10px 0" }}>交易时间：</div>
                                                                    <div style={{ color: "#fff" }}>{this.state.nowDate ? this.state.nowDate : "2023/08/31 13:00:11"}</div>
                                                                </div>
                                                                <div style={{ margin: "15px" }}>
                                                                    <div style={{ color: "#fff", margin: "10px 0" }}>作品状态：</div>
                                                                    <div style={{ color: "#fff" }}>上链成功</div>
                                                                </div>
                                                            </Card>
                                                        </div>
                                                }

                                                <div>
                                                    <div style={{ color: "#fff", margin: "15px", fontSize: "16px" }}>作者信息</div>
                                                    <Card bordered={false} style={{ backgroundColor: "#25262C", margin: "0 15px" }}>
                                                        <div style={{ margin: "15px" }}>
                                                            <div style={{ color: "#fff", margin: "10px 0" }}>钱包地址：</div>
                                                            <div style={{ color: "#fff" }}>{this.imageData?.qianbao || ""}</div>
                                                        </div>
                                                    </Card>
                                                </div>

                                                <div style={{ backgroundColor: "#000", color: "#fff", margin: "15px", fontSize: "16px" }}>作品信息</div>
                                                <Card bordered={false} style={{ backgroundColor: "#25262C", margin: "0 15px" }}>
                                                    <div style={{ color: "#C1C2C5", margin: "15px" }}>Prompt</div>
                                                    <div style={{ backgroundColor: "#2C2E34", color: "#C1C2C5", margin: "15px", height: "220px", overflowY: "auto" }}>
                                                        {this.imageData?.des}
                                                    </div>
                                                    <div style={{ color: "#C1C2C5", margin: "15px" }}>Negative prompt</div>
                                                    <div style={{ backgroundColor: "#2C2E34", color: "#C1C2C5", margin: "15px", height: "220px", overflowY: "auto" }}>
                                                        furry, [:desaturated:1] [:open mouth:11] [:short hair:5] [:person in the lower background:1] [:cgi:10][:extra limbs:5] [:small parson standing in the bottom of the frame:9]
                                                    </div>
                                                    <div style={{ backgroundColor: "#2C2E34", color: "#C1C2C5", margin: "15px", height: "30px" }}>
                                                        <span>CFG scale:</span>
                                                        <span style={{ display: "inline-block", marginLeft: "10px" }}>4</span>
                                                    </div>
                                                    <div style={{ backgroundColor: "#2C2E34", color: "#C1C2C5", margin: "15px", height: "30px" }}>
                                                        <span>Steps:</span>
                                                        <span style={{ display: "inline-block", marginLeft: "10px" }}>30</span>
                                                    </div>
                                                    <div style={{ backgroundColor: "#2C2E34", color: "#C1C2C5", margin: "15px", height: "30px" }}>
                                                        <span>Seed:</span>
                                                        <span style={{ display: "inline-block", marginLeft: "10px" }}>3017875619</span>
                                                    </div>

                                                </Card>
                                            </div>
                                        </Col>
                                    </Row>
                                </Card>
                            </div>
                        </Col>
                    </Row>
                </Spin>

                <Modal title={null} visible={this.state.startPublish} footer={null} style={{ textAlign: "center" }} closable={false} maskClosable={false}>
                    <Progress type="circle" percent={this.state.countDownTime} strokeColor={{ '0%': '#108ee9', '100%': '#87d068' }} />
                    <div style={{ color: "#C1C2C5", margin: "20px 0" }}>{this.state.loadingText}</div>
                </Modal>
                <style>{`
                    .button-demo .ant-btn {
                        margin-right: 8px;
                        margin-bottom: 12px;
                    }
                    .ant-modal-body {
                        background-color: #25262C;
                    }
                    .ant-progress-circle .ant-progress-text {
                        color: #C1C2C5;
                    }
                    .ant-card-body{
                        padding: 0;
                    }
                    .ant-list-split .ant-list-item {
                        border-bottom: 1px solid #25262C;
                        margin-left: 10px;
                    }
                    .ant-list-item-meta-title{
                        color: #C1C2C5;
                    }
                    .ant-list-item-meta-description{
                        color: #C1C2C5;
                    }
                `}</style>
            </div>
        );
    }
}

export default Buttons;
