/**
 * Created by hao.cheng on 2017/4/23.
 */
import React from 'react';
import { Row, Col, Card, Modal, Image, Button, Carousel, Spin } from 'antd';
import { DoubleRightOutlined } from '@ant-design/icons';
import BreadcrumbCustom from '../widget/BreadcrumbCustom';
import { RadioChangeEvent } from 'antd/lib/radio';
import { ButtonSize } from 'antd/lib/button';
import { DownOutlined, LeftOutlined, RightOutlined } from '@ant-design/icons';

type ButtonsState = {
    size: ButtonSize;
    loading: boolean;
    iconLoading: boolean;
    drawerOpen: boolean;
    imageData: any;
    spinLoading: boolean;
};
const contentStyle: React.CSSProperties = {
    height: '160px',
    color: '#fff',
    lineHeight: '160px',
    textAlign: 'center',
    background: '#364d79',
};
class Buttons extends React.Component<any, ButtonsState> {
    constructor(props: any) {
        super(props);
        this.state = {
            size: 'middle',
            loading: false,
            iconLoading: false,
            drawerOpen: false,
            imageData: null,
            spinLoading: false
        };
    }

    myImages = [
        {
            id: 1,
            url: require('../../images/picture2.jpg')
        },
        {
            id: 2,
            url: require('../../images/picture2.jpg')
        },
        {
            id: 3,
            url: require('../../images/picture2.jpg')
        },
        {
            id: 4,
            url: require('../../images/picture2.jpg')
        },
        {
            id: 5,
            url: require('../../images/picture2.jpg')
        },
        {
            id: 6,
            url: require('../../images/picture2.jpg')
        },
        {
            id: 7,
            url: require('../../images/picture2.jpg')
        },
        {
            id: 8,
            url: require('../../images/picture2.jpg')
        },
        {
            id: 9,
            url: require('../../images/picture2.jpg')
        },
        {
            id: 10,
            url: require('../../images/picture2.jpg')
        },
        {
            id: 11,
            url: require('../../images/picture2.jpg')
        },
        {
            id: 12,
            url: require('../../images/picture2.jpg')
        },
        {
            id: 13,
            url: require('../../images/picture2.jpg')
        },
        {
            id: 14,
            url: require('../../images/picture2.jpg')
        },
    ]
    container = document.querySelector(".app_layout");
    componentDidMount() {
        if (this.container) {
            this.container.scrollTo(0, 0);
        }
        this.setState({ spinLoading: true });
        setTimeout(() => {
            this.setState({ spinLoading: false });
        }, 1000);
    }
    storeImages: any = JSON.parse(localStorage.getItem("storeImages") || "[]")
    handleSizeChange = (e: RadioChangeEvent) => {
        this.setState({ size: e.target.value });
    };
    handleMenuClick = (e: any) => {
        console.log('click', e);
    };
    enterLoading = () => {
        this.setState({ loading: true });
    };
    enterIconLoading = () => {
        this.setState({ iconLoading: true });
    };
    drawerOnClose = () => {
        this.setState({
            drawerOpen: false,
        });
    };
    openDrawer = () => {
        this.setState({
            drawerOpen: true,
        });
    };
    toDetail = () => {
        localStorage.setItem("storeImage", JSON.stringify(this.state.imageData))
        window.location.hash = '/app/ui/Guanlian'
    }
    checkImage = (data: any) => {
        this.setState({ loading: true });
        this.setState({ imageData: data });
    }
    render() {
        return (
            <div className="gutter-example button-demo">
                <Spin spinning={this.state.spinLoading}>
                    <Row gutter={16}>
                        <Col className="gutter-row" md={24}>
                            <div className="gutter-box">
                                <Card bordered={false}>
                                    <Carousel autoplay>
                                        <div className='background'>
                                            <Image
                                                className='carousel-image'
                                                src={require('../../images/66.jpg')}
                                            />
                                        </div>
                                        <div className='background'>
                                            <Image
                                                className='carousel-image'
                                                src={require('../../images/1.png')}
                                            />
                                        </div>
                                        <div className='background'>
                                            <Image
                                                className='carousel-image'
                                                src={require('../../images/11.jpg')}
                                            />
                                        </div>
                                        <div className='background'>
                                            <Image
                                                className='carousel-image'
                                                src={require('../../images/2.jpg')}
                                            />
                                        </div>
                                        <div className='background'>
                                            <Image
                                                className='carousel-image'
                                                src={require('../../images/10.jpg')}
                                            />
                                        </div>
                                        <div className='background'>
                                            <Image
                                                className='carousel-image'
                                                src={require('../../images/3.jpg')}
                                            />
                                        </div>
                                    </Carousel>
                                </Card>
                            </div>
                        </Col>
                        <Col className="gutter-row" md={24}>
                            <div className="gutter-box">
                                <Card bordered={false}>
                                    <div style={{ width: "125px", fontSize: "18px", margin: "0 auto", color: "#25262C" }}>商户合作公告</div>
                                    <Row gutter={16}>
                                        {
                                            this.storeImages.map((item: any) => {
                                                return (
                                                    <Col className="gutter-row" md={4} key={item.id}>
                                                        <div className="gutter-box">
                                                            <Card bordered={false}>
                                                                <Image
                                                                    className='my-album-image'
                                                                    src={item.url}
                                                                    preview={false}
                                                                    onClick={() => this.checkImage(item)}
                                                                />
                                                            </Card>
                                                        </div>
                                                    </Col>
                                                )
                                            })
                                        }

                                    </Row>
                                </Card>
                            </div>
                        </Col>
                    </Row>
                </Spin>

                <Modal title={null} visible={this.state.loading} footer={null} style={{ textAlign: "center" }} maskClosable={false} onCancel={() => this.setState({ loading: false })}>
                    <Row gutter={16}>
                        <Col className="gutter-row" md={12}>
                            <div className="gutter-box">
                                <Card bordered={false} style={{ backgroundColor: "#25262C" }}>
                                    <Image
                                        className='my-album-image'
                                        preview={false}
                                        src={this.state.imageData?.url}
                                    />
                                </Card>
                            </div>
                        </Col>
                        <Col className="gutter-row" md={12}>
                            <div className="gutter-box">
                                <Card bordered={false} style={{ backgroundColor: "#25262C" }}>
                                    <div style={{ color: "#C1C2C5", margin: "15px", fontSize: "16px" }}>作品描述</div>
                                    <div style={{ color: "#C1C2C5", textAlign: "left", marginBottom: "60px" }}>{this.state.imageData?.des}</div>
                                </Card>
                                <div className="gutter-box">

                                    <Button type="primary" onClick={this.toDetail}>
                                        开始联系
                                    </Button>

                                </div>
                            </div>
                        </Col>
                    </Row>
                </Modal>
                <style>{`
                    .button-demo .ant-btn {
                        margin-right: 8px;
                        margin-bottom: 12px;
                    }
                    .gutter-box {
                        text-align: center;
                        
                    }
                    .background {
                        background: #9f63d2;
                    }
                    .ant-image-img {
                        height:380px;
                        width: 100%;
                    }
                    .ant-modal-body {
                        background-color: #25262C;
                    }
                    .ant-modal-close-x {
                        color: #C1C2C5;
                    }
                    .slick-track{
                        height:378px;
                    }
                `}</style>
            </div>
        );
    }
}

export default Buttons;
