/**
 * Created by hao.cheng on 2017/4/23.
 */
import React from 'react';
import { Row, Col, Card, Spin, Image, Input, Button } from 'antd';
import { HeartTwoTone, MessageOutlined } from '@ant-design/icons';
import BreadcrumbCustom from '../widget/BreadcrumbCustom';
import { RadioChangeEvent } from 'antd/lib/radio';
import { ButtonSize } from 'antd/lib/button';
import { DownOutlined, LeftOutlined, RightOutlined } from '@ant-design/icons';
const { TextArea } = Input;

type ButtonsState = {
    size: ButtonSize;
    loading: boolean;
    iconLoading: boolean;
    drawerOpen: boolean;
    inputValue: string;
    showText: boolean;
    spinLoading: boolean
};
const contentStyle: React.CSSProperties = {
    height: '160px',
    color: '#fff',
    lineHeight: '160px',
    textAlign: 'center',
    background: '#364d79',
};
class Buttons extends React.Component<any, ButtonsState> {
    constructor(props: any) {
        super(props);
        this.state = {
            size: 'middle',
            loading: false,
            iconLoading: false,
            drawerOpen: false,
            inputValue: "",
            showText: false,
            spinLoading: false,
        };
    }

    listResult = [
        {
            "name": {
                "last": "Fowler"
            },
            "picture": {
                "large": require('../../images/picture1.jpg'),
            },
            "description": "Ant Design, a design language for background applications, is refined by Ant UED Team"
        },
        {
            "name": {
                "last": "Fowler"
            },
            "picture": {
                "large": require('../../images/picture1.jpg'),
            },
            "description": "Ant Design, a design language for background applications, is refined by Ant UED Team"
        },
        {
            "name": {
                "last": "Fowler"
            },
            "picture": {
                "large": require('../../images/picture1.jpg'),
            },
            "description": "Ant Design, a design language for background applications, is refined by Ant UED Team"
        },
        {
            "name": {
                "last": "Fowler"
            },
            "picture": {
                "large": require('../../images/picture1.jpg'),
            },
            "description": "Ant Design, a design language for background applications, is refined by Ant UED Team"
        },
        {
            "name": {
                "last": "Fowler"
            },
            "picture": {
                "large": require('../../images/picture1.jpg'),
            },
            "description": "Ant Design, a design language for background applications, is refined by Ant UED Team"
        },
        {
            "name": {
                "last": "Fowler"
            },
            "picture": {
                "large": require('../../images/picture1.jpg'),
            },
            "description": "Ant Design, a design language for background applications, is refined by Ant UED Team"
        },
        {
            "name": {
                "last": "Fowler"
            },
            "picture": {
                "large": require('../../images/picture1.jpg'),
            },
            "description": "Ant Design, a design language for background applications, is refined by Ant UED Team"
        },

        {
            "name": {
                "last": "Fowler"
            },
            "picture": {
                "large": require('../../images/picture1.jpg'),
            },
            "description": "Ant Design, a design language for background applications, is refined by Ant UED Team"
        },

    ]
    container = document.querySelector(".app_layout");
    componentDidMount() {
        if (this.container) {
            this.container.scrollTo(0, 0);
        }
        this.setState({ spinLoading: true });
        setTimeout(() => {
            this.setState({ spinLoading: false });
        }, 1000);
    }
    imageData = JSON.parse(localStorage.getItem("imageData") || "{}")
    storeImage = JSON.parse(localStorage.getItem("storeImage") || "{}")
    handleSizeChange = (e: RadioChangeEvent) => {
        this.setState({ size: e.target.value });
    };
    handleMenuClick = (e: any) => {
        console.log('click', e);
    };
    enterLoading = () => {
        this.setState({ loading: true });
    };
    enterIconLoading = () => {
        this.setState({ iconLoading: true });
    };
    drawerOnClose = () => {
        this.setState({
            drawerOpen: false,
        });
    };
    openDrawer = () => {
        this.setState({
            drawerOpen: true,
        });
    };
    toHeZuo = () => {
        // if(this.state.showText === false){
        //     this.setState({
        //         showText: true,
        //     });
        // }else{
        //     window.location.hash = '/app/ui/HeZuoSuccess'
        // }
        // window.location.hash = '/app/ui/HeZuoSuccess'
        window.location.hash = '/app/ui/WaitPage'
    }
    render() {
        return (
            <div className="gutter-example button-demo">
                <Spin spinning={this.state.spinLoading}>
                    <Row gutter={16} style={{ textAlign: "center" }}>
                        <Col className="gutter-row" md={24}>
                            <div className="gutter-box">
                                <Card bordered={false}>
                                    <Row gutter={16}>
                                        <Col className="gutter-row" md={12}>
                                            <div className="gutter-box">
                                                <Card bordered={false}>
                                                    <div style={{ color: "#25262C", margin: "15px", fontSize: "16px" }}>合作标题</div>
                                                    <div style={{ color: "#25262C", marginBottom: "15px" }}>{this.storeImage?.des}</div>
                                                </Card>
                                                <Card bordered={false} style={{ height: "500px" }}>
                                                    <Image
                                                        className='my-album-image'
                                                        src={this.storeImage.url}
                                                        style={{ height: "500px" }}
                                                        preview={false}
                                                    />
                                                </Card>
                                            </div>
                                        </Col>
                                        <Col className="gutter-row" md={12}>
                                            <div className="gutter-box">
                                                <Card bordered={false}>
                                                    <div style={{ color: "#25262C", margin: "15px", fontSize: "16px" }}>我的作品</div>
                                                    <div style={{ color: "#25262C", marginBottom: "15px" }}>{this.imageData?.des}</div>
                                                </Card>
                                                <Card bordered={false}>
                                                    <Image
                                                        className='my-album-image'
                                                        src={this.imageData.url}
                                                        style={{ height: "200px" }}
                                                        preview={false}
                                                    />
                                                </Card>

                                            </div>
                                        </Col>
                                    </Row>
                                    <Row gutter={16}>
                                        <Col className="gutter-row" md={24}>
                                            <div className="gutter-box">
                                                <Card bordered={false}>
                                                    <div>合作信息留言</div>
                                                    <TextArea
                                                        value={this.state.inputValue}
                                                        onChange={e => this.setState({ inputValue: e.target.value })}
                                                        placeholder="请留言"
                                                        autoSize={{ minRows: 3, maxRows: 5 }}
                                                        style={{ width: "500px" }}
                                                    />

                                                </Card>

                                            </div>
                                        </Col>
                                    </Row>
                                    <div className="gutter-box">
                                        <Card bordered={false}>
                                            <Button type="primary" onClick={this.toHeZuo}>
                                                确认合作
                                            </Button>
                                        </Card>
                                    </div>
                                </Card>
                            </div>
                        </Col>
                    </Row>
                </Spin>

                <style>{`
                    .button-demo .ant-btn {
                        margin-right: 8px;
                        margin-bottom: 12px;
                    }
                    .ant-card-body{
                        padding: 0;
                    }
                    .ant-image-img{
                        height: 500px;
                    }
                `}</style>
            </div>
        );
    }
}

export default Buttons;
