/**
 * Created by hao.cheng on 2017/4/23.
 */
import React from 'react';
import { Row, Col, Card, Input, Slider, Tabs, Button, Spin, Image, Progress, Modal } from 'antd';
import { HeartTwoTone, PlusOutlined } from '@ant-design/icons';
import NProgress from 'nprogress';
import 'nprogress/nprogress.css';
const { TextArea } = Input;
const TabPane = Tabs.TabPane;
const sizeList = [
    {
        id: 1,
        size: <div style={{ backgroundColor: "#b6f1ed", width: "36px", height: "64px", padding: "20px 5px", margin: "0 12px" }}>9:16</div>,
        choosed: false
    },
    {
        id: 2,
        size: <div style={{ backgroundColor: "#b6f1ed", width: "64px", height: "36px", padding: "7px 18px", margin: "12px 0" }}>16:9</div>,
        choosed: false
    },
    {
        id: 3,
        size: <div style={{ backgroundColor: "#b6f1ed", width: "42px", height: "63px", padding: "20px 5px", margin: "0 12px" }}>2:3</div>,
        choosed: false
    },
    {
        id: 4,
        size: <div style={{ backgroundColor: "#b6f1ed", width: "63px", height: "42px", padding: "10px 5px", margin: "10px 0" }}>3:2</div>,
        choosed: false
    },
    {
        id: 5,
        size: <div style={{ backgroundColor: "#b6f1ed", width: "64px", height: "64px", padding: "20px 5px" }}>1:1</div>,
        choosed: false
    },
    {
        id: 6,
        size: <div style={{ backgroundColor: "#b6f1ed", width: "48px", height: "64px", padding: "20px 5px", margin: "0 9px" }}>3:4</div>,
        choosed: false
    },
    {
        id: 7,
        size: <div style={{ backgroundColor: "#b6f1ed", width: "64px", height: "48px", padding: "13px 5px" }}>4:3</div>,
        choosed: false
    },

]
const a = [
    {
        id: 1,
        size: <div>
            <Image
                className='checkImage'
                preview={false}
                src={require('../../images/m8.jpeg')}
            />
            <div style={{ fontSize: "12px" }}>CG综合</div>
        </div>,
        choosed: false
    },
    {
        id: 2,
        size: <div>
            <Image
                className='checkImage'
                preview={false}
                src={require('../../images/m25.jpeg')}
            />
            <div style={{ fontSize: "12px" }}>胶片写真</div>
        </div>,
        choosed: false
    },
    {
        id: 3,
        size: <div>
            <Image
                className='checkImage'
                preview={false}
                src={require('../../images/m12.jpeg')}
            />
            <div style={{ fontSize: "12px" }}>魔法</div>
        </div>,
        choosed: false
    },
    {
        id: 4,
        size: <div>
            <Image
                className='checkImage'
                preview={false}
                src={require('../../images/m26.jpeg')}
            />
            <div style={{ fontSize: "12px" }}>增强二次元</div>
        </div>,
        choosed: false
    },
    {
        id: 5,
        size: <div>
            <Image
                className='checkImage'
                preview={false}
                src={require('../../images/m27.jpeg')}
            />
            <div style={{ fontSize: "12px" }}>水墨淡雅</div>
        </div>,
        choosed: false
    },
    {
        id: 6,
        size: <div>
            <Image
                className='checkImage'
                preview={false}
                src={require('../../images/m22.jpeg')}
            />
            <div style={{ fontSize: "12px" }}>动漫</div>
        </div>,
        choosed: false
    },
]
const b = [
    {
        id: 1,
        size: <div>
            <Image
                className='checkImage'
                preview={false}
                src={require('../../images/t2.jpeg')}
            />
            <div style={{ fontSize: "12px" }}>动漫线稿 V1.0</div>
        </div>,
        choosed: false
    },
    {
        id: 2,
        size: <div>
            <Image
                className='checkImage'
                preview={false}
                src={require('../../images/t12.jpeg')}
            />
            <div style={{ fontSize: "12px" }}>汉服 V1.0</div>
        </div>,
        choosed: false
    },
    {
        id: 3,
        size: <div>
            <Image
                className='checkImage'
                preview={false}
                src={require('../../images/t9.jpeg')}
            />
            <div style={{ fontSize: "12px" }}>国风水墨 V1.0</div>
        </div>,
        choosed: false
    },
    {
        id: 4,
        size: <div>
            <Image
                className='checkImage'
                preview={false}
                src={require('../../images/s11.jpeg')}
            />
            <div style={{ fontSize: "12px" }}>亚洲女性 V1.0</div>
        </div>,
        choosed: false
    },
]
const c = [
    {
        id: 1,
        size: <div>
            <Image
                className='checkImage'
                preview={false}
                src={require('../../images/t1.jpeg')}
            />
            <div style={{ fontSize: "12px" }}>标准</div>
        </div>,
        choosed: false
    },
    {
        id: 2,
        size: <div>
            <Image
                className='checkImage'
                preview={false}
                src={require('../../images/t13.jpeg')}
            />
            <div style={{ fontSize: "12px" }}>3D</div>
        </div>,
        choosed: false
    },
    {
        id: 3,
        size: <div>
            <Image
                className='checkImage'
                preview={false}
                src={require('../../images/t3.jpeg')}
            />
            <div style={{ fontSize: "12px" }}>亚洲风尚</div>
        </div>,
        choosed: false
    },
    {
        id: 4,
        size: <div>
            <Image
                className='checkImage'
                preview={false}
                src={require('../../images/t4.jpeg')}
            />
            <div style={{ fontSize: "12px" }}>光影</div>
        </div>,
        choosed: false
    },
    {
        id: 5,
        size: <div>
            <Image
                className='checkImage'
                preview={false}
                src={require('../../images/t5.jpeg')}
            />
            <div style={{ fontSize: "12px" }}>吉卜力</div>
        </div>,
        choosed: false
    },
    {
        id: 6,
        size: <div>
            <Image
                className='checkImage'
                preview={false}
                src={require('../../images/t6.jpeg')}
            />
            <div style={{ fontSize: "12px" }}>连环画</div>
        </div>,
        choosed: false
    },
    {
        id: 7,
        size: <div>
            <Image
                className='checkImage'
                preview={false}
                src={require('../../images/t7.jpeg')}
            />
            <div style={{ fontSize: "12px" }}>暗色</div>
        </div>,
        choosed: false
    },
    {
        id: 8,
        size: <div>
            <Image
                className='checkImage'
                preview={false}
                src={require('../../images/t8.jpeg')}
            />
            <div style={{ fontSize: "12px" }}>水墨</div>
        </div>,
        choosed: false
    },
    {
        id: 9,
        size: <div>
            <Image
                className='checkImage'
                preview={false}
                src={require('../../images/t10.jpeg')}
            />
            <div style={{ fontSize: "12px" }}>焦茶</div>
        </div>,
        choosed: false
    },
    {
        id: 10,
        size: <div>
            <Image
                className='checkImage'
                preview={false}
                src={require('../../images/t11.jpeg')}
            />
            <div style={{ fontSize: "12px" }}>玩偶</div>
        </div>,
        choosed: false
    },
    {
        id: 11,
        size: <div>
            <Image
                className='checkImage'
                preview={false}
                src={require('../../images/m15.jpeg')}
            />
            <div style={{ fontSize: "12px" }}>线稿</div>
        </div>,
        choosed: false
    },
    {
        id: 12,
        size: <div>
            <Image
                className='checkImage'
                preview={false}
                src={require('../../images/m16.jpeg')}
            />
            <div style={{ fontSize: "12px" }}>绘本</div>
        </div>,
        choosed: false
    },
]
const d = [
    {
        id: 1,
        size: <div>
            <Image
                className='checkImage'
                preview={false}
                src={require('../../images/t14.jpeg')}
            />
            <div style={{ fontSize: "12px" }}>标准</div>
        </div>,
        choosed: false
    },
    {
        id: 2,
        size: <div>
            <Image
                className='checkImage'
                preview={false}
                src={require('../../images/t15.jpeg')}
            />
            <div style={{ fontSize: "12px" }}>典雅法</div>
        </div>,
        choosed: false
    },
    {
        id: 3,
        size: <div>
            <Image
                className='checkImage'
                preview={false}
                src={require('../../images/t16.jpeg')}
            />
            <div style={{ fontSize: "12px" }}>夜姬法</div>
        </div>,
        choosed: false
    },
    {
        id: 4,
        size: <div>
            <Image
                className='checkImage'
                preview={false}
                src={require('../../images/t17.jpeg')}
            />
            <div style={{ fontSize: "12px" }}>工笔法</div>
        </div>,
        choosed: false
    },
    {
        id: 5,
        size: <div>
            <Image
                className='checkImage'
                preview={false}
                src={require('../../images/t18.jpeg')}
            />
            <div style={{ fontSize: "12px" }}>幻想法</div>
        </div>,
        choosed: false
    },
    {
        id: 6,
        size: <div>
            <Image
                className='checkImage'
                preview={false}
                src={require('../../images/t19.jpeg')}
            />
            <div style={{ fontSize: "12px" }}>深海法</div>
        </div>,
        choosed: false
    },
    {
        id: 7,
        size: <div>
            <Image
                className='checkImage'
                preview={false}
                src={require('../../images/t20.jpeg')}
            />
            <div style={{ fontSize: "12px" }}>真实法</div>
        </div>,
        choosed: false
    },
    {
        id: 8,
        size: <div>
            <Image
                className='checkImage'
                preview={false}
                src={require('../../images/t21.jpeg')}
            />
            <div style={{ fontSize: "12px" }}>行云法</div>
        </div>,
        choosed: false
    },
]
class Spins extends React.Component {
    myMyImages: any = JSON.parse(localStorage.getItem("myMyImages") || "[]")
    state = {
        loading: false,
        professionalInput1: "",
        professionalInput2: "",
        countDownTime: 0,
        percent: 0,
        loadingText: "AI图片生成中……",
        actionSizeList: sizeList,
        actionSizeList2: sizeList,
        showModal: false,
        myMyImages: this.myMyImages,
        copyImage: {},
        againImage: {
            id: 0,
            url: "",
            des: "",
            publish: false,
            message: 0,
            heart: 0
        },
        a: a,
        b: b,
        c: c,
        d: d,
        spinLoading: false
    };
    container = document.querySelector(".app_layout");
    componentDidMount() {
        if (this.container) {
            this.container.scrollTo(0, 0);
        }
        this.setState({ spinLoading: true });
        setTimeout(() => {
            this.setState({ spinLoading: false });
        }, 1000);
    }

    startSubmin = () => {
        this.setState({ loading: true });
        this.countStart()
    };
    countStart = () => {
        let countDownTime = this.state.countDownTime
        let timer = window.setInterval(() => {
            if (countDownTime > 99) {
                window.clearInterval(timer);
            } else {
                this.setState({ countDownTime: (countDownTime++) }, () => {
                    // if (countDownTime == 51) {
                    //     this.setState({ loadingText: "正在生成签名……" })
                    // }
                    // if (countDownTime == 65) {
                    //     this.setState({ loadingText: "正在上链……" })
                    // }
                    if (countDownTime == 100) {
                        this.setState({ loadingText: "AI图片生成完毕" })
                        let newImage: any = {
                            id: 100,
                            url: require('../../images/m19.jpeg'),
                            des: this.state.professionalInput1?this.state.professionalInput1:"none",
                            publish: false,
                            message: 0,
                            heart: 0,
                            chainData: {
                                hash: "0x1914f71922b3ae8552aed7761d7aa3c8990b3f2aed7761db13521b9f761d7a63",
                                chain: "1176309"
                            },
                            qianbao: "0x88fc50577749bd27b242b578b8a0b6a738eb8683"
                        }
                        if(this.state.againImage.url){
                            newImage = {
                                id: 101,
                                url: require('../../images/g2.jpeg'),
                                des: this.state.professionalInput2?this.state.professionalInput2:"none",
                                publish: false,
                                message: 0,
                                heart: 0,
                                chainData: {
                                    hash: "0x328de3dc02a6cc4f3920f7d93a4da4c4c90f393a4da0b1352e8dba4da4c4c899",
                                    chain: "19356937"
                                },
                                qianbao: "0x88fc50577749bd27b242b578b8a0b6a738eb8683"
                            }
                        }
                        let copyimage = this.myMyImages
                        copyimage.unshift(newImage)
                        localStorage.setItem("myMyImages", JSON.stringify(copyimage));
                        localStorage.setItem("imageData", JSON.stringify(newImage))
                        setTimeout(() => {

                            window.location.hash = '/app/ui/ImageDetail?notPublish'
                        }, 1500);
                        // window.setInterval(() => {
                        //     window.location.hash = '/app/ui/ImageDetail'
                        // },1500)

                    }
                });
            }
        }, 30)
    }
    nprogressStart = () => {
        NProgress.start();
    };
    nprogressDone = () => {
        NProgress.done();
    };
    onChange = (value: number | [number, number]) => {
        console.log('onChange: ', value);
    };

    onAfterChange = (value: number | [number, number]) => {
        console.log('onAfterChange: ', value);
    };
    onChange1 = (value: number | [number, number]) => {
        console.log('onChange: ', value);
    };

    onAfterChange1 = (value: number | [number, number]) => {
        console.log('onAfterChange: ', value);
    };
    tabsOnChange = (key: string) => {

    }
    //对象合并深拷贝
    getObjType = (obj: any) => {
        if (typeof obj == 'object') {
            if (obj instanceof Array) {
                return 'array'
            } else {
                return 'object'
            }
        } else {
            return 'value'
        }
    }
    deepExtend = (obj1: any, obj2: any) => {
        let obj1Type = this.getObjType(obj1)
        let obj2Type = this.getObjType(obj2)
        //如果传入的两个参数类型不一致，则先设置数据类型
        if (obj1Type != obj2Type) {
            if (obj2Type == 'object') {
                obj1 = obj2 ? {} : null
            } else if (obj2Type == 'array') {
                obj1 = []
            } else {
                obj1 = obj2
                return obj1
            }
        }
        if (obj2Type == 'object') {
            for (let prop in obj2) {
                if (!obj1[prop]) {
                    obj1[prop] = obj2[prop] ? {} : null
                }
                obj1[prop] = this.deepExtend(obj1[prop], obj2[prop])
            }
        } else if (obj2Type == 'array') {
            obj2 = obj2.slice()
            var newObj: any = obj2 instanceof Array ? [] : {}
            for (var item in obj2) {
                //只复制元素自身的属性，不复制原型链上的
                if (obj2.hasOwnProperty(item)) {
                    newObj[item] = typeof obj2[item] == 'object' ? this.deepExtend([], obj2[item]) : obj2[item] //判断属性值类型
                }
            }
            obj1 = obj1.concat(newObj)
        } else {
            obj1 = obj2
        }
        return obj1
    }
    increase = () => {
        let newPercent = this.state.percent + 10;
        if (newPercent > 100) {
            newPercent = 100;
        }
        this.setState({ percent: newPercent })
    };
    chooseSize = (item: any, type: string) => {
        let copySizeList = this.deepExtend([], this.state.actionSizeList)
        copySizeList.forEach((data: any) => {
            if (data.id === item.id) {
                data.choosed = true
            } else {
                data.choosed = false
            }
        })
        if (type === "1") {
            this.setState({ actionSizeList: copySizeList });
        } else {
            this.setState({ actionSizeList2: copySizeList });
        }

    }
    chooseModal = (item: any, type: string) => {
        let copy: any = []
        if (type === "a") {
            copy = this.deepExtend([], this.state.a)

        }
        if (type === "b") {
            copy = this.deepExtend([], this.state.b)

        }
        if (type === "c") {
            copy = this.deepExtend([], this.state.c)

        }
        if (type === "d") {
            copy = this.deepExtend([], this.state.d)

        }
        copy.forEach((data: any) => {
            if (data.id === item.id) {
                data.choosed = true
            } else {
                data.choosed = false
            }
        })
        this.setState({ [type]: copy });
    }
    imageImage = (item: any) => {
        let copySizeList = this.deepExtend([], this.state.myMyImages)
        copySizeList.forEach((data: any) => {
            if (data.id === item.id) {
                data.choosed = true
            } else {
                data.choosed = false
            }
        })
        this.setState({ myMyImages: copySizeList });
    }
    updateImage = () => {
        this.setState({ showModal: true });
    }

    againChooseImage = () => {
        this.setState({ againImage: this.state.copyImage }, () => {
            this.setState({ showModal: false })
        });
    }
    textAreaOnChange = (e:any) => {
        this.setState({ professionalInput1: e.target.value })
        let copy: any = []
        copy = this.deepExtend([], this.state.a)
        copy.forEach((data: any) => {
            if (data.id === 4) {
                data.choosed = true
            }
        })
        this.setState({ a: copy });
    }

    antIcon = <Progress type="circle" percent={Number(this.state.countDownTime)} strokeColor={{ '0%': '#108ee9', '100%': '#87d068' }} />
    render() {

        return (
            <div className="gutter-example button-demo">

                <Spin spinning={this.state.spinLoading}>
                    <Row gutter={16}>
                        <Col className="gutter-row" md={12}>
                            <div className="gutter-box">
                                <Card bordered={false}>
                                    <div style={{ width: "125px", fontSize: "18px", margin: "0 auto", color: "#25262C" }}>专业炼丹</div>
                                    {/* <Progress percent={this.state.percent} /> */}
                                    {/* <Progress type="circle" percent={this.state.percent} strokeColor={{ '0%': '#108ee9', '100%': '#87d068' }} />
                                    <Button type="primary" onClick={this.increase} /> */}
                                    <TextArea
                                        value={this.state.professionalInput1}
                                        onChange={(e) => {this.textAreaOnChange(e)}}
                                        placeholder="输入想要的图片描述"
                                        autoSize={{ minRows: 3, maxRows: 5 }}
                                    />
                                    <div style={{ marginTop: "20px" }}>比例</div>
                                    <Row gutter={16}>
                                        {
                                            this.state.actionSizeList.map(item => {
                                                return (
                                                    <Col className="gutter-row" md={4} key={item.id}>
                                                        <div className="gutter-box">
                                                            <Card bordered={false} className={`${item.choosed ? "choose" : null}`} style={{ cursor: "pointer" }} onClick={() => this.chooseSize(item, "1")}>
                                                                {item.size}
                                                            </Card>
                                                        </div>
                                                    </Col>
                                                )
                                            })
                                        }

                                    </Row>
                                    <div>模型选择</div>
                                    <Row gutter={16}>
                                        {
                                            this.state.a.map(item => {
                                                return (
                                                    <Col className="gutter-row" md={4} key={item.id}>
                                                        <div className="gutter-box">
                                                            <Card bordered={false} className={`${item.choosed ? "choose" : null}`} style={{ cursor: "pointer" }} onClick={() => this.chooseModal(item, "a")}>
                                                                {item.size}
                                                            </Card>
                                                        </div>
                                                    </Col>
                                                )
                                            })
                                        }
                                    </Row>
                                    <div>叠加模型</div>
                                    <Row gutter={16}>
                                        {
                                            this.state.b.map(item => {
                                                return (
                                                    <Col className="gutter-row" md={4} key={item.id}>
                                                        <div className="gutter-box">
                                                            <Card bordered={false} className={`${item.choosed ? "choose" : null}`} style={{ cursor: "pointer" }} onClick={() => this.chooseModal(item, "b")}>
                                                                {item.size}
                                                            </Card>
                                                        </div>
                                                    </Col>
                                                )
                                            })
                                        }

                                    </Row>
                                    <div>文字束缚力度</div>
                                    <Slider defaultValue={30} onChange={this.onChange} onAfterChange={this.onAfterChange} />
                                    <div>重绘力度</div>
                                    <Slider defaultValue={40} onChange={this.onChange1} onAfterChange={this.onAfterChange1} />
                                    <Button type="primary" shape="round" size={"large"} onClick={this.startSubmin}>
                                        开始绘画
                                    </Button>
                                </Card>
                            </div>
                        </Col>
                        <Col className="gutter-row" md={12}>
                            <div className="gutter-box">
                                <Card>
                                    <div style={{ width: "125px", fontSize: "18px", margin: "0 auto", color: "#25262C" }}>快捷炼丹</div>
                                    <Tabs onChange={this.tabsOnChange} type="card">
                                        <TabPane tab="文炼" key="1">
                                            <TextArea
                                                value={this.state.professionalInput2}
                                                onChange={(e) => this.setState({ professionalInput2: e.target.value })}
                                                placeholder="输入想要的图片描述"
                                                autoSize={{ minRows: 3, maxRows: 5 }}
                                            />
                                        </TabPane>
                                        <TabPane tab="图炼" key="2">
                                            <div onClick={this.updateImage} style={{ width: "300px", height: "150px", backgroundColor: "#eee", margin: "auto", cursor: "pointer" }}>

                                                {
                                                    this.state.againImage.url ?
                                                        <Image
                                                            className='showImage'
                                                            src={this.state.againImage["url"] || ""}
                                                            preview={false}
                                                        /> : <PlusOutlined style={{fontSize: "33px", lineHeight: "150px"}} />
                                                }

                                            </div>
                                        </TabPane>
                                    </Tabs>
                                    <div style={{ marginTop: "20px" }}>比例</div>
                                    <Row gutter={16}>
                                        {
                                            this.state.actionSizeList2.map(item => {
                                                return (
                                                    <Col className="gutter-row" md={4} key={item.id}>
                                                        <div className="gutter-box">
                                                            <Card bordered={false} className={`${item.choosed ? "choose" : null}`} style={{ cursor: "pointer" }} onClick={() => this.chooseSize(item, "2")}>
                                                                {item.size}
                                                            </Card>
                                                        </div>
                                                    </Col>
                                                )
                                            })
                                        }

                                    </Row>
                                    <div>选择风格</div>
                                    <Row gutter={16}>
                                        {
                                            this.state.c.map(item => {
                                                return (
                                                    <Col className="gutter-row" md={4} key={item.id}>
                                                        <div className="gutter-box">
                                                            <Card bordered={false} className={`${item.choosed ? "choose" : null}`} style={{ cursor: "pointer" }} onClick={() => this.chooseModal(item, "c")}>
                                                                {item.size}
                                                            </Card>
                                                        </div>
                                                    </Col>
                                                )
                                            })
                                        }


                                    </Row>
                                    <div>选择魔法</div>
                                    <Row gutter={16}>
                                        {
                                            this.state.d.map(item => {
                                                return (
                                                    <Col className="gutter-row" md={4} key={item.id}>
                                                        <div className="gutter-box">
                                                            <Card bordered={false} className={`${item.choosed ? "choose" : null}`} style={{ cursor: "pointer" }} onClick={() => this.chooseModal(item, "d")}>
                                                                {item.size}
                                                            </Card>
                                                        </div>
                                                    </Col>
                                                )
                                            })
                                        }

                                    </Row>
                                    <Button type="primary" shape="round" size={"large"} onClick={this.startSubmin}>
                                        开始绘画
                                    </Button>
                                </Card>
                            </div>
                        </Col>
                    </Row>
                </Spin>
                <Modal className='chooseChoose' title={null} visible={this.state.showModal} footer={null} style={{ textAlign: "center" }} onCancel={() => this.setState({ showModal: false })} maskClosable={false}>
                    <Row gutter={16}>
                        {
                            this.state.myMyImages.map((item: any) => {
                                return (
                                    <Col className="gutter-row" md={12} key={item.id}>
                                        <div className="gutter-box">
                                            <Card bordered={false} style={{ backgroundColor: "#25262C", cursor: "pointer" }} className={`${item.choosed ? "choose" : null}`} onClick={() => this.imageImage(item)}>
                                                <Image
                                                    className='my-album-image'
                                                    src={item.url}
                                                    preview={false}
                                                    onClick={() => {this.setState({copyImage: item})}}
                                                />
                                            </Card>
                                        </div>
                                    </Col>
                                )
                            })
                        }

                    </Row>
                    <Button style={{ marginTop: "20px" }} type="primary" onClick={this.againChooseImage}>
                        确认选择
                    </Button>
                </Modal>

                <Modal title={null} visible={this.state.loading} footer={null} style={{ textAlign: "center" }} closable={false} maskClosable={false}>
                    <Progress type="circle" percent={this.state.countDownTime} strokeColor={{ '0%': '#108ee9', '100%': '#87d068' }} />
                    <div style={{ color: "#C1C2C5", margin: "20px 0" }}>{this.state.loadingText}</div>
                </Modal>
                <style>{`
                    .ant-modal-body {
                        background-color: #25262C;
                    }
                    .ant-modal-close-x {
                        color: #C1C2C5;
                    }
                    .chooseChoose .ant-modal-body{
                        height:500px;
                        overflow-y: auto
                    }
                    .showImage .ant-image-img{
                        height: 150px;
                    }
                    .chooseChoose .ant-modal-body .ant-row{
                        height:400px;
                        overflow-y: auto
                    }
                    .ant-progress-circle .ant-progress-text {
                        color: #C1C2C5;
                    }
                    .ant-spin-nested-loading > div > .ant-spin .ant-spin-dot {
                        left: 46%;
                    }
                    .ant-spin-nested-loading > div > .ant-spin .ant-spin-text {
                        top: 77%;
                    }
                    .ant-card-body {
                        text-align: center;
                    }
                    .choose {
                        border: 1px solid #6de26b;
                    }
                    .checkImage .ant-image-img {
                        width: 60px;
                        height: 60px;
                        border-radius: 50%;
                    }
                `}</style>
            </div>
        );
    }
}

export default Spins;
