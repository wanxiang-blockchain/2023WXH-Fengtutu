/**
 * Created by hao.cheng on 2017/4/15.
 */
import React from 'react';
import { Table, Row, Col, Card } from 'antd';
// import { TableRowSelection } from 'antd/lib/table';


// for (let i = 0; i < 46; i++) {
//     data.push({
//         key: i,
//         name: `Edward King ${i}`,
//         age: 32,
//         address: `London, Park Lane no. ${i}`,
//     });
// }

class SelectTable extends React.Component {
    state = {
        selectedRowKeys: [], // Check here to configure the default column
        spinLoading: false,
    };
    columns = [
        {
            title: '哈希',
            dataIndex: 'name',
            render: (text: any, record: any, index: number) => {
                return <span onClick={() => this.toDetail(index)} style={{ cursor: "pointer", color: "#1777FF" }}>{text}</span>
            },
        },
        {
            title: '方法',
            dataIndex: 'age',
        },
        {
            title: '发送方',
            dataIndex: 'to',
            render: (text: any, record: any, index: number) => {
                return <span onClick={() => this.toDetail(index)} style={{cursor: "pointer", color: "#1777FF"}}>{text}</span>
            },
        },
        {
            title: '接收方',
            dataIndex: 'get',
            render: (text: any, record: any, index: number) => {
                return <span onClick={() => this.toDetail(index)} style={{cursor: "pointer", color: "#1777FF"}}>{text}</span>
            },
        },
        {
            title: '数量',
            dataIndex: 'count',
        },
        {
            title: '手续费',
            dataIndex: 'money',
        },
    ];

    data: any[] = [
        {
            key: 1,
            name: "0x03578d77219c5469cd8efc0ba7a137fd……",
            age: "0x095ea7b3",
            to: "0xc94edc……e380",
            get: "0x4d6bba……9eab",
            count: `0.0000264`,
            money: "0.000302"
        },
        {
            key: 2,
            name: "0xbfe8f08ab5e23424acc09bf157ac68db……",
            age: "0x9c5469ce2",
            to: "0xa7a137……9cd8",
            get: "0xe52085……fc64",
            count: `0.0010064`,
            money: "0.000351"
        },
        {
            key: 3,
            name: "0x3ea9fe5208593bab5bfc645ae3beac9……",
            age: "0x424acc09b",
            to: "0xc94edc……e380",
            get: "0x4d6bba……9eab",
            count: `0.0012599`,
            money: "0.000758"
        },
        {
            key: 4,
            name: "0x6d29a8f2364eceb8df910021b48945b……",
            age: "0x8593bab5",
            to: "0x8375e4……75e4",
            get: "0x312c0e……12c0",
            count: `0.0000006`,
            money: "0.000004"
        },
        {
            key: 5,
            name: "0x5b1e8375e474a5312c0ed352c89b78e……",
            age: "0x6ceb8df9",
            to: "0x2902e6……b6d5",
            get: "0x2e60ff……7db0",
            count: `0.0035782`,
            money: "0.001701"
        },
        {
            key: 6,
            name: "0x7992902e60ffd0bb6d507db06db6b93……",
            age: "0xd0bb6d50",
            to: "0x56fca7……6fca",
            get: "0xe266c0……66c0",
            count: `0.0000064`,
            money: "0.000004"
        },
        {
            key: 7,
            name: "0xb591656fca74cdce266c07487319115……",
            age: "0xb93e436c3",
            to: "0x697262……62f7",
            get: "0xf73ad3……d3d1",
            count: `0.0000132`,
            money: "0.000114"
        },
        {
            key: 8,
            name: "0x9da697262f7d2f73ad3d1bdbbb8c057……",
            age: "0x74cdce26",
            to: "0x1911e3……62f7",
            get: "0xad3d12……2f7d",
            count: `0.0012343`,
            money: "0.000683"
        },
    ];
    data1: any[] = [
        
        {
            key: 1,
            name: "0x6d29a8f2364eceb8df910021b48945b……",
            age: "0x8593bab5",
            to: "0x8375e4……75e4",
            get: "0x312c0e……12c0",
            count: `0.0000006`,
            money: "0.000004"
        },
        {
            key: 2,
            name: "0x7992902e60ffd0bb6d507db06db6b93……",
            age: "0xd0bb6d50",
            to: "0x56fca7……6fca",
            get: "0xe266c0……66c0",
            count: `0.0000064`,
            money: "0.000004"
        },
        {
            key: 3,
            name: "0xb591656fca74cdce266c07487319115……",
            age: "0xb93e436c3",
            to: "0x697262……62f7",
            get: "0xf73ad3……d3d1",
            count: `0.0000132`,
            money: "0.000114"
        },
    ];
    toDetail = (index: any) => {
        let newImage: any = {
            id: 100,
            url: require('../../images/g1.jpeg'),
            des: "可爱女生，短发，黑色头发，夏日风，穿黄色短袖，家里，花盆",
            publish: false,
            message: 0,
            heart: 0,
            chainData: {
                hash: "0x1914f71922b3ae8552aed7761d7aa3c8990b3f2aed7761db13521b9f761d7a63",
                chain: "1176309"
            },
            qianbao: "0xf8756eb399bbe17d3a8c20ca996d02006a81a0d2"
        }
        if (index === 0) {
            newImage = {
                id: 101,
                url: require('../../images/g2.jpeg'),
                des: "none",
                publish: false,
                message: 0,
                heart: 0,
                chainData: {
                    hash: "0x328de3dc02a6cc4f3920f7d93a4da4c4c90f393a4da0b1352e8dba4da4c4c899",
                    chain: "19356937"
                },
                qianbao: "0x88fc50577749bd27b242b578b8a0b6a738eb8683"
            }
        }
        if(window.location.hash.indexOf("outside") === -1){
            localStorage.setItem("imageData", JSON.stringify(newImage))
            window.location.hash = '/app/ui/ImageDetail'
        }else{
            if (index === 0) {
                newImage = {
                    id: 102,
                    url: require('../../images/m3.jpeg'),
                    des: "lllllllllllllllllllllllllllllll",
                    publish: true,
                    message: 8,
                    heart: 21
                }
            }
            if (index === 1) {
                newImage = {
                    id: 103,
                    url: require('../../images/m5.jpeg'),
                    des: "lllllllllllllllllllllllllllllll",
                    publish: true,
                    message: 16,
                    heart:6
                }
            }
            if (index === 2) {
                newImage = {
                    id: 106,
                    url: require('../../images/m6.jpeg'),
                    des: "lllllllllllllllllllllllllllllll",
                    publish: true,
                    message: 16,
                    heart:11
                }
            }
            localStorage.setItem("imageData", JSON.stringify(newImage))
            window.location.hash = '/app/ui/ImageDetail?outside'
        }
        
    }
    container = document.querySelector(".app_layout");
    componentDidMount() {
        if (this.container) {
            this.container.scrollTo(0, 0);
        }
        this.setState({ spinLoading: true });
        setTimeout(() => {
            this.setState({ spinLoading: false });
        }, 1000);
    }
    onSelectChange = (selectedRowKeys: string[] | number[]) => {
        console.log('selectedRowKeys changed: ', selectedRowKeys);
        this.setState({ selectedRowKeys });
    };
    render() {
        let newData:any = null
        if(!this.state.spinLoading){
            if(window.location.hash.indexOf("outside") === -1){
                newData = this.data
            }else{
                newData = this.data1
            }
        }
        
        return (
            <div className="gutter-example button-demo">
                <Row gutter={16}>
                    <Col className="gutter-row" md={24}>
                        <div className="gutter-box">
                            <Card bordered={false}>
                                <Table columns={this.columns} dataSource={newData} loading={this.state.spinLoading} />;
                            </Card>
                        </div>
                    </Col>
                </Row>

            </div>
        )

    }
}

export default SelectTable;
