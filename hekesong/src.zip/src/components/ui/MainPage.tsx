/**
 * Created by hao.cheng on 2017/4/23.
 */
import React from 'react';
import { Row, Col, Card, Spin, Image, Button, Drawer, Space } from 'antd';
import { HeartTwoTone, EyeInvisibleOutlined } from '@ant-design/icons';
import BreadcrumbCustom from '../widget/BreadcrumbCustom';
import { RadioChangeEvent } from 'antd/lib/radio';
import { ButtonSize } from 'antd/lib/button';
import { DownOutlined, LeftOutlined, RightOutlined } from '@ant-design/icons';
import Cooperate from './Cooperate';

type ButtonsState = {
    size: ButtonSize;
    loading: boolean;
    iconLoading: boolean;
    drawerOpen: boolean;
    spinLoading: boolean;
};
const contentStyle: React.CSSProperties = {
    height: '160px',
    color: '#fff',
    lineHeight: '160px',
    textAlign: 'center',
    background: '#364d79',
};
class Buttons extends React.Component<any, ButtonsState> {
    constructor(props: any) {
        super(props);
        this.state = {
            size: 'middle',
            loading: false,
            iconLoading: false,
            drawerOpen: false,
            spinLoading: false,
        };
    }
    container = document.querySelector(".app_layout");
    componentDidMount() {
        if (this.container) {
            this.container.scrollTo(0, 0);
        }
        this.setState({ spinLoading: true });
        setTimeout(() => {
            this.setState({ spinLoading: false });
        }, 1000);
    }

    myImage: any = JSON.parse(localStorage.getItem("myImages") || "[]")
    storeImages: any = JSON.parse(localStorage.getItem("storeImages") || "[]")
    handleSizeChange = (e: RadioChangeEvent) => {
        this.setState({ size: e.target.value });
    };
    handleMenuClick = (e: any) => {
        console.log('click', e);
    };
    enterLoading = () => {
        this.setState({ loading: true });
    };
    enterIconLoading = () => {
        this.setState({ iconLoading: true });
    };
    drawerOnClose = () => {
        this.setState({
            drawerOpen: false,
        });
    };
    openDrawer = () => {
        this.setState({
            drawerOpen: true,
        });
    };
    toDetail = (item: any) => {
        localStorage.setItem("imageData", JSON.stringify(item))
        window.location.hash = '/app/ui/ImageDetail?outside'
    }
    render() {
        let imageList: any = []
        if (window.location.hash.indexOf("ai") != -1) {
            imageList = this.myImage
        } else {
            imageList = this.storeImages
        }
        return (
            <div className="gutter-example button-demo">
                <Spin spinning={this.state.spinLoading}>
                    <Row gutter={16}>
                        <Col className="gutter-row" md={24}>
                            <div className="gutter-box">
                                <Card bordered={false}>
                                    <div style={{ width: "125px", fontSize: "18px", margin: "20px auto", color: "#25262C" }}>个人中心</div>
                                    <Row gutter={16}>
                                        <Col className="gutter-row" md={8} style={{ textAlign: "center" }}>
                                            <Image
                                                className='my-album-image'
                                                src={require('../../images/head.jpg')}
                                                preview={false}
                                            />
                                        </Col>
                                        <Col className="gutter-row" md={16}>
                                            <Row gutter={16}>
                                                <Col className="gutter-row" md={12}>
                                                    <div style={{ width: "125px", fontSize: "18px", color: "#25262C", margin: "10px 0" }}>昵称</div>
                                                    <div style={{ color: "#94969a" }}>疯兔兔</div>
                                                </Col>
                                                <Col className="gutter-row" md={12}>
                                                    <div style={{ width: "125px", fontSize: "18px", color: "#25262C", margin: "10px 0" }}>手机号</div>
                                                    <div style={{ color: "#94969a" }}>17317136199</div>
                                                </Col>
                                            </Row>
                                            <Row gutter={16}>
                                                <Col className="gutter-row" md={12} style={{ position: "relative" }}>
                                                    <div style={{ width: "125px", fontSize: "18px", color: "#25262C", margin: "10px 0" }}>私钥</div>
                                                    <div style={{ color: "#94969a" }}>f73a……d3d1bd</div>
                                                    <EyeInvisibleOutlined style={{ position: "absolute", left: "125px", bottom: "5px", color: "#1777FF", cursor: "pointer" }} />
                                                </Col>
                                                <Col className="gutter-row" md={12}>
                                                    <div style={{ width: "125px", fontSize: "18px", color: "#25262C", margin: "10px 0" }}>邮箱</div>
                                                    <div style={{ color: "#94969a" }}>jeffrey13876@163.com</div>
                                                </Col>
                                            </Row>
                                            <Row gutter={16}>
                                                <Col className="gutter-row" md={12}>
                                                    <div style={{ width: "125px", fontSize: "18px", color: "#25262C", margin: "10px 0" }}>公钥</div>
                                                    <div style={{ color: "#94969a" }}>MFkwEwYHKoZIzj0CAQYIKoEcz1UBgi0DQgAEex+BLKH39ipPe</div>
                                                    <div style={{ color: "#94969a" }}>5ROin3wniJm5/ze8M5f2DRBehXwQpu/xctFCiJkqokyREzmue</div>
                                                    <div style={{ color: "#94969a" }}>aAUGvWiQhhmCDp/Fy2MqnqIw==</div>
                                                </Col>
                                                <Col className="gutter-row" md={12}>
                                                    <div style={{ width: "125px", fontSize: "18px", color: "#25262C", margin: "10px 0" }}>实名认证信息</div>
                                                    <div style={{ color: "#94969a" }}>12028119……641X</div>
                                                    <EyeInvisibleOutlined style={{ position: "absolute", left: "140px", bottom: "48px", color: "#1777FF", cursor: "pointer" }} />
                                                </Col>
                                            </Row>
                                        </Col>
                                    </Row>
                                    <div style={{ width: "125px", fontSize: "18px", margin: "20px auto", color: "#25262C" }}>作品列表</div>
                                    <Cooperate type="mainPage" />
                                </Card>
                            </div>
                        </Col>
                    </Row>
                </Spin>

                <style>{`
                    .button-demo .ant-btn {
                        margin-right: 8px;
                        margin-bottom: 12px;
                    }
                    .ant-image-img {
                        height:380px;
                        width: 100%;
                        
                    }
                `}</style>
            </div>
        );
    }
}

export default Buttons;
