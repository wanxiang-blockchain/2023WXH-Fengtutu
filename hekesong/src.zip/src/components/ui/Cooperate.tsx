/**
 * Created by hao.cheng on 2017/4/23.
 */
import React from 'react';
import { Row, Col, Card, Spin, Image, Button, Modal, Progress } from 'antd';
import { HeartTwoTone, MessageOutlined } from '@ant-design/icons';
import BreadcrumbCustom from '../widget/BreadcrumbCustom';
import { RadioChangeEvent } from 'antd/lib/radio';
import { ButtonSize } from 'antd/lib/button';
import { DownOutlined, LeftOutlined, RightOutlined } from '@ant-design/icons';

type ButtonsState = {
    size: ButtonSize;
    loading: boolean;
    iconLoading: boolean;
    drawerOpen: boolean;
    value: number;
    imageData: any;
    startPublish: any;
    countDownTime: any;
    loadingText: any;
    spinLoading: boolean
};
const contentStyle: React.CSSProperties = {
    height: '160px',
    color: '#fff',
    lineHeight: '160px',
    textAlign: 'center',
    background: '#364d79',
};
class Buttons extends React.Component<any, ButtonsState> {
    constructor(props: any) {
        super(props);
        this.state = {
            size: 'middle',
            loading: false,
            iconLoading: false,
            drawerOpen: false,
            value: 1,
            imageData: {},
            startPublish: false,
            countDownTime: 0,
            loadingText: "正在生成签名……",
            spinLoading: false
        };
    }
    container = document.querySelector(".app_layout");
    componentDidMount() {
        if (this.container) {
            this.container.scrollTo(0, 0);
        }
        this.setState({ spinLoading: true });
        setTimeout(() => {
            this.setState({ spinLoading: false });
        }, 1000);
    }
    myMyImages: any = JSON.parse(localStorage.getItem("myMyImages2") || "[]")

    handleSizeChange = (e: RadioChangeEvent) => {
        this.setState({ size: e.target.value });
    };
    handleMenuClick = (e: any) => {
        console.log('click', e);
    };
    enterLoading = () => {
        this.setState({ loading: true });
    };
    enterIconLoading = () => {
        this.setState({ iconLoading: true });
    };
    drawerOnClose = () => {
        this.setState({
            drawerOpen: false,
        });
    };
    openDrawer = () => {
        this.setState({
            drawerOpen: true,
        });
    };
    toCooperate = () => {
        localStorage.setItem("imageData", JSON.stringify(this.state.imageData))
        window.location.hash = '/app/ui/MerchantImage'
    }
    radioOnChange = (e: any) => {
        this.setState({ value: e.target.value });
    }
    publishImage = (data: any) => {
        // if (data.publish) {
        //     window.location.hash = '/app/ui/ImageDetail'
        // } else {
        //     this.setState({ imageData: data });
        //     this.setState({ loading: true });
        // }
        localStorage.setItem("imageData", JSON.stringify(data))
        this.setState({ imageData: data });
        this.setState({ loading: true });

    }
    startPublish = () => {
        this.setState({ loading: false });

        this.setState({ startPublish: true });
        this.countStart()

    }
    countStart = () => {
        let countDownTime = this.state.countDownTime
        let timer = window.setInterval(() => {
            if (countDownTime > 99) {
                window.clearInterval(timer);
            } else {
                this.setState({ countDownTime: (countDownTime++) }, () => {
                    if (countDownTime == 51) {
                        this.setState({ loadingText: "正在上链……" })
                    }
                    if (countDownTime == 100) {
                        let copyimage = this.myMyImages
                        copyimage.forEach((element: any) => {
                            if (element.id === this.state.imageData.id) {
                                element.publish = true
                            }
                        });
                        this.setState({ loadingText: "上链成功" })
                        localStorage.setItem("myMyImages", JSON.stringify(copyimage));
                        setTimeout(() => {
                            this.setState({ startPublish: false });
                        }, 1500);
                        // window.setInterval(() => {
                        //     this.setState({ startPublish: false });
                        // }, 1500)

                    }
                });
            }
        }, 30)
    }
    changeColor = (item: any): any => {
        if (item.publish === true) {
            return {
                color: "success",
                text: "已发布"
            }
        }
        if (item.publish === false) {
            return {
                color: "waitting",
                text: "未发布"
            }
        }
        if (item.publish === null) {
            return {
                color: "waittingCooperate",
                text: "合作中"
            }
        }
    }
    toDetail = () => {
        localStorage.setItem("imageData", JSON.stringify(this.state.imageData))
        window.location.hash = `/app/ui/ImageDetail?${this.state.imageData.publish ? "toCooperate" : "notPublish"}?fromCooperate`
    }
    render() {
        let showImages: any = this.myMyImages
        if (this.props.type && this.props.type === "mainPage") {
            showImages = JSON.parse(localStorage.getItem("mainPage") || "[]")
        }
        return (
            <div className="gutter-example button-demo">
                <Spin spinning={this.state.spinLoading}>
                    <Row gutter={16}>
                        <Col className="gutter-row" md={24}>
                            <div className="gutter-box">
                                <Card bordered={false}>
                                    {
                                        this.props.type && this.props.type === "mainPage" ? null :
                                            <div style={{ width: "125px", fontSize: "18px", margin: "0 auto", color: "#25262C" }}>我的AI作品展</div>
                                    }

                                    <Row gutter={16}>
                                        {
                                            showImages.map((item: any) => {
                                                return (
                                                    <Col className="gutter-row" md={4} key={item.id}>
                                                        <div className="gutter-box">
                                                            <Card bordered={false} className='mycard'>
                                                                <div className={`publish ${this.changeColor(item).color}`}></div>
                                                                <div className='publistText'>{this.changeColor(item).text}</div>
                                                                {/* <Radio.Group onChange={(e) => this.radioOnChange(e)} value={this.state.value}>
                                                            <Radio> */}
                                                                <Image
                                                                    className='my-album-image'
                                                                    src={item.url}
                                                                    preview={false}
                                                                    // onClick={this.toDetail}
                                                                    onClick={() => this.publishImage(item)}
                                                                />
                                                                <div>
                                                                    <span style={{ marginRight: "20px", fontSize: "20px" }}>
                                                                        <MessageOutlined style={{ color: "#C1C2C5", margin: "0 15px 0 0" }} />
                                                                        <span style={{ color: "#C1C2C5" }}>{item?.message}</span>
                                                                    </span>
                                                                    <span style={{ marginRight: "20px", fontSize: "20px" }}>
                                                                        <HeartTwoTone twoToneColor="#eb2f96" style={{ margin: "0 15px" }} />
                                                                        <span style={{ color: "#C1C2C5" }}>{item?.heart}</span>
                                                                    </span>
                                                                </div>
                                                                {/* </Radio>
                                                            </Radio.Group> */}

                                                            </Card>
                                                        </div>
                                                    </Col>
                                                )
                                            })
                                        }

                                    </Row>
                                </Card>
                            </div>
                        </Col>
                    </Row>
                </Spin>

                <Modal title={null} visible={this.state.loading} footer={null} style={{ textAlign: "center" }} onCancel={() => this.setState({ loading: false })} maskClosable={false}>
                    <Row gutter={16}>
                        <Col className="gutter-row" md={12}>
                            <div className="gutter-box">
                                <Card bordered={false} style={{ backgroundColor: "#25262C" }}>
                                    <Image
                                        className='my-album-image'
                                        src={this.state.imageData.url}
                                        preview={false}
                                    />
                                </Card>
                            </div>
                        </Col>
                        <Col className="gutter-row" md={12}>
                            <div className="gutter-box">
                                <Card bordered={false} className='right' style={{ backgroundColor: "#25262C" }}>
                                    <div style={{ color: "#C1C2C5", margin: "15px", fontSize: "16px" }}>作品描述</div>
                                    <div style={{ color: "#C1C2C5", textAlign: "left", marginBottom: "60px" }}>{this.state.imageData?.des}</div>
                                    {
                                        this.state.imageData.publish ?
                                            <Button type="primary" onClick={this.toCooperate}>
                                                去合作
                                            </Button> :
                                            <Button type="primary" onClick={this.startPublish}>
                                                开始发布
                                            </Button>
                                    }
                                    <Button type="primary" onClick={this.toDetail}>
                                        查看详情
                                    </Button>
                                </Card>
                            </div>
                        </Col>

                    </Row>
                </Modal>
                <Modal title={null} visible={this.state.startPublish} footer={null} style={{ textAlign: "center" }} closable={false} maskClosable={false}>
                    <Progress type="circle" percent={this.state.countDownTime} strokeColor={{ '0%': '#108ee9', '100%': '#87d068' }} />
                    <div style={{ color: "#C1C2C5", margin: "20px 0" }}>{this.state.loadingText}</div>
                </Modal>
                <style>{`
                    .right .ant-card-body{
                        padding: 20px;
                    }
                    .ant-modal-body {
                        background-color: #25262C;
                    }
                    .ant-progress-circle .ant-progress-text {
                        color: #C1C2C5;
                    }
                    .mycard {
                        posititon: relative;
                    }
                    .publish {
                        width: 0;
                        height: 0;
                        border-top: 43px solid skyblue;
                        border-right: 100px solid transparent;
                        position: absolute;
                        z-index: 20;
                    }
                    .success {
                        border-block-color: #86f165;
                    }
                    .waitting {
                        border-block-color: #f9ee33;
                    }
                    .waittingCooperate {
                        border-block-color: #f98233;
                    }
                    .publistText{
                        position: absolute;
                        color: #fff;
                        z-index: 25;
                        top: 28px;
                        left: 28px;
                    }
                    .ant-modal-body {
                        background-color: #25262C;
                    }
                    .ant-modal-close-x {
                        color: #C1C2C5;
                    }
                    .ant-image-img {
                        height:380px;
                        width: 100%;
                        
                    }
                `}</style>
            </div>
        );
    }
}

export default Buttons;
