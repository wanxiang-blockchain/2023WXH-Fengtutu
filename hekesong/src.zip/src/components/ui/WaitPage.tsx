/**
 * Created by hao.cheng on 2017/4/23.
 */
import React from 'react';
import { Result, Col, Card, Row, Image, Button, Drawer, Space } from 'antd';
import { DoubleRightOutlined } from '@ant-design/icons';
import BreadcrumbCustom from '../widget/BreadcrumbCustom';
import { RadioChangeEvent } from 'antd/lib/radio';
import { ButtonSize } from 'antd/lib/button';
import { DownOutlined, LeftOutlined, RightOutlined } from '@ant-design/icons';

type ButtonsState = {
    size: ButtonSize;
    loading: boolean;
    iconLoading: boolean;
    drawerOpen: boolean;
};

class Buttons extends React.Component<any, ButtonsState> {
    constructor(props: any) {
        super(props);
        this.state = {
            size: 'middle',
            loading: false,
            iconLoading: false,
            drawerOpen: false
        };
    }
    myImage: any = JSON.parse(localStorage.getItem("myImages") || "[]")
    imageData: any = JSON.parse(localStorage.getItem("imageData") || "[]")
    goBack = () => {
        this.myImage.forEach((item:any) => {
            if(item.id === this.imageData.id){
                item.publish = null
            }
        }); 
        localStorage.setItem("myImages", JSON.stringify(this.myImage))
        window.location.hash = '/app/ui/Cooperate'
    }
    render() {
        return (
            <div className="gutter-example button-demo">
                <Row gutter={16}>
                    <Col className="gutter-row" md={24}>
                        <div className="gutter-box">
                            <Card bordered={false}>
                                <Result
                                    status="success"
                                    title="合作申请发送成功!"
                                    subTitle="待审核放审核通过后，即可完成合作，可点击刷新按钮手动刷新结果"
                                    extra={[
                                        <Button type="primary" key="console" onClick={this.goBack}>
                                            我的合作作品
                                        </Button>,
                                        <Button key="buy" onClick={() => {window.location.hash = '/app/ui/HeZuoSuccess'}}>刷 新</Button>,
                                    ]}
                                />
                            </Card>
                        </div>
                    </Col>
                </Row>

                <style>{`
                    .button-demo .ant-btn {
                        margin-right: 8px;
                        margin-bottom: 12px;
                    }
                `}</style>
            </div>
        );
    }
}

export default Buttons;
